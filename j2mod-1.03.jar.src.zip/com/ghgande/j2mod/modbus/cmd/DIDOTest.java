/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public class DIDOTest
/*     */ {
/*     */   /* Error */
/*     */   public static void main(String[] args)
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aconst_null
/*     */     //   1: astore_1
/*     */     //   2: aconst_null
/*     */     //   3: astore_2
/*     */     //   4: aconst_null
/*     */     //   5: astore_3
/*     */     //   6: aconst_null
/*     */     //   7: astore 4
/*     */     //   9: aconst_null
/*     */     //   10: astore 5
/*     */     //   12: aconst_null
/*     */     //   13: astore 6
/*     */     //   15: iconst_0
/*     */     //   16: istore 7
/*     */     //   18: iconst_0
/*     */     //   19: istore 8
/*     */     //   21: sipush 502
/*     */     //   24: istore 9
/*     */     //   26: aload_0
/*     */     //   27: arraylength
/*     */     //   28: iconst_3
/*     */     //   29: if_icmpge +13 -> 42
/*     */     //   32: invokestatic 16	com/ghgande/j2mod/modbus/cmd/DIDOTest:printUsage	()V
/*     */     //   35: iconst_1
/*     */     //   36: invokestatic 19	java/lang/System:exit	(I)V
/*     */     //   39: goto +85 -> 124
/*     */     //   42: aload_0
/*     */     //   43: iconst_0
/*     */     //   44: aaload
/*     */     //   45: astore 10
/*     */     //   47: aload 10
/*     */     //   49: bipush 58
/*     */     //   51: invokevirtual 25	java/lang/String:indexOf	(I)I
/*     */     //   54: istore 11
/*     */     //   56: iload 11
/*     */     //   58: ifle +27 -> 85
/*     */     //   61: aload 10
/*     */     //   63: iload 11
/*     */     //   65: iconst_1
/*     */     //   66: iadd
/*     */     //   67: invokevirtual 31	java/lang/String:substring	(I)Ljava/lang/String;
/*     */     //   70: invokestatic 35	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*     */     //   73: istore 9
/*     */     //   75: aload 10
/*     */     //   77: iconst_0
/*     */     //   78: iload 11
/*     */     //   80: invokevirtual 41	java/lang/String:substring	(II)Ljava/lang/String;
/*     */     //   83: astore 10
/*     */     //   85: aload 10
/*     */     //   87: invokestatic 44	java/net/InetAddress:getByName	(Ljava/lang/String;)Ljava/net/InetAddress;
/*     */     //   90: astore_1
/*     */     //   91: aload_0
/*     */     //   92: iconst_1
/*     */     //   93: aaload
/*     */     //   94: invokestatic 35	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*     */     //   97: istore 7
/*     */     //   99: aload_0
/*     */     //   100: iconst_2
/*     */     //   101: aaload
/*     */     //   102: invokestatic 35	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*     */     //   105: istore 8
/*     */     //   107: goto +17 -> 124
/*     */     //   110: astore 10
/*     */     //   112: aload 10
/*     */     //   114: invokevirtual 50	java/lang/Exception:printStackTrace	()V
/*     */     //   117: invokestatic 16	com/ghgande/j2mod/modbus/cmd/DIDOTest:printUsage	()V
/*     */     //   120: iconst_1
/*     */     //   121: invokestatic 19	java/lang/System:exit	(I)V
/*     */     //   124: new 55	com/ghgande/j2mod/modbus/net/TCPMasterConnection
/*     */     //   127: dup
/*     */     //   128: aload_1
/*     */     //   129: invokespecial 57	com/ghgande/j2mod/modbus/net/TCPMasterConnection:<init>	(Ljava/net/InetAddress;)V
/*     */     //   132: astore_2
/*     */     //   133: aload_2
/*     */     //   134: iload 9
/*     */     //   136: invokevirtual 60	com/ghgande/j2mod/modbus/net/TCPMasterConnection:setPort	(I)V
/*     */     //   139: aload_2
/*     */     //   140: invokevirtual 63	com/ghgande/j2mod/modbus/net/TCPMasterConnection:connect	()V
/*     */     //   143: getstatic 66	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*     */     //   146: ifeq +40 -> 186
/*     */     //   149: getstatic 72	java/lang/System:out	Ljava/io/PrintStream;
/*     */     //   152: new 76	java/lang/StringBuilder
/*     */     //   155: dup
/*     */     //   156: ldc 78
/*     */     //   158: invokespecial 80	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   161: aload_1
/*     */     //   162: invokevirtual 83	java/net/InetAddress:toString	()Ljava/lang/String;
/*     */     //   165: invokevirtual 87	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   168: ldc 91
/*     */     //   170: invokevirtual 87	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   173: aload_2
/*     */     //   174: invokevirtual 93	com/ghgande/j2mod/modbus/net/TCPMasterConnection:getPort	()I
/*     */     //   177: invokevirtual 97	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*     */     //   180: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   183: invokevirtual 101	java/io/PrintStream:println	(Ljava/lang/String;)V
/*     */     //   186: new 106	com/ghgande/j2mod/modbus/msg/ReadInputDiscretesRequest
/*     */     //   189: dup
/*     */     //   190: iload 7
/*     */     //   192: iconst_1
/*     */     //   193: invokespecial 108	com/ghgande/j2mod/modbus/msg/ReadInputDiscretesRequest:<init>	(II)V
/*     */     //   196: astore_3
/*     */     //   197: new 111	com/ghgande/j2mod/modbus/msg/WriteCoilRequest
/*     */     //   200: dup
/*     */     //   201: invokespecial 113	com/ghgande/j2mod/modbus/msg/WriteCoilRequest:<init>	()V
/*     */     //   204: astore 4
/*     */     //   206: aload 4
/*     */     //   208: iload 8
/*     */     //   210: invokevirtual 114	com/ghgande/j2mod/modbus/msg/WriteCoilRequest:setReference	(I)V
/*     */     //   213: aload_3
/*     */     //   214: iconst_0
/*     */     //   215: invokevirtual 117	com/ghgande/j2mod/modbus/msg/ModbusRequest:setUnitID	(I)V
/*     */     //   218: aload 4
/*     */     //   220: iconst_0
/*     */     //   221: invokevirtual 122	com/ghgande/j2mod/modbus/msg/WriteCoilRequest:setUnitID	(I)V
/*     */     //   224: new 123	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction
/*     */     //   227: dup
/*     */     //   228: aload_2
/*     */     //   229: invokespecial 125	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction:<init>	(Lcom/ghgande/j2mod/modbus/net/TCPMasterConnection;)V
/*     */     //   232: astore 5
/*     */     //   234: aload 5
/*     */     //   236: aload_3
/*     */     //   237: invokevirtual 128	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction:setRequest	(Lcom/ghgande/j2mod/modbus/msg/ModbusRequest;)V
/*     */     //   240: aload 5
/*     */     //   242: iconst_0
/*     */     //   243: invokevirtual 132	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction:setReconnecting	(Z)V
/*     */     //   246: new 123	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction
/*     */     //   249: dup
/*     */     //   250: aload_2
/*     */     //   251: invokespecial 125	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction:<init>	(Lcom/ghgande/j2mod/modbus/net/TCPMasterConnection;)V
/*     */     //   254: astore 6
/*     */     //   256: aload 6
/*     */     //   258: aload 4
/*     */     //   260: invokevirtual 128	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction:setRequest	(Lcom/ghgande/j2mod/modbus/msg/ModbusRequest;)V
/*     */     //   263: aload 6
/*     */     //   265: iconst_0
/*     */     //   266: invokevirtual 132	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction:setReconnecting	(Z)V
/*     */     //   269: iconst_0
/*     */     //   270: istore 10
/*     */     //   272: iconst_0
/*     */     //   273: istore 11
/*     */     //   275: aload 5
/*     */     //   277: invokevirtual 136	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction:execute	()V
/*     */     //   280: aload 5
/*     */     //   282: invokevirtual 139	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction:getResponse	()Lcom/ghgande/j2mod/modbus/msg/ModbusResponse;
/*     */     //   285: checkcast 143	com/ghgande/j2mod/modbus/msg/ReadInputDiscretesResponse
/*     */     //   288: iconst_0
/*     */     //   289: invokevirtual 145	com/ghgande/j2mod/modbus/msg/ReadInputDiscretesResponse:getDiscreteStatus	(I)Z
/*     */     //   292: istore 11
/*     */     //   294: iload 11
/*     */     //   296: iload 10
/*     */     //   298: if_icmpeq -23 -> 275
/*     */     //   301: aload 4
/*     */     //   303: iload 11
/*     */     //   305: invokevirtual 149	com/ghgande/j2mod/modbus/msg/WriteCoilRequest:setCoil	(Z)V
/*     */     //   308: aload 6
/*     */     //   310: invokevirtual 136	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction:execute	()V
/*     */     //   313: iload 11
/*     */     //   315: istore 10
/*     */     //   317: getstatic 66	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*     */     //   320: ifeq -45 -> 275
/*     */     //   323: getstatic 72	java/lang/System:out	Ljava/io/PrintStream;
/*     */     //   326: ldc -104
/*     */     //   328: invokevirtual 101	java/io/PrintStream:println	(Ljava/lang/String;)V
/*     */     //   331: goto -56 -> 275
/*     */     //   334: astore 10
/*     */     //   336: aload 10
/*     */     //   338: invokevirtual 50	java/lang/Exception:printStackTrace	()V
/*     */     //   341: aload_2
/*     */     //   342: invokevirtual 154	com/ghgande/j2mod/modbus/net/TCPMasterConnection:close	()V
/*     */     //   345: goto +12 -> 357
/*     */     //   348: astore 12
/*     */     //   350: aload_2
/*     */     //   351: invokevirtual 154	com/ghgande/j2mod/modbus/net/TCPMasterConnection:close	()V
/*     */     //   354: aload 12
/*     */     //   356: athrow
/*     */     //   357: return
/*     */     // Line number table:
/*     */     //   Java source line #68	-> byte code offset #0
/*     */     //   Java source line #69	-> byte code offset #2
/*     */     //   Java source line #70	-> byte code offset #4
/*     */     //   Java source line #71	-> byte code offset #6
/*     */     //   Java source line #73	-> byte code offset #9
/*     */     //   Java source line #74	-> byte code offset #12
/*     */     //   Java source line #76	-> byte code offset #15
/*     */     //   Java source line #77	-> byte code offset #18
/*     */     //   Java source line #78	-> byte code offset #21
/*     */     //   Java source line #83	-> byte code offset #26
/*     */     //   Java source line #84	-> byte code offset #32
/*     */     //   Java source line #85	-> byte code offset #35
/*     */     //   Java source line #86	-> byte code offset #39
/*     */     //   Java source line #88	-> byte code offset #42
/*     */     //   Java source line #89	-> byte code offset #47
/*     */     //   Java source line #90	-> byte code offset #56
/*     */     //   Java source line #91	-> byte code offset #61
/*     */     //   Java source line #92	-> byte code offset #75
/*     */     //   Java source line #94	-> byte code offset #85
/*     */     //   Java source line #95	-> byte code offset #91
/*     */     //   Java source line #96	-> byte code offset #99
/*     */     //   Java source line #97	-> byte code offset #107
/*     */     //   Java source line #98	-> byte code offset #112
/*     */     //   Java source line #99	-> byte code offset #117
/*     */     //   Java source line #100	-> byte code offset #120
/*     */     //   Java source line #105	-> byte code offset #124
/*     */     //   Java source line #106	-> byte code offset #133
/*     */     //   Java source line #107	-> byte code offset #139
/*     */     //   Java source line #108	-> byte code offset #143
/*     */     //   Java source line #109	-> byte code offset #149
/*     */     //   Java source line #110	-> byte code offset #173
/*     */     //   Java source line #109	-> byte code offset #183
/*     */     //   Java source line #113	-> byte code offset #186
/*     */     //   Java source line #115	-> byte code offset #197
/*     */     //   Java source line #116	-> byte code offset #206
/*     */     //   Java source line #118	-> byte code offset #213
/*     */     //   Java source line #119	-> byte code offset #218
/*     */     //   Java source line #122	-> byte code offset #224
/*     */     //   Java source line #123	-> byte code offset #234
/*     */     //   Java source line #124	-> byte code offset #240
/*     */     //   Java source line #125	-> byte code offset #246
/*     */     //   Java source line #126	-> byte code offset #256
/*     */     //   Java source line #127	-> byte code offset #263
/*     */     //   Java source line #130	-> byte code offset #269
/*     */     //   Java source line #131	-> byte code offset #272
/*     */     //   Java source line #135	-> byte code offset #275
/*     */     //   Java source line #137	-> byte code offset #280
/*     */     //   Java source line #136	-> byte code offset #285
/*     */     //   Java source line #137	-> byte code offset #288
/*     */     //   Java source line #136	-> byte code offset #292
/*     */     //   Java source line #140	-> byte code offset #294
/*     */     //   Java source line #141	-> byte code offset #301
/*     */     //   Java source line #142	-> byte code offset #308
/*     */     //   Java source line #143	-> byte code offset #313
/*     */     //   Java source line #144	-> byte code offset #317
/*     */     //   Java source line #145	-> byte code offset #323
/*     */     //   Java source line #147	-> byte code offset #331
/*     */     //   Java source line #149	-> byte code offset #334
/*     */     //   Java source line #150	-> byte code offset #336
/*     */     //   Java source line #154	-> byte code offset #341
/*     */     //   Java source line #151	-> byte code offset #348
/*     */     //   Java source line #154	-> byte code offset #350
/*     */     //   Java source line #156	-> byte code offset #354
/*     */     //   Java source line #157	-> byte code offset #357
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	358	0	args	String[]
/*     */     //   1	161	1	addr	java.net.InetAddress
/*     */     //   3	348	2	con	com.ghgande.j2mod.modbus.net.TCPMasterConnection
/*     */     //   5	232	3	di_req	com.ghgande.j2mod.modbus.msg.ModbusRequest
/*     */     //   7	295	4	do_req	com.ghgande.j2mod.modbus.msg.WriteCoilRequest
/*     */     //   10	271	5	di_trans	com.ghgande.j2mod.modbus.io.ModbusTCPTransaction
/*     */     //   13	296	6	do_trans	com.ghgande.j2mod.modbus.io.ModbusTCPTransaction
/*     */     //   16	175	7	di_ref	int
/*     */     //   19	190	8	do_ref	int
/*     */     //   24	111	9	port	int
/*     */     //   45	41	10	astr	String
/*     */     //   110	3	10	ex	Exception
/*     */     //   270	46	10	last_out	boolean
/*     */     //   334	3	10	ex	Exception
/*     */     //   54	25	11	idx	int
/*     */     //   273	41	11	new_in	boolean
/*     */     //   348	7	12	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   42	107	110	java/lang/Exception
/*     */     //   26	334	334	java/lang/Exception
/*     */     //   26	341	348	finally
/*     */   }
/*     */   
/*     */   private static void printUsage()
/*     */   {
/* 161 */     System.out.println("java com.ghgande.j2mod.modbus.cmd.DIDOTest <address{:<port>} [String]> <register d_in [int16]> <register d_out [int16]>");
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\DIDOTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */