/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusException;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusRTUTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTCPTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransaction;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransport;
/*     */ import com.ghgande.j2mod.modbus.msg.ExceptionResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadMultipleRegistersRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadMultipleRegistersResponse;
/*     */ import com.ghgande.j2mod.modbus.net.ModbusMasterFactory;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadHoldingRegistersTest
/*     */ {
/*     */   private static void printUsage()
/*     */   {
/* 113 */     System.out.println("java com.ghgande.j2mod.modbus.cmd.ReadHoldingRegistersTest <address{:port{:unit}} [String]> <base [int]> <count [int]> {<repeat [int]>}");
/*     */   }
/*     */   
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 119 */     ModbusTransport transport = null;
/* 120 */     ModbusRequest req = null;
/* 121 */     ModbusTransaction trans = null;
/* 122 */     int ref = 0;
/* 123 */     int count = 0;
/* 124 */     int repeat = 1;
/* 125 */     int unit = 0;
/*     */     
/*     */ 
/* 128 */     if (args.length < 3) {
/* 129 */       printUsage();
/* 130 */       System.exit(1);
/*     */     }
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/* 136 */         transport = ModbusMasterFactory.createModbusMaster(args[0]);
/* 137 */         if (transport == null) {
/* 138 */           System.err.println("Cannot open " + args[0]);
/* 139 */           System.exit(1);
/*     */         }
/* 141 */         ref = Integer.parseInt(args[1]);
/* 142 */         count = Integer.parseInt(args[2]);
/*     */         
/* 144 */         if (args.length == 4) {
/* 145 */           repeat = Integer.parseInt(args[3]);
/*     */         }
/* 147 */         if ((transport instanceof ModbusTCPTransport)) {
/* 148 */           String[] parts = args[0].split(":");
/* 149 */           if (parts.length >= 4)
/* 150 */             unit = Integer.parseInt(parts[3]);
/* 151 */         } else if ((transport instanceof ModbusRTUTransport)) {
/* 152 */           String[] parts = args[0].split(":");
/* 153 */           if (parts.length >= 3)
/* 154 */             unit = Integer.parseInt(parts[2]);
/*     */         }
/*     */       } catch (Exception ex) {
/* 157 */         ex.printStackTrace();
/* 158 */         printUsage();
/* 159 */         System.exit(1);
/*     */       }
/*     */       
/*     */ 
/* 163 */       req = new ReadMultipleRegistersRequest(ref, count);
/* 164 */       req.setUnitID(unit);
/* 165 */       if (Modbus.debug) {
/* 166 */         System.out.println("Request: " + req.getHexMessage());
/*     */       }
/*     */       
/* 169 */       trans = transport.createTransaction();
/* 170 */       trans.setRequest(req);
/*     */       
/*     */ 
/*     */ 
/* 174 */       for (int i = 0; i < repeat; i++) {
/*     */         try {
/* 176 */           trans.execute();
/*     */         } catch (ModbusException x) {
/* 178 */           System.err.println(x.getMessage());
/* 179 */           continue;
/*     */         }
/* 181 */         ModbusResponse res = trans.getResponse();
/*     */         
/* 183 */         if (Modbus.debug) {
/* 184 */           if (res != null) {
/* 185 */             System.out.println("Response: " + res.getHexMessage());
/*     */           } else
/* 187 */             System.err.println("No response to READ HOLDING request.");
/*     */         }
/* 189 */         if ((res instanceof ExceptionResponse)) {
/* 190 */           ExceptionResponse exception = (ExceptionResponse)res;
/* 191 */           System.out.println(exception);
/*     */ 
/*     */ 
/*     */         }
/* 195 */         else if ((res instanceof ReadMultipleRegistersResponse))
/*     */         {
/*     */ 
/* 198 */           ReadMultipleRegistersResponse data = (ReadMultipleRegistersResponse)res;
/* 199 */           Register[] values = data.getRegisters();
/*     */           
/* 201 */           System.out.println("Data: " + Arrays.toString(values));
/*     */         }
/*     */       }
/* 204 */     } catch (Exception ex) { ex.printStackTrace();
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 209 */       if (transport != null) {
/* 210 */         transport.close();
/*     */       }
/*     */     }
/*     */     catch (IOException localIOException) {}
/* 214 */     System.exit(0);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\ReadHoldingRegistersTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */