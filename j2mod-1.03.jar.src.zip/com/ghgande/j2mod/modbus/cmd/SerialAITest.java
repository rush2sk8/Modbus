/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusSerialTransaction;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputRegistersRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputRegistersResponse;
/*     */ import com.ghgande.j2mod.modbus.net.SerialConnection;
/*     */ import com.ghgande.j2mod.modbus.util.SerialParameters;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerialAITest
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  55 */     SerialConnection con = null;
/*  56 */     ModbusSerialTransaction trans = null;
/*  57 */     ReadInputRegistersRequest req = null;
/*  58 */     ReadInputRegistersResponse res = null;
/*     */     
/*  60 */     String portname = null;
/*  61 */     int unitid = 0;
/*  62 */     int ref = 0;
/*  63 */     int count = 0;
/*  64 */     int repeat = 1;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/*  69 */       if (args.length < 4) {
/*  70 */         printUsage();
/*  71 */         System.exit(1);
/*     */       } else {
/*     */         try {
/*  74 */           portname = args[0];
/*  75 */           unitid = Integer.parseInt(args[1]);
/*  76 */           ref = Integer.parseInt(args[2]);
/*  77 */           count = Integer.parseInt(args[3]);
/*  78 */           if (args.length == 5) {
/*  79 */             repeat = Integer.parseInt(args[4]);
/*     */           }
/*     */         } catch (Exception ex) {
/*  82 */           ex.printStackTrace();
/*  83 */           printUsage();
/*  84 */           System.exit(1);
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*  89 */       ModbusCoupler.getReference().setUnitID(unitid);
/*     */       
/*  91 */       System.out.println("com.ghgande.j2mod.modbus.debug set to: " + 
/*  92 */         System.getProperty("com.ghgande.j2mod.modbus.debug"));
/*     */       
/*     */ 
/*  95 */       SerialParameters params = new SerialParameters();
/*  96 */       params.setPortName(portname);
/*  97 */       params.setBaudRate(9600);
/*  98 */       params.setDatabits(8);
/*  99 */       params.setParity("None");
/* 100 */       params.setStopbits(1);
/* 101 */       params.setEncoding("ascii");
/* 102 */       params.setEcho(false);
/* 103 */       if (Modbus.debug) { System.out.println("Encoding [" + params.getEncoding() + "]");
/*     */       }
/*     */       
/* 106 */       con = new SerialConnection(params);
/* 107 */       con.open();
/*     */       
/*     */ 
/* 110 */       req = new ReadInputRegistersRequest(ref, count);
/* 111 */       req.setUnitID(unitid);
/* 112 */       req.setHeadless();
/* 113 */       if (Modbus.debug) { System.out.println("Request: " + req.getHexMessage());
/*     */       }
/*     */       
/* 116 */       trans = new ModbusSerialTransaction(con);
/* 117 */       trans.setRequest(req);
/*     */       
/*     */ 
/* 120 */       int k = 0;
/*     */       do {
/* 122 */         trans.execute();
/*     */         
/* 124 */         res = (ReadInputRegistersResponse)trans.getResponse();
/* 125 */         if (Modbus.debug)
/* 126 */           System.out.println("Response: " + res.getHexMessage());
/* 127 */         for (int n = 0; n < res.getWordCount(); n++) {
/* 128 */           System.out.println("Word " + n + "=" + res.getRegisterValue(n));
/*     */         }
/* 130 */         k++;
/* 121 */       } while (
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */         k < repeat);
/*     */       
/*     */ 
/* 134 */       con.close();
/*     */     }
/*     */     catch (Exception ex) {
/* 137 */       ex.printStackTrace();
/*     */       
/* 139 */       con.close();
/*     */     }
/*     */   }
/*     */   
/*     */   private static void printUsage() {
/* 144 */     System.out.println(
/* 145 */       "java com.ghgande.j2mod.modbus.cmd.SerialAITest <portname [String]>  <Unit Address [int8]> <register [int16]> <wordcount [int16]> {<repeat [int]>}");
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\SerialAITest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */