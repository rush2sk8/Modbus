/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.net.ModbusListener;
/*     */ import com.ghgande.j2mod.modbus.net.ModbusListenerFactory;
/*     */ import com.ghgande.j2mod.modbus.procimg.File;
/*     */ import com.ghgande.j2mod.modbus.procimg.Record;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleDigitalIn;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleDigitalOut;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleInputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusSlaveTest
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  57 */     ModbusListener listener = null;
/*  58 */     SimpleProcessImage spi = null;
/*     */     try
/*     */     {
/*  61 */       System.out.println("j2mod Modbus Slave (Server) v0.97");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  66 */       spi = new SimpleProcessImage();
/*     */       
/*  68 */       spi.addDigitalOut(new SimpleDigitalOut(true));
/*  69 */       spi.addDigitalOut(new SimpleDigitalOut(true));
/*     */       
/*  71 */       spi.addDigitalIn(new SimpleDigitalIn(false));
/*  72 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/*  73 */       spi.addDigitalIn(new SimpleDigitalIn(false));
/*  74 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/*     */       
/*  76 */       spi.addFile(new File(0, 10).setRecord(0, new Record(0, 10))
/*  77 */         .setRecord(1, new Record(1, 10))
/*  78 */         .setRecord(2, new Record(2, 10))
/*  79 */         .setRecord(3, new Record(3, 10))
/*  80 */         .setRecord(4, new Record(4, 10))
/*  81 */         .setRecord(5, new Record(5, 10))
/*  82 */         .setRecord(6, new Record(6, 10))
/*  83 */         .setRecord(7, new Record(7, 10))
/*  84 */         .setRecord(8, new Record(8, 10))
/*  85 */         .setRecord(9, new Record(9, 10)));
/*     */       
/*  87 */       spi.addFile(new File(1, 20)
/*  88 */         .setRecord(0, new Record(0, 10))
/*  89 */         .setRecord(1, new Record(1, 20))
/*  90 */         .setRecord(2, new Record(2, 20))
/*  91 */         .setRecord(3, new Record(3, 20))
/*  92 */         .setRecord(4, new Record(4, 20))
/*  93 */         .setRecord(5, new Record(5, 20))
/*  94 */         .setRecord(6, new Record(6, 20))
/*  95 */         .setRecord(7, new Record(7, 20))
/*  96 */         .setRecord(8, new Record(8, 20))
/*  97 */         .setRecord(9, new Record(9, 20))
/*  98 */         .setRecord(10, new Record(10, 10))
/*  99 */         .setRecord(11, new Record(11, 20))
/* 100 */         .setRecord(12, new Record(12, 20))
/* 101 */         .setRecord(13, new Record(13, 20))
/* 102 */         .setRecord(14, new Record(14, 20))
/* 103 */         .setRecord(15, new Record(15, 20))
/* 104 */         .setRecord(16, new Record(16, 20))
/* 105 */         .setRecord(17, new Record(17, 20))
/* 106 */         .setRecord(18, new Record(18, 20))
/* 107 */         .setRecord(19, new Record(19, 20)));
/*     */       
/*     */ 
/*     */ 
/* 111 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/* 112 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/* 113 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/* 114 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/*     */       
/* 116 */       spi.addRegister(new SimpleRegister(251));
/* 117 */       spi.addInputRegister(new SimpleInputRegister(45));
/*     */       
/*     */ 
/* 120 */       ModbusCoupler.getReference().setProcessImage(spi);
/* 121 */       ModbusCoupler.getReference().setMaster(false);
/* 122 */       ModbusCoupler.getReference().setUnitID(15);
/*     */       
/*     */ 
/* 125 */       System.out.println("Creating.");
/*     */       
/* 127 */       listener = ModbusListenerFactory.createModbusListener(args[0]);
/*     */       
/* 129 */       System.out.println("Listening.");
/*     */       
/* 131 */       while (listener.isListening()) {
/*     */         try {
/* 133 */           Thread.sleep(1000L);
/*     */         } catch (InterruptedException x) {
/* 135 */           listener.stop();
/* 136 */           break;
/*     */         }
/*     */       }
/*     */       
/* 140 */       System.out.println("Done.");
/*     */     } catch (Exception x) {
/* 142 */       if (Modbus.debug) {
/* 143 */         x.printStackTrace();
/*     */       }
/* 145 */       if (listener != null) {
/* 146 */         listener.stop();
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\ModbusSlaveTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */