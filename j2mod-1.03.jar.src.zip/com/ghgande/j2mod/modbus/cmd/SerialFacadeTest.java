/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusException;
/*     */ import com.ghgande.j2mod.modbus.facade.ModbusSerialMaster;
/*     */ import com.ghgande.j2mod.modbus.procimg.InputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import com.ghgande.j2mod.modbus.util.BitVector;
/*     */ import com.ghgande.j2mod.modbus.util.ModbusUtil;
/*     */ import com.ghgande.j2mod.modbus.util.SerialParameters;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerialFacadeTest
/*     */ {
/*     */   private static void printUsage()
/*     */   {
/*  70 */     System.out.println("java com.ghgande.j2mod.modbus.cmd.SerialAITest <portname [String]> <Unit Address [int8]>");
/*     */   }
/*     */   
/*     */   public static void main(String[] args)
/*     */   {
/*  75 */     int inChar = -1;
/*  76 */     int result = 0;
/*  77 */     boolean finished = false;
/*  78 */     int slaveId = 88;
/*  79 */     String portname = null;
/*  80 */     ModbusSerialMaster msm = null;
/*     */     
/*     */ 
/*  83 */     if (args.length < 2) {
/*  84 */       printUsage();
/*  85 */       System.exit(1);
/*     */     } else {
/*     */       try {
/*  88 */         portname = args[0];
/*  89 */         slaveId = Integer.parseInt(args[1]);
/*     */       } catch (Exception ex) {
/*  91 */         ex.printStackTrace();
/*  92 */         printUsage();
/*  93 */         System.exit(1);
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/*  98 */       System.out.println("Sending test messages to slave: " + slaveId);
/*  99 */       System.out.println("com.ghgande.j2mod.modbus.debug set to: " + 
/* 100 */         System.getProperty("com.ghgande.j2mod.modbus.debug"));
/*     */       
/* 102 */       System.out
/* 103 */         .println("Hit enter to start and <s enter> to terminate the test.");
/* 104 */       inChar = System.in.read();
/* 105 */       if ((inChar == 115) || (inChar == 83)) {
/* 106 */         System.out.println("Exiting");
/* 107 */         System.exit(0);
/*     */       }
/*     */       
/*     */ 
/* 111 */       SerialParameters params = new SerialParameters();
/* 112 */       params.setPortName(portname);
/* 113 */       params.setBaudRate(9600);
/* 114 */       params.setDatabits(8);
/* 115 */       params.setParity("None");
/* 116 */       params.setStopbits(1);
/* 117 */       params.setEncoding("rtu");
/* 118 */       params.setEcho(false);
/*     */       
/* 120 */       if (Modbus.debug) {
/* 121 */         System.out.println("Encoding [" + params.getEncoding() + "]");
/*     */       }
/*     */       
/* 124 */       msm = new ModbusSerialMaster(params);
/* 125 */       msm.connect();
/*     */       do
/*     */       {
/* 128 */         if (msm.writeCoil(slaveId, 4, true)) {
/* 129 */           System.out.println("Set output 5 to true");
/*     */         } else {
/* 131 */           System.err.println("Error setting slave " + slaveId + 
/* 132 */             " output 5");
/*     */         }
/* 134 */         BitVector coils = msm.readCoils(slaveId, 0, 8);
/* 135 */         if (coils != null) {
/* 136 */           System.out.print("Coils:");
/* 137 */           for (int i = 0; i < coils.size(); i++) {
/* 138 */             System.out.print(" " + i + ": " + coils.getBit(i));
/*     */           }
/* 140 */           System.out.println();
/*     */           try
/*     */           {
/* 143 */             msm.writeMultipleCoils(slaveId, 0, coils);
/*     */           } catch (ModbusException ex) {
/* 145 */             System.out.println("Error writing coils: " + result);
/*     */           }
/*     */         } else {
/* 148 */           System.out.println("Outputs: null");
/* 149 */           msm.disconnect();
/* 150 */           System.exit(-1);
/*     */         }
/*     */         
/* 153 */         BitVector digInp = msm.readInputDiscretes(slaveId, 0, 8);
/*     */         
/* 155 */         if (digInp != null) {
/* 156 */           System.out.print("Digital Inputs:");
/* 157 */           for (int i = 0; i < digInp.size(); i++) {
/* 158 */             System.out.print(" " + i + ": " + digInp.getBit(i));
/*     */           }
/* 160 */           System.out.println();
/* 161 */           System.out.println("Inputs: " + 
/* 162 */             ModbusUtil.toHex(digInp.getBytes()));
/*     */         } else {
/* 164 */           System.out.println("Inputs: null");
/* 165 */           msm.disconnect();
/* 166 */           System.exit(-1);
/*     */         }
/*     */         
/* 169 */         InputRegister[] ai = null;
/* 170 */         for (int i = 1000; i < 1010; i++) {
/* 171 */           ai = msm.readInputRegisters(slaveId, i, 1);
/* 172 */           if (ai != null) {
/* 173 */             System.out.print("Tag " + i + ": ");
/* 174 */             for (int n = 0; n < ai.length; n++) {
/* 175 */               System.out.print(" " + ai[n].getValue());
/*     */             }
/* 177 */             System.out.println();
/*     */           } else {
/* 179 */             System.out.println("Tag: " + i + " null");
/* 180 */             msm.disconnect();
/* 181 */             System.exit(-1);
/*     */           }
/*     */         }
/*     */         
/* 185 */         Register[] regs = null;
/* 186 */         for (int i = 1000; i < 1005; i++) {
/* 187 */           regs = msm.readMultipleRegisters(slaveId, i, 1);
/* 188 */           if (regs != null) {
/* 189 */             System.out.print("RWRegisters " + i + " length: " + 
/* 190 */               regs.length);
/* 191 */             for (int n = 0; n < regs.length; n++) {
/* 192 */               System.out.print(" " + regs[n].getValue());
/*     */             }
/* 194 */             System.out.println();
/*     */           } else {
/* 196 */             System.out.println("RWRegisters " + i + ": null");
/* 197 */             msm.disconnect();
/* 198 */             System.exit(-1);
/*     */           }
/*     */         }
/* 201 */         regs = msm.readMultipleRegisters(slaveId, 0, 10);
/* 202 */         System.out.println("Registers: ");
/* 203 */         if (regs != null) {
/* 204 */           System.out.print("regs :");
/* 205 */           for (int n = 0; n < regs.length; n++) {
/* 206 */             System.out.print("  " + n + "= " + regs[n]);
/*     */           }
/* 208 */           System.out.println();
/*     */         } else {
/* 210 */           System.out.println("Registers: null");
/* 211 */           msm.disconnect();
/* 212 */           System.exit(-1);
/*     */         }
/* 214 */         while (System.in.available() > 0) {
/* 215 */           inChar = System.in.read();
/* 216 */           if ((inChar == 115) || (inChar == 83)) {
/* 217 */             finished = true;
/*     */           }
/*     */         }
/* 220 */       } while (!finished);
/*     */     } catch (Exception e) {
/* 222 */       System.err.println("SerialFacadeTest driver: " + e);
/* 223 */       e.printStackTrace();
/*     */     }
/* 225 */     msm.disconnect();
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\SerialFacadeTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */