/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.net.ModbusUDPListener;
/*     */ import com.ghgande.j2mod.modbus.procimg.File;
/*     */ import com.ghgande.j2mod.modbus.procimg.Record;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleDigitalIn;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleDigitalOut;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleInputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UDPSlaveTest
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  96 */     ModbusUDPListener listener = null;
/*  97 */     SimpleProcessImage spi = null;
/*  98 */     int port = 502;
/*     */     
/*     */     try
/*     */     {
/* 102 */       if ((args != null) && (args.length == 1)) {
/* 103 */         port = Integer.parseInt(args[0]);
/*     */       }
/*     */       
/* 106 */       System.out.println("j2mod Modbus/UDP Slave v0.97");
/*     */       
/*     */ 
/* 109 */       spi = new SimpleProcessImage();
/* 110 */       spi.addDigitalOut(new SimpleDigitalOut(true));
/* 111 */       spi.addDigitalIn(new SimpleDigitalIn(false));
/* 112 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/* 113 */       spi.addDigitalIn(new SimpleDigitalIn(false));
/* 114 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/* 115 */       spi.addRegister(new SimpleRegister(251));
/*     */       
/* 117 */       spi.addFile(new File(0, 10)
/* 118 */         .setRecord(0, new Record(0, 10))
/* 119 */         .setRecord(1, new Record(1, 10))
/* 120 */         .setRecord(2, new Record(2, 10))
/* 121 */         .setRecord(3, new Record(3, 10))
/* 122 */         .setRecord(4, new Record(4, 10))
/* 123 */         .setRecord(5, new Record(5, 10))
/* 124 */         .setRecord(6, new Record(6, 10))
/* 125 */         .setRecord(7, new Record(7, 10))
/* 126 */         .setRecord(8, new Record(8, 10))
/* 127 */         .setRecord(9, new Record(9, 10)));
/*     */       
/* 129 */       spi.addFile(new File(1, 20)
/* 130 */         .setRecord(0, new Record(0, 10))
/* 131 */         .setRecord(1, new Record(1, 20))
/* 132 */         .setRecord(2, new Record(2, 20))
/* 133 */         .setRecord(3, new Record(3, 20))
/* 134 */         .setRecord(4, new Record(4, 20))
/* 135 */         .setRecord(5, new Record(5, 20))
/* 136 */         .setRecord(6, new Record(6, 20))
/* 137 */         .setRecord(7, new Record(7, 20))
/* 138 */         .setRecord(8, new Record(8, 20))
/* 139 */         .setRecord(9, new Record(9, 20))
/* 140 */         .setRecord(10, new Record(10, 10))
/* 141 */         .setRecord(11, new Record(11, 20))
/* 142 */         .setRecord(12, new Record(12, 20))
/* 143 */         .setRecord(13, new Record(13, 20))
/* 144 */         .setRecord(14, new Record(14, 20))
/* 145 */         .setRecord(15, new Record(15, 20))
/* 146 */         .setRecord(16, new Record(16, 20))
/* 147 */         .setRecord(17, new Record(17, 20))
/* 148 */         .setRecord(18, new Record(18, 20))
/* 149 */         .setRecord(19, new Record(19, 20)));
/*     */       
/*     */ 
/* 152 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/* 153 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/* 154 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/* 155 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/*     */       
/* 157 */       spi.addRegister(new SimpleRegister(251));
/* 158 */       spi.addInputRegister(new SimpleInputRegister(45));
/*     */       
/* 160 */       ModbusCoupler.getReference().setProcessImage(spi);
/* 161 */       ModbusCoupler.getReference().setMaster(false);
/* 162 */       ModbusCoupler.getReference().setUnitID(15);
/*     */       
/*     */ 
/* 165 */       listener = new ModbusUDPListener();
/* 166 */       listener.setPort(port);
/* 167 */       new Thread(listener).start();
/*     */     }
/*     */     catch (Exception ex) {
/* 170 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\UDPSlaveTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */