/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.net.ModbusTCPListener;
/*     */ import com.ghgande.j2mod.modbus.procimg.File;
/*     */ import com.ghgande.j2mod.modbus.procimg.Record;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleDigitalIn;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleDigitalOut;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleInputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.PrintStream;
/*     */ import java.net.Inet4Address;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TCPSlaveTest
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  59 */     ModbusTCPListener listener = null;
/*  60 */     SimpleProcessImage spi = null;
/*  61 */     int port = 502;
/*  62 */     int unit = 0;
/*     */     try
/*     */     {
/*  65 */       if ((args != null) && (args.length == 1)) {
/*  66 */         port = Integer.parseInt(args[0]);
/*     */       }
/*  68 */       System.out.println("j2mod Modbus Slave (Server) v0.97");
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*  73 */       spi = new SimpleProcessImage();
/*     */       
/*  75 */       spi.addDigitalOut(new SimpleDigitalOut(true));
/*  76 */       spi.addDigitalOut(new SimpleDigitalOut(true));
/*     */       
/*  78 */       spi.addDigitalIn(new SimpleDigitalIn(false));
/*  79 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/*  80 */       spi.addDigitalIn(new SimpleDigitalIn(false));
/*  81 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/*     */       
/*  83 */       spi.addFile(new File(0, 10).setRecord(0, new Record(0, 10))
/*  84 */         .setRecord(1, new Record(1, 10))
/*  85 */         .setRecord(2, new Record(2, 10))
/*  86 */         .setRecord(3, new Record(3, 10))
/*  87 */         .setRecord(4, new Record(4, 10))
/*  88 */         .setRecord(5, new Record(5, 10))
/*  89 */         .setRecord(6, new Record(6, 10))
/*  90 */         .setRecord(7, new Record(7, 10))
/*  91 */         .setRecord(8, new Record(8, 10))
/*  92 */         .setRecord(9, new Record(9, 10)));
/*     */       
/*  94 */       spi.addFile(new File(1, 20)
/*  95 */         .setRecord(0, new Record(0, 10))
/*  96 */         .setRecord(1, new Record(1, 20))
/*  97 */         .setRecord(2, new Record(2, 20))
/*  98 */         .setRecord(3, new Record(3, 20))
/*  99 */         .setRecord(4, new Record(4, 20))
/* 100 */         .setRecord(5, new Record(5, 20))
/* 101 */         .setRecord(6, new Record(6, 20))
/* 102 */         .setRecord(7, new Record(7, 20))
/* 103 */         .setRecord(8, new Record(8, 20))
/* 104 */         .setRecord(9, new Record(9, 20))
/* 105 */         .setRecord(10, new Record(10, 10))
/* 106 */         .setRecord(11, new Record(11, 20))
/* 107 */         .setRecord(12, new Record(12, 20))
/* 108 */         .setRecord(13, new Record(13, 20))
/* 109 */         .setRecord(14, new Record(14, 20))
/* 110 */         .setRecord(15, new Record(15, 20))
/* 111 */         .setRecord(16, new Record(16, 20))
/* 112 */         .setRecord(17, new Record(17, 20))
/* 113 */         .setRecord(18, new Record(18, 20))
/* 114 */         .setRecord(19, new Record(19, 20)));
/*     */       
/*     */ 
/*     */ 
/* 118 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/* 119 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/* 120 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/* 121 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/*     */       
/* 123 */       spi.addRegister(new SimpleRegister(251));
/* 124 */       spi.addInputRegister(new SimpleInputRegister(45));
/*     */       
/*     */ 
/* 127 */       ModbusCoupler.getReference().setProcessImage(spi);
/* 128 */       ModbusCoupler.getReference().setMaster(false);
/* 129 */       ModbusCoupler.getReference().setUnitID(15);
/*     */       
/*     */ 
/* 132 */       if (Modbus.debug) {
/* 133 */         System.out.println("Listening...");
/*     */       }
/* 135 */       listener = new ModbusTCPListener(3, 
/* 136 */         Inet4Address.getByName("0.0.0.0"));
/* 137 */       listener.setPort(port);
/* 138 */       listener.setUnit(unit);
/* 139 */       listener.listen();
/*     */     }
/*     */     catch (Exception ex) {
/* 142 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\TCPSlaveTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */