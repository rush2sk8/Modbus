/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusException;
/*     */ import com.ghgande.j2mod.modbus.ModbusIOException;
/*     */ import com.ghgande.j2mod.modbus.ModbusSlaveException;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTCPTransaction;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransaction;
/*     */ import com.ghgande.j2mod.modbus.msg.ExceptionResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadFileRecordRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadFileRecordRequest.RecordRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadFileRecordResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadFileRecordResponse.RecordResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteFileRecordRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteFileRecordRequest.RecordRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteFileRecordResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteFileRecordResponse.RecordResponse;
/*     */ import com.ghgande.j2mod.modbus.net.TCPMasterConnection;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TCPWriteRecordTest
/*     */ {
/*     */   private static void usage()
/*     */   {
/*  69 */     System.out.println(
/*  70 */       "Usage: TCPWriteRecordTest address[:port[:unit]] file record registers [count]");
/*     */     
/*  72 */     System.exit(1);
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/*  76 */     InetAddress ipAddress = null;
/*  77 */     int port = 502;
/*  78 */     int unit = 0;
/*  79 */     TCPMasterConnection connection = null;
/*  80 */     ReadFileRecordRequest rdRequest = null;
/*  81 */     ReadFileRecordResponse rdResponse = null;
/*  82 */     WriteFileRecordRequest wrRequest = null;
/*  83 */     WriteFileRecordResponse wrResponse = null;
/*  84 */     ModbusTransaction trans = null;
/*  85 */     int file = 0;
/*  86 */     int record = 0;
/*  87 */     int registers = 0;
/*  88 */     int requestCount = 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  93 */     if ((args.length < 4) || (args.length > 5)) {
/*  94 */       usage();
/*     */     }
/*  96 */     String serverAddress = args[0];
/*  97 */     String[] parts = serverAddress.split(":");
/*  98 */     String hostName = parts[0];
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 112 */       if (parts.length > 1) {
/* 113 */         port = Integer.parseInt(parts[1]);
/*     */         
/* 115 */         if (parts.length > 2)
/* 116 */           unit = Integer.parseInt(parts[2]);
/*     */       }
/* 118 */       ipAddress = InetAddress.getByName(hostName);
/*     */       
/* 120 */       file = Integer.parseInt(args[1]);
/* 121 */       record = Integer.parseInt(args[2]);
/* 122 */       registers = Integer.parseInt(args[3]);
/*     */       
/* 124 */       if (args.length > 4)
/* 125 */         requestCount = Integer.parseInt(args[4]);
/*     */     } catch (NumberFormatException x) {
/* 127 */       System.err.println("Invalid parameter");
/* 128 */       usage();
/*     */     } catch (UnknownHostException x) {
/* 130 */       System.err.println("Unknown host: " + hostName);
/* 131 */       System.exit(1);
/*     */     } catch (Exception ex) {
/* 133 */       ex.printStackTrace();
/* 134 */       usage();
/* 135 */       System.exit(1);
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 143 */       connection = new TCPMasterConnection(ipAddress);
/* 144 */       connection.setPort(port);
/* 145 */       connection.connect();
/* 146 */       connection.setTimeout(500);
/*     */       
/* 148 */       if (Modbus.debug) {
/* 149 */         System.out.println("Connected to " + ipAddress.toString() + ":" + 
/* 150 */           connection.getPort());
/*     */       }
/* 152 */       for (int i = 0; i < requestCount; i++)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 157 */         rdRequest = new ReadFileRecordRequest();
/* 158 */         rdRequest.setUnitID(unit); ReadFileRecordRequest 
/*     */         
/*     */ 
/* 161 */           tmp312_310 = rdRequest;tmp312_310.getClass();ReadFileRecordRequest.RecordRequest recordRequest = new ReadFileRecordRequest.RecordRequest(tmp312_310, file, record + i, registers);
/* 162 */         rdRequest.addRequest(recordRequest);
/*     */         
/* 164 */         if (Modbus.debug) {
/* 165 */           System.out.println("Request: " + rdRequest.getHexMessage());
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 170 */         trans = new ModbusTCPTransaction(connection);
/* 171 */         trans.setRequest(rdRequest);
/*     */         
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 177 */           trans.execute();
/*     */         } catch (ModbusSlaveException x) {
/* 179 */           System.err.println("Slave Exception: " + 
/* 180 */             x.getLocalizedMessage());
/* 181 */           continue;
/*     */         } catch (ModbusIOException x) {
/* 183 */           System.err.println("I/O Exception: " + 
/* 184 */             x.getLocalizedMessage());
/* 185 */           continue;
/*     */         } catch (ModbusException x) {
/* 187 */           System.err.println("Modbus Exception: " + 
/* 188 */             x.getLocalizedMessage());
/* 189 */           continue;
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 194 */         wrRequest = new WriteFileRecordRequest();
/* 195 */         wrRequest.setUnitID(unit);
/*     */         
/* 197 */         ModbusResponse dummy = trans.getResponse();
/* 198 */         if (dummy == null) {
/* 199 */           System.err.println("No response for transaction " + i);
/*     */ 
/*     */         }
/* 202 */         else if ((dummy instanceof ExceptionResponse)) {
/* 203 */           ExceptionResponse exception = (ExceptionResponse)dummy;
/*     */           
/* 205 */           System.err.println(exception);
/*     */         }
/*     */         else {
/* 208 */           if ((dummy instanceof ReadFileRecordResponse)) {
/* 209 */             rdResponse = (ReadFileRecordResponse)dummy;
/*     */             
/* 211 */             if (Modbus.debug) {
/* 212 */               System.out.println("Response: " + 
/* 213 */                 rdResponse.getHexMessage());
/*     */             }
/* 215 */             int count = rdResponse.getRecordCount();
/* 216 */             for (int j = 0; j < count; j++) {
/* 217 */               ReadFileRecordResponse.RecordResponse data = rdResponse.getRecord(j);
/* 218 */               short[] values = new short[data.getWordCount()];
/* 219 */               for (int k = 0; k < data.getWordCount(); k++) {
/* 220 */                 values[k] = data.getRegister(k).toShort();
/*     */               }
/* 222 */               System.out.println("read data[" + j + "] = " + 
/* 223 */                 Arrays.toString(values)); WriteFileRecordRequest 
/*     */               
/*     */ 
/* 226 */                 tmp728_726 = wrRequest;tmp728_726.getClass();WriteFileRecordRequest.RecordRequest wrData = new WriteFileRecordRequest.RecordRequest(tmp728_726, file, record + i, values);
/* 227 */               wrRequest.addRequest(wrData);
/*     */             }
/*     */             
/*     */           }
/*     */           else
/*     */           {
/* 233 */             System.out.println(
/* 234 */               "Unknown Response: " + dummy.getHexMessage());
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 240 */           trans = new ModbusTCPTransaction(connection);
/* 241 */           trans.setRequest(wrRequest);
/*     */           
/*     */ 
/*     */ 
/*     */           try
/*     */           {
/* 247 */             trans.execute();
/*     */           } catch (ModbusSlaveException x) {
/* 249 */             System.err.println("Slave Exception: " + 
/* 250 */               x.getLocalizedMessage());
/* 251 */             continue;
/*     */           } catch (ModbusIOException x) {
/* 253 */             System.err.println("I/O Exception: " + 
/* 254 */               x.getLocalizedMessage());
/* 255 */             continue;
/*     */           } catch (ModbusException x) {
/* 257 */             System.err.println("Modbus Exception: " + 
/* 258 */               x.getLocalizedMessage());
/* 259 */             continue;
/*     */           }
/*     */           
/* 262 */           dummy = trans.getResponse();
/* 263 */           if (dummy == null) {
/* 264 */             System.err.println("No response for transaction " + i);
/*     */ 
/*     */           }
/* 267 */           else if ((dummy instanceof ExceptionResponse)) {
/* 268 */             ExceptionResponse exception = (ExceptionResponse)dummy;
/*     */             
/* 270 */             System.err.println(exception);
/*     */ 
/*     */           }
/* 273 */           else if ((dummy instanceof WriteFileRecordResponse)) {
/* 274 */             wrResponse = (WriteFileRecordResponse)dummy;
/*     */             
/* 276 */             if (Modbus.debug) {
/* 277 */               System.out.println("Response: " + 
/* 278 */                 wrResponse.getHexMessage());
/*     */             }
/* 280 */             int count = wrResponse.getRequestCount();
/* 281 */             for (int j = 0; j < count; j++) {
/* 282 */               WriteFileRecordResponse.RecordResponse data = 
/* 283 */                 wrResponse.getRecord(j);
/* 284 */               short[] values = new short[data.getWordCount()];
/* 285 */               for (int k = 0; k < data.getWordCount(); k++) {
/* 286 */                 values[k] = data.getRegister(k).toShort();
/*     */               }
/* 288 */               System.out.println("write response data[" + j + "] = " + 
/* 289 */                 Arrays.toString(values));
/*     */             }
/*     */             
/*     */           }
/*     */           else
/*     */           {
/* 295 */             System.out.println(
/* 296 */               "Unknown Response: " + dummy.getHexMessage());
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 303 */       connection.close();
/*     */     } catch (Exception ex) {
/* 305 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\TCPWriteRecordTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */