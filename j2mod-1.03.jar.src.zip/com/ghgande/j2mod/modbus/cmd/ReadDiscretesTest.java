/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTCPTransaction;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransaction;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransport;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputDiscretesRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputDiscretesResponse;
/*     */ import com.ghgande.j2mod.modbus.net.ModbusMasterFactory;
/*     */ import com.ghgande.j2mod.modbus.util.BitVector;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadDiscretesTest
/*     */ {
/*     */   private static void printUsage()
/*     */   {
/*  86 */     System.out.println(
/*  87 */       "java com.ghgande.j2mod.modbus.cmd.ReadDiscretesTest <connection [String]> <unit [int8]> <register [int16]> <bitcount [int16]> {<repeat [int]>}");
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/*  91 */     ReadInputDiscretesRequest req = null;
/*  92 */     ReadInputDiscretesResponse res = null;
/*  93 */     ModbusTransport transport = null;
/*  94 */     ModbusTransaction trans = null;
/*  95 */     int ref = 0;
/*  96 */     int count = 0;
/*  97 */     int repeat = 1;
/*  98 */     int unit = 0;
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 103 */       if ((args.length < 4) || (args.length > 5)) {
/* 104 */         printUsage();
/* 105 */         System.exit(1);
/*     */       } else {
/*     */         try {
/* 108 */           transport = ModbusMasterFactory.createModbusMaster(args[0]);
/* 109 */           unit = Integer.parseInt(args[1]);
/* 110 */           ref = Integer.parseInt(args[2]);
/* 111 */           count = Integer.parseInt(args[3]);
/* 112 */           if (args.length == 5) {
/* 113 */             repeat = Integer.parseInt(args[4]);
/*     */           }
/*     */         } catch (Exception ex) {
/* 116 */           ex.printStackTrace();
/* 117 */           printUsage();
/* 118 */           System.exit(1);
/*     */         }
/*     */       }
/*     */       
/* 122 */       req = new ReadInputDiscretesRequest(ref, count);
/* 123 */       req.setUnitID(unit);
/* 124 */       if (Modbus.debug) {
/* 125 */         System.out.println("Request: " + req.getHexMessage());
/*     */       }
/*     */       
/* 128 */       trans = transport.createTransaction();
/* 129 */       trans.setRequest(req);
/*     */       
/* 131 */       if ((trans instanceof ModbusTCPTransaction)) {
/* 132 */         ((ModbusTCPTransaction)trans).setReconnecting(true);
/*     */       }
/*     */       
/* 135 */       int k = 0;
/*     */       do {
/* 137 */         trans.execute();
/*     */         
/* 139 */         res = (ReadInputDiscretesResponse)trans.getResponse();
/*     */         
/* 141 */         if (Modbus.debug) {
/* 142 */           System.out.println("Response: " + res.getHexMessage());
/*     */         }
/* 144 */         System.out.println("Input Discretes Status=" + 
/* 145 */           res.getDiscretes().toString());
/*     */         
/* 147 */         k++;
/* 136 */       } while (
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 148 */         k < repeat);
/*     */       
/*     */ 
/* 151 */       transport.close();
/*     */     }
/*     */     catch (Exception ex) {
/* 154 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\ReadDiscretesTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */