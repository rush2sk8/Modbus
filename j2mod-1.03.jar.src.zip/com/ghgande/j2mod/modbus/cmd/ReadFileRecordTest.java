/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusException;
/*     */ import com.ghgande.j2mod.modbus.ModbusIOException;
/*     */ import com.ghgande.j2mod.modbus.ModbusSlaveException;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransaction;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransport;
/*     */ import com.ghgande.j2mod.modbus.msg.ExceptionResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadFileRecordRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadFileRecordRequest.RecordRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadFileRecordResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadFileRecordResponse.RecordResponse;
/*     */ import com.ghgande.j2mod.modbus.net.ModbusMasterFactory;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadFileRecordTest
/*     */ {
/*     */   private static void usage()
/*     */   {
/*  65 */     System.out.println(
/*  66 */       "Usage: ReadFileRecord connection unit file record registers [repeat]");
/*     */     
/*  68 */     System.exit(1);
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/*  72 */     ModbusTransport transport = null;
/*  73 */     ReadFileRecordRequest request = null;
/*  74 */     ReadFileRecordResponse response = null;
/*  75 */     ModbusTransaction trans = null;
/*  76 */     int unit = 0;
/*  77 */     int file = 0;
/*  78 */     int record = 0;
/*  79 */     int registers = 0;
/*  80 */     int requestCount = 1;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  85 */     if ((args.length < 5) || (args.length > 6)) {
/*  86 */       usage();
/*     */     }
/*     */     try {
/*  89 */       transport = ModbusMasterFactory.createModbusMaster(args[0]);
/*  90 */       unit = Integer.parseInt(args[1]);
/*  91 */       file = Integer.parseInt(args[2]);
/*  92 */       record = Integer.parseInt(args[3]);
/*  93 */       registers = Integer.parseInt(args[4]);
/*     */       
/*  95 */       if (args.length > 5)
/*  96 */         requestCount = Integer.parseInt(args[5]);
/*     */     } catch (NumberFormatException x) {
/*  98 */       System.err.println("Invalid parameter");
/*  99 */       usage();
/*     */     } catch (Exception ex) {
/* 101 */       ex.printStackTrace();
/* 102 */       usage();
/* 103 */       System.exit(1);
/*     */     }
/*     */     try
/*     */     {
/* 107 */       for (int i = 0; i < requestCount; i++)
/*     */       {
/*     */ 
/*     */ 
/*     */ 
/* 112 */         request = new ReadFileRecordRequest();
/* 113 */         request.setUnitID(unit); ReadFileRecordRequest 
/*     */         
/*     */ 
/* 116 */           tmp151_150 = request;tmp151_150.getClass();ReadFileRecordRequest.RecordRequest recordRequest = new ReadFileRecordRequest.RecordRequest(tmp151_150, file, record + i, registers);
/* 117 */         request.addRequest(recordRequest);
/*     */         
/* 119 */         if (Modbus.debug) {
/* 120 */           System.out.println("Request: " + request.getHexMessage());
/*     */         }
/*     */         
/*     */ 
/*     */ 
/* 125 */         trans = transport.createTransaction();
/* 126 */         trans.setRequest(request);
/*     */         
/*     */ 
/*     */ 
/*     */         try
/*     */         {
/* 132 */           trans.execute();
/*     */         } catch (ModbusSlaveException x) {
/* 134 */           System.err.println("Slave Exception: " + 
/* 135 */             x.getLocalizedMessage());
/* 136 */           continue;
/*     */         } catch (ModbusIOException x) {
/* 138 */           System.err.println("I/O Exception: " + 
/* 139 */             x.getLocalizedMessage());
/* 140 */           continue;
/*     */         } catch (ModbusException x) {
/* 142 */           System.err.println("Modbus Exception: " + 
/* 143 */             x.getLocalizedMessage());
/* 144 */           continue;
/*     */         }
/*     */         
/* 147 */         ModbusResponse dummy = trans.getResponse();
/* 148 */         if (dummy == null) {
/* 149 */           System.err.println("No response for transaction " + i);
/*     */ 
/*     */         }
/* 152 */         else if ((dummy instanceof ExceptionResponse)) {
/* 153 */           ExceptionResponse exception = (ExceptionResponse)dummy;
/*     */           
/* 155 */           System.err.println(exception);
/*     */ 
/*     */         }
/* 158 */         else if ((dummy instanceof ReadFileRecordResponse)) {
/* 159 */           response = (ReadFileRecordResponse)dummy;
/*     */           
/* 161 */           if (Modbus.debug) {
/* 162 */             System.out.println("Response: " + 
/* 163 */               response.getHexMessage());
/*     */           }
/* 165 */           int count = response.getRecordCount();
/* 166 */           for (int j = 0; j < count; j++) {
/* 167 */             ReadFileRecordResponse.RecordResponse data = response.getRecord(j);
/* 168 */             short[] values = new short[data.getWordCount()];
/* 169 */             for (int k = 0; k < data.getWordCount(); k++) {
/* 170 */               values[k] = data.getRegister(k).toShort();
/*     */             }
/* 172 */             System.out.println("data[" + i + "][" + j + "] = " + 
/* 173 */               Arrays.toString(values));
/*     */           }
/*     */           
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 181 */           System.out.println(
/* 182 */             "Unknown Response: " + dummy.getHexMessage());
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 188 */       transport.close();
/*     */     } catch (Exception ex) {
/* 190 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\ReadFileRecordTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */