/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.net.ModbusSerialListener;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleDigitalIn;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleDigitalOut;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleInputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import com.ghgande.j2mod.modbus.util.SerialParameters;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerialSlaveTest
/*     */ {
/*     */   public static void main(String[] args)
/*     */   {
/*  53 */     ModbusSerialListener listener = null;
/*  54 */     SimpleProcessImage spi = new SimpleProcessImage();
/*  55 */     String portname = args[0];
/*     */     
/*  57 */     if (Modbus.debug) {
/*  58 */       System.out.println("j2mod ModbusSerial Slave");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/*  70 */       spi = new SimpleProcessImage();
/*  71 */       spi.addDigitalOut(new SimpleDigitalOut(true));
/*  72 */       spi.addDigitalOut(new SimpleDigitalOut(false));
/*  73 */       spi.addDigitalIn(new SimpleDigitalIn(false));
/*  74 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/*  75 */       spi.addDigitalIn(new SimpleDigitalIn(false));
/*  76 */       spi.addDigitalIn(new SimpleDigitalIn(true));
/*     */       
/*  78 */       spi.addRegister(new SimpleRegister(251));
/*  79 */       spi.addInputRegister(new SimpleInputRegister(45));
/*     */       
/*     */ 
/*  82 */       ModbusCoupler.getReference().setProcessImage(spi);
/*  83 */       ModbusCoupler.getReference().setMaster(false);
/*  84 */       ModbusCoupler.getReference().setUnitID(2);
/*     */       
/*     */ 
/*  87 */       SerialParameters params = new SerialParameters();
/*     */       
/*  89 */       params.setPortName(portname);
/*  90 */       params.setBaudRate(9600);
/*  91 */       params.setDatabits(8);
/*  92 */       params.setParity("None");
/*  93 */       params.setStopbits(1);
/*  94 */       params.setEncoding("rtu");
/*  95 */       params.setEcho(false);
/*  96 */       if (Modbus.debug) {
/*  97 */         System.out.println("Encoding [" + params.getEncoding() + "]");
/*     */       }
/*     */       
/* 100 */       listener = new ModbusSerialListener(params);
/* 101 */       listener.setListening(true);
/*     */       
/*     */ 
/* 104 */       new Thread(listener).start();
/*     */     } catch (Exception ex) {
/* 106 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\SerialSlaveTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */