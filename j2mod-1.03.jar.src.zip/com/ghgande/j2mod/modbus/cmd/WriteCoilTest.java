/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransaction;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransport;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteCoilRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteCoilResponse;
/*     */ import com.ghgande.j2mod.modbus.net.ModbusMasterFactory;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class WriteCoilTest
/*     */ {
/*     */   private static void printUsage()
/*     */   {
/*  69 */     System.out.println("java com.ghgande.j2mod.modbus.cmd.WriteCoilTest <connection [String]> <unit [int8]> <coil [int16]> <state [boolean]> {<repeat [int]>}");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  78 */     WriteCoilRequest req = null;
/*  79 */     ModbusTransport transport = null;
/*  80 */     ModbusTransaction trans = null;
/*  81 */     int ref = 0;
/*  82 */     boolean value = false;
/*  83 */     int repeat = 1;
/*  84 */     int unit = 0;
/*     */     
/*     */ 
/*  87 */     if (args.length < 4) {
/*  88 */       printUsage();
/*  89 */       System.exit(1);
/*     */     }
/*     */     try {
/*     */       try {
/*  93 */         transport = ModbusMasterFactory.createModbusMaster(args[0]);
/*  94 */         unit = Integer.parseInt(args[1]);
/*  95 */         ref = Integer.parseInt(args[2]);
/*  96 */         value = "true".equals(args[3]);
/*  97 */         if (args.length == 5) {
/*  98 */           repeat = Integer.parseInt(args[4]);
/*     */         }
/*     */       } catch (Exception ex) {
/* 101 */         ex.printStackTrace();
/* 102 */         printUsage();
/* 103 */         System.exit(1);
/*     */       }
/*     */       
/*     */ 
/* 107 */       req = new WriteCoilRequest(ref, value);
/* 108 */       req.setUnitID(unit);
/* 109 */       if (Modbus.debug) {
/* 110 */         System.out.println("Request: " + req.getHexMessage());
/*     */       }
/*     */       
/* 113 */       trans = transport.createTransaction();
/* 114 */       trans.setRequest(req);
/*     */       
/*     */ 
/* 117 */       for (int count = 0; count < repeat; count++) {
/* 118 */         trans.execute();
/*     */         
/* 120 */         if (Modbus.debug) {
/* 121 */           System.out.println("Response: " + 
/* 122 */             trans.getResponse().getHexMessage());
/*     */         }
/* 124 */         WriteCoilResponse data = (WriteCoilResponse)trans.getResponse();
/* 125 */         System.out.println("Coil = " + data.getCoil());
/*     */       }
/*     */       
/*     */ 
/* 129 */       transport.close();
/*     */     }
/*     */     catch (Exception ex) {
/* 132 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\WriteCoilTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */