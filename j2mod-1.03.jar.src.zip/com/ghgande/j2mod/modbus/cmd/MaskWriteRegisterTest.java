/*    */ package com.ghgande.j2mod.modbus.cmd;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MaskWriteRegisterTest
/*    */ {
/*    */   private static void printUsage()
/*    */   {
/* 73 */     System.out.println("java com.ghgande.j2mod.modbus.cmd.WriteHoldingRegisterTest <address{:<port>{:<unit>}} [String]> <register [int]> <andMask [int]> <orMask [int]> {<repeat [int]>}");
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public static void main(String[] args)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aconst_null
/*    */     //   1: astore_1
/*    */     //   2: aconst_null
/*    */     //   3: astore_2
/*    */     //   4: aconst_null
/*    */     //   5: astore_3
/*    */     //   6: iconst_0
/*    */     //   7: istore 4
/*    */     //   9: ldc 31
/*    */     //   11: istore 5
/*    */     //   13: iconst_0
/*    */     //   14: istore 6
/*    */     //   16: iconst_1
/*    */     //   17: istore 7
/*    */     //   19: iconst_0
/*    */     //   20: istore 8
/*    */     //   22: aload_0
/*    */     //   23: arraylength
/*    */     //   24: iconst_3
/*    */     //   25: if_icmpge +10 -> 35
/*    */     //   28: invokestatic 32	com/ghgande/j2mod/modbus/cmd/MaskWriteRegisterTest:printUsage	()V
/*    */     //   31: iconst_1
/*    */     //   32: invokestatic 34	java/lang/System:exit	(I)V
/*    */     //   35: aload_0
/*    */     //   36: iconst_1
/*    */     //   37: aaload
/*    */     //   38: invokestatic 38	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*    */     //   41: istore 4
/*    */     //   43: aload_0
/*    */     //   44: iconst_2
/*    */     //   45: aaload
/*    */     //   46: invokestatic 38	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*    */     //   49: istore 5
/*    */     //   51: aload_0
/*    */     //   52: iconst_3
/*    */     //   53: aaload
/*    */     //   54: invokestatic 38	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*    */     //   57: istore 6
/*    */     //   59: aload_0
/*    */     //   60: arraylength
/*    */     //   61: iconst_5
/*    */     //   62: if_icmpne +28 -> 90
/*    */     //   65: aload_0
/*    */     //   66: iconst_4
/*    */     //   67: aaload
/*    */     //   68: invokestatic 38	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*    */     //   71: istore 7
/*    */     //   73: goto +17 -> 90
/*    */     //   76: astore 9
/*    */     //   78: aload 9
/*    */     //   80: invokevirtual 44	java/lang/Exception:printStackTrace	()V
/*    */     //   83: invokestatic 32	com/ghgande/j2mod/modbus/cmd/MaskWriteRegisterTest:printUsage	()V
/*    */     //   86: iconst_1
/*    */     //   87: invokestatic 34	java/lang/System:exit	(I)V
/*    */     //   90: aload_0
/*    */     //   91: iconst_0
/*    */     //   92: aaload
/*    */     //   93: invokestatic 49	com/ghgande/j2mod/modbus/net/ModbusMasterFactory:createModbusMaster	(Ljava/lang/String;)Lcom/ghgande/j2mod/modbus/io/ModbusTransport;
/*    */     //   96: astore_1
/*    */     //   97: getstatic 55	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*    */     //   100: ifeq +25 -> 125
/*    */     //   103: getstatic 15	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   106: new 61	java/lang/StringBuilder
/*    */     //   109: dup
/*    */     //   110: ldc 63
/*    */     //   112: invokespecial 65	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*    */     //   115: aload_1
/*    */     //   116: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*    */     //   119: invokevirtual 71	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*    */     //   122: invokevirtual 23	java/io/PrintStream:println	(Ljava/lang/String;)V
/*    */     //   125: new 75	com/ghgande/j2mod/modbus/msg/MaskWriteRegisterRequest
/*    */     //   128: dup
/*    */     //   129: iload 4
/*    */     //   131: iload 5
/*    */     //   133: iload 6
/*    */     //   135: invokespecial 77	com/ghgande/j2mod/modbus/msg/MaskWriteRegisterRequest:<init>	(III)V
/*    */     //   138: astore_2
/*    */     //   139: aload_2
/*    */     //   140: iload 8
/*    */     //   142: invokevirtual 80	com/ghgande/j2mod/modbus/msg/ModbusRequest:setUnitID	(I)V
/*    */     //   145: getstatic 55	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*    */     //   148: ifeq +28 -> 176
/*    */     //   151: getstatic 15	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   154: new 61	java/lang/StringBuilder
/*    */     //   157: dup
/*    */     //   158: ldc 85
/*    */     //   160: invokespecial 65	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*    */     //   163: aload_2
/*    */     //   164: invokevirtual 87	com/ghgande/j2mod/modbus/msg/ModbusRequest:getHexMessage	()Ljava/lang/String;
/*    */     //   167: invokevirtual 90	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   170: invokevirtual 71	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*    */     //   173: invokevirtual 23	java/io/PrintStream:println	(Ljava/lang/String;)V
/*    */     //   176: aload_1
/*    */     //   177: invokeinterface 93 1 0
/*    */     //   182: astore_3
/*    */     //   183: aload_3
/*    */     //   184: aload_2
/*    */     //   185: invokeinterface 99 2 0
/*    */     //   190: iconst_0
/*    */     //   191: istore 9
/*    */     //   193: goto +48 -> 241
/*    */     //   196: aload_3
/*    */     //   197: invokeinterface 105 1 0
/*    */     //   202: getstatic 55	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*    */     //   205: ifeq +33 -> 238
/*    */     //   208: getstatic 15	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   211: new 61	java/lang/StringBuilder
/*    */     //   214: dup
/*    */     //   215: ldc 108
/*    */     //   217: invokespecial 65	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*    */     //   220: aload_3
/*    */     //   221: invokeinterface 110 1 0
/*    */     //   226: invokevirtual 114	com/ghgande/j2mod/modbus/msg/ModbusResponse:getHexMessage	()Ljava/lang/String;
/*    */     //   229: invokevirtual 90	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   232: invokevirtual 71	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*    */     //   235: invokevirtual 23	java/io/PrintStream:println	(Ljava/lang/String;)V
/*    */     //   238: iinc 9 1
/*    */     //   241: iload 9
/*    */     //   243: iload 7
/*    */     //   245: if_icmplt -49 -> 196
/*    */     //   248: goto +40 -> 288
/*    */     //   251: astore 9
/*    */     //   253: aload 9
/*    */     //   255: invokevirtual 44	java/lang/Exception:printStackTrace	()V
/*    */     //   258: aload_1
/*    */     //   259: invokeinterface 117 1 0
/*    */     //   264: goto +35 -> 299
/*    */     //   267: astore 11
/*    */     //   269: goto +30 -> 299
/*    */     //   272: astore 10
/*    */     //   274: aload_1
/*    */     //   275: invokeinterface 117 1 0
/*    */     //   280: goto +5 -> 285
/*    */     //   283: astore 11
/*    */     //   285: aload 10
/*    */     //   287: athrow
/*    */     //   288: aload_1
/*    */     //   289: invokeinterface 117 1 0
/*    */     //   294: goto +5 -> 299
/*    */     //   297: astore 11
/*    */     //   299: return
/*    */     // Line number table:
/*    */     //   Java source line #80	-> byte code offset #0
/*    */     //   Java source line #81	-> byte code offset #2
/*    */     //   Java source line #82	-> byte code offset #4
/*    */     //   Java source line #83	-> byte code offset #6
/*    */     //   Java source line #84	-> byte code offset #9
/*    */     //   Java source line #85	-> byte code offset #13
/*    */     //   Java source line #86	-> byte code offset #16
/*    */     //   Java source line #87	-> byte code offset #19
/*    */     //   Java source line #90	-> byte code offset #22
/*    */     //   Java source line #91	-> byte code offset #28
/*    */     //   Java source line #92	-> byte code offset #31
/*    */     //   Java source line #97	-> byte code offset #35
/*    */     //   Java source line #98	-> byte code offset #43
/*    */     //   Java source line #99	-> byte code offset #51
/*    */     //   Java source line #101	-> byte code offset #59
/*    */     //   Java source line #102	-> byte code offset #65
/*    */     //   Java source line #103	-> byte code offset #73
/*    */     //   Java source line #104	-> byte code offset #78
/*    */     //   Java source line #105	-> byte code offset #83
/*    */     //   Java source line #106	-> byte code offset #86
/*    */     //   Java source line #110	-> byte code offset #90
/*    */     //   Java source line #112	-> byte code offset #97
/*    */     //   Java source line #113	-> byte code offset #103
/*    */     //   Java source line #115	-> byte code offset #125
/*    */     //   Java source line #117	-> byte code offset #139
/*    */     //   Java source line #118	-> byte code offset #145
/*    */     //   Java source line #119	-> byte code offset #151
/*    */     //   Java source line #122	-> byte code offset #176
/*    */     //   Java source line #123	-> byte code offset #183
/*    */     //   Java source line #127	-> byte code offset #190
/*    */     //   Java source line #128	-> byte code offset #196
/*    */     //   Java source line #130	-> byte code offset #202
/*    */     //   Java source line #131	-> byte code offset #208
/*    */     //   Java source line #132	-> byte code offset #220
/*    */     //   Java source line #131	-> byte code offset #235
/*    */     //   Java source line #127	-> byte code offset #238
/*    */     //   Java source line #134	-> byte code offset #248
/*    */     //   Java source line #135	-> byte code offset #253
/*    */     //   Java source line #138	-> byte code offset #258
/*    */     //   Java source line #139	-> byte code offset #264
/*    */     //   Java source line #136	-> byte code offset #272
/*    */     //   Java source line #138	-> byte code offset #274
/*    */     //   Java source line #139	-> byte code offset #280
/*    */     //   Java source line #142	-> byte code offset #285
/*    */     //   Java source line #138	-> byte code offset #288
/*    */     //   Java source line #139	-> byte code offset #294
/*    */     //   Java source line #143	-> byte code offset #299
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	300	0	args	String[]
/*    */     //   1	288	1	transport	com.ghgande.j2mod.modbus.io.ModbusTransport
/*    */     //   3	182	2	req	com.ghgande.j2mod.modbus.msg.ModbusRequest
/*    */     //   5	216	3	trans	com.ghgande.j2mod.modbus.io.ModbusTransaction
/*    */     //   7	123	4	ref	int
/*    */     //   11	121	5	andMask	int
/*    */     //   14	120	6	orMask	int
/*    */     //   17	227	7	repeat	int
/*    */     //   20	121	8	unit	int
/*    */     //   76	3	9	ex	Exception
/*    */     //   191	51	9	count	int
/*    */     //   251	3	9	ex	Exception
/*    */     //   272	14	10	localObject	Object
/*    */     //   267	1	11	localIOException	java.io.IOException
/*    */     //   283	1	11	localIOException1	java.io.IOException
/*    */     //   297	1	11	localIOException2	java.io.IOException
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   35	73	76	java/lang/Exception
/*    */     //   35	248	251	java/lang/Exception
/*    */     //   258	264	267	java/io/IOException
/*    */     //   35	258	272	finally
/*    */     //   274	280	283	java/io/IOException
/*    */     //   288	294	297	java/io/IOException
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\MaskWriteRegisterTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */