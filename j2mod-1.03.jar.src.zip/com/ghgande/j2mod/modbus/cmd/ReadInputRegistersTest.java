/*     */ package com.ghgande.j2mod.modbus.cmd;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusException;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusRTUTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusSerialTransaction;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusSerialTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTCPTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransaction;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransport;
/*     */ import com.ghgande.j2mod.modbus.msg.ExceptionResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputRegistersRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputRegistersResponse;
/*     */ import com.ghgande.j2mod.modbus.net.ModbusMasterFactory;
/*     */ import com.ghgande.j2mod.modbus.procimg.InputRegister;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReadInputRegistersTest
/*     */ {
/*     */   private static void printUsage()
/*     */   {
/* 115 */     System.out.println("java com.ghgande.j2mod.modbus.cmd.ReadInputRegistersTest <address{:port{:unit}} [String]> <base [int]> <count [int]> {<repeat [int]>}");
/*     */   }
/*     */   
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 121 */     ModbusTransport transport = null;
/* 122 */     ModbusRequest req = null;
/* 123 */     ModbusTransaction trans = null;
/* 124 */     int ref = 0;
/* 125 */     int count = 0;
/* 126 */     int repeat = 1;
/* 127 */     int unit = 0;
/*     */     
/*     */ 
/* 130 */     if (args.length < 3) {
/* 131 */       printUsage();
/* 132 */       System.exit(1);
/*     */     }
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/* 138 */         transport = ModbusMasterFactory.createModbusMaster(args[0]);
/* 139 */         if (transport == null) {
/* 140 */           System.err.println("Cannot open " + args[0]);
/* 141 */           System.exit(1);
/*     */         }
/*     */         
/* 144 */         if ((transport instanceof ModbusSerialTransport)) {
/* 145 */           ((ModbusSerialTransport)transport).setReceiveTimeout(500);
/* 146 */           ((ModbusSerialTransport)transport).setBaudRate(19200);
/*     */         }
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 153 */         Thread.sleep(2000L);
/*     */         
/* 155 */         ref = Integer.parseInt(args[1]);
/* 156 */         count = Integer.parseInt(args[2]);
/*     */         
/* 158 */         if (args.length > 3) {
/* 159 */           repeat = Integer.parseInt(args[3]);
/*     */         }
/* 161 */         if ((transport instanceof ModbusTCPTransport)) {
/* 162 */           String[] parts = args[0].split(":");
/* 163 */           if (parts.length >= 4)
/* 164 */             unit = Integer.parseInt(parts[3]);
/* 165 */         } else if ((transport instanceof ModbusRTUTransport)) {
/* 166 */           String[] parts = args[0].split(":");
/* 167 */           if (parts.length >= 3)
/* 168 */             unit = Integer.parseInt(parts[2]);
/*     */         }
/*     */       } catch (Exception ex) {
/* 171 */         ex.printStackTrace();
/* 172 */         printUsage();
/* 173 */         System.exit(1);
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 178 */       for (int k = 0; k < repeat; k++) {
/* 179 */         System.err.println("try " + k);
/*     */         
/* 181 */         req = new ReadInputRegistersRequest(ref, count);
/* 182 */         req.setUnitID(unit);
/* 183 */         req.setHeadless(trans instanceof ModbusSerialTransaction);
/*     */         
/* 185 */         if (Modbus.debug) {
/* 186 */           System.out.println("Request: " + req.getHexMessage());
/*     */         }
/*     */         
/* 189 */         trans = transport.createTransaction();
/* 190 */         trans.setRequest(req);
/* 191 */         trans.setRetries(1);
/*     */         
/* 193 */         if ((trans instanceof ModbusSerialTransaction))
/*     */         {
/*     */ 
/*     */ 
/* 197 */           ((ModbusSerialTransaction)trans).setTransDelayMS(10);
/*     */         }
/*     */         try
/*     */         {
/* 201 */           trans.execute();
/*     */         } catch (ModbusException x) {
/* 203 */           System.err.println(x.getMessage());
/* 204 */           continue;
/*     */         }
/* 206 */         ModbusResponse res = trans.getResponse();
/*     */         
/* 208 */         if (Modbus.debug) {
/* 209 */           if (res != null) {
/* 210 */             System.out.println("Response: " + res.getHexMessage());
/*     */           } else
/* 212 */             System.err.println("No response to READ INPUT request.");
/*     */         }
/* 214 */         if ((res instanceof ExceptionResponse)) {
/* 215 */           ExceptionResponse exception = (ExceptionResponse)res;
/* 216 */           System.out.println(exception);
/*     */ 
/*     */ 
/*     */         }
/* 220 */         else if ((res instanceof ReadInputRegistersResponse))
/*     */         {
/*     */ 
/* 223 */           ReadInputRegistersResponse data = (ReadInputRegistersResponse)res;
/* 224 */           InputRegister[] values = data.getRegisters();
/*     */           
/* 226 */           System.out.println("Data: " + Arrays.toString(values));
/*     */         }
/*     */       }
/* 229 */     } catch (Exception ex) { ex.printStackTrace();
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 234 */       if (transport != null) {
/* 235 */         transport.close();
/*     */       }
/*     */     }
/*     */     catch (IOException localIOException) {}
/* 239 */     System.exit(0);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\ReadInputRegistersTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */