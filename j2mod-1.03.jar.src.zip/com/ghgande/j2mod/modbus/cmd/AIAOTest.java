/*    */ package com.ghgande.j2mod.modbus.cmd;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AIAOTest
/*    */ {
/*    */   private static void printUsage()
/*    */   {
/* 73 */     System.out.println("java com.ghgande.j2mod.modbus.cmd.AIAOTest <address{:<port>} [String]> <register a_in [int16]> <register a_out [int16]>");
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public static void main(String[] args)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aconst_null
/*    */     //   1: astore_1
/*    */     //   2: aconst_null
/*    */     //   3: astore_2
/*    */     //   4: aconst_null
/*    */     //   5: astore_3
/*    */     //   6: aconst_null
/*    */     //   7: astore 4
/*    */     //   9: aconst_null
/*    */     //   10: astore 5
/*    */     //   12: aconst_null
/*    */     //   13: astore 6
/*    */     //   15: iconst_0
/*    */     //   16: istore 7
/*    */     //   18: iconst_0
/*    */     //   19: istore 8
/*    */     //   21: sipush 502
/*    */     //   24: istore 9
/*    */     //   26: iconst_0
/*    */     //   27: istore 10
/*    */     //   29: iconst_0
/*    */     //   30: istore 11
/*    */     //   32: aload_0
/*    */     //   33: arraylength
/*    */     //   34: iconst_3
/*    */     //   35: if_icmpge +10 -> 45
/*    */     //   38: invokestatic 31	com/ghgande/j2mod/modbus/cmd/AIAOTest:printUsage	()V
/*    */     //   41: iconst_1
/*    */     //   42: invokestatic 33	java/lang/System:exit	(I)V
/*    */     //   45: aload_0
/*    */     //   46: iconst_0
/*    */     //   47: aaload
/*    */     //   48: astore 12
/*    */     //   50: aload 12
/*    */     //   52: ldc 37
/*    */     //   54: invokevirtual 39	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
/*    */     //   57: astore 13
/*    */     //   59: aload 13
/*    */     //   61: iconst_0
/*    */     //   62: aaload
/*    */     //   63: astore 14
/*    */     //   65: aload 13
/*    */     //   67: arraylength
/*    */     //   68: iconst_1
/*    */     //   69: if_icmple +47 -> 116
/*    */     //   72: aload 13
/*    */     //   74: iconst_1
/*    */     //   75: aaload
/*    */     //   76: invokestatic 45	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*    */     //   79: istore 9
/*    */     //   81: aload 13
/*    */     //   83: arraylength
/*    */     //   84: iconst_2
/*    */     //   85: if_icmple +31 -> 116
/*    */     //   88: aload 13
/*    */     //   90: iconst_2
/*    */     //   91: aaload
/*    */     //   92: invokestatic 45	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*    */     //   95: dup
/*    */     //   96: istore 11
/*    */     //   98: istore 10
/*    */     //   100: aload 13
/*    */     //   102: arraylength
/*    */     //   103: iconst_3
/*    */     //   104: if_icmple +12 -> 116
/*    */     //   107: aload 13
/*    */     //   109: iconst_3
/*    */     //   110: aaload
/*    */     //   111: invokestatic 45	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*    */     //   114: istore 11
/*    */     //   116: aload 14
/*    */     //   118: invokestatic 51	java/net/InetAddress:getByName	(Ljava/lang/String;)Ljava/net/InetAddress;
/*    */     //   121: astore_1
/*    */     //   122: aload_0
/*    */     //   123: iconst_1
/*    */     //   124: aaload
/*    */     //   125: invokestatic 45	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*    */     //   128: istore 7
/*    */     //   130: aload_0
/*    */     //   131: iconst_2
/*    */     //   132: aaload
/*    */     //   133: invokestatic 45	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*    */     //   136: istore 8
/*    */     //   138: goto +17 -> 155
/*    */     //   141: astore 12
/*    */     //   143: aload 12
/*    */     //   145: invokevirtual 57	java/lang/Exception:printStackTrace	()V
/*    */     //   148: invokestatic 31	com/ghgande/j2mod/modbus/cmd/AIAOTest:printUsage	()V
/*    */     //   151: iconst_1
/*    */     //   152: invokestatic 33	java/lang/System:exit	(I)V
/*    */     //   155: new 62	com/ghgande/j2mod/modbus/net/TCPMasterConnection
/*    */     //   158: dup
/*    */     //   159: aload_1
/*    */     //   160: invokespecial 64	com/ghgande/j2mod/modbus/net/TCPMasterConnection:<init>	(Ljava/net/InetAddress;)V
/*    */     //   163: astore_2
/*    */     //   164: aload_2
/*    */     //   165: iload 9
/*    */     //   167: invokevirtual 67	com/ghgande/j2mod/modbus/net/TCPMasterConnection:setPort	(I)V
/*    */     //   170: aload_2
/*    */     //   171: invokevirtual 70	com/ghgande/j2mod/modbus/net/TCPMasterConnection:connect	()V
/*    */     //   174: getstatic 73	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*    */     //   177: ifeq +40 -> 217
/*    */     //   180: getstatic 15	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   183: new 79	java/lang/StringBuilder
/*    */     //   186: dup
/*    */     //   187: ldc 81
/*    */     //   189: invokespecial 83	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*    */     //   192: aload_1
/*    */     //   193: invokevirtual 85	java/net/InetAddress:toString	()Ljava/lang/String;
/*    */     //   196: invokevirtual 89	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   199: ldc 37
/*    */     //   201: invokevirtual 89	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   204: aload_2
/*    */     //   205: invokevirtual 93	com/ghgande/j2mod/modbus/net/TCPMasterConnection:getPort	()I
/*    */     //   208: invokevirtual 97	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
/*    */     //   211: invokevirtual 100	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*    */     //   214: invokevirtual 23	java/io/PrintStream:println	(Ljava/lang/String;)V
/*    */     //   217: new 101	com/ghgande/j2mod/modbus/msg/ReadInputRegistersRequest
/*    */     //   220: dup
/*    */     //   221: iload 7
/*    */     //   223: iconst_1
/*    */     //   224: invokespecial 103	com/ghgande/j2mod/modbus/msg/ReadInputRegistersRequest:<init>	(II)V
/*    */     //   227: astore_3
/*    */     //   228: new 106	com/ghgande/j2mod/modbus/msg/WriteSingleRegisterRequest
/*    */     //   231: dup
/*    */     //   232: invokespecial 108	com/ghgande/j2mod/modbus/msg/WriteSingleRegisterRequest:<init>	()V
/*    */     //   235: astore 4
/*    */     //   237: aload 4
/*    */     //   239: iload 8
/*    */     //   241: invokevirtual 109	com/ghgande/j2mod/modbus/msg/WriteSingleRegisterRequest:setReference	(I)V
/*    */     //   244: aload_3
/*    */     //   245: iload 10
/*    */     //   247: invokevirtual 112	com/ghgande/j2mod/modbus/msg/ModbusRequest:setUnitID	(I)V
/*    */     //   250: aload 4
/*    */     //   252: iload 11
/*    */     //   254: invokevirtual 117	com/ghgande/j2mod/modbus/msg/WriteSingleRegisterRequest:setUnitID	(I)V
/*    */     //   257: new 118	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction
/*    */     //   260: dup
/*    */     //   261: aload_2
/*    */     //   262: invokespecial 120	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction:<init>	(Lcom/ghgande/j2mod/modbus/net/TCPMasterConnection;)V
/*    */     //   265: astore 5
/*    */     //   267: aload 5
/*    */     //   269: aload_3
/*    */     //   270: invokeinterface 123 2 0
/*    */     //   275: new 118	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction
/*    */     //   278: dup
/*    */     //   279: aload_2
/*    */     //   280: invokespecial 120	com/ghgande/j2mod/modbus/io/ModbusTCPTransaction:<init>	(Lcom/ghgande/j2mod/modbus/net/TCPMasterConnection;)V
/*    */     //   283: astore 6
/*    */     //   285: aload 6
/*    */     //   287: aload 4
/*    */     //   289: invokeinterface 123 2 0
/*    */     //   294: new 129	com/ghgande/j2mod/modbus/procimg/SimpleRegister
/*    */     //   297: dup
/*    */     //   298: iconst_0
/*    */     //   299: invokespecial 131	com/ghgande/j2mod/modbus/procimg/SimpleRegister:<init>	(I)V
/*    */     //   302: astore 12
/*    */     //   304: aload 4
/*    */     //   306: aload 12
/*    */     //   308: invokevirtual 133	com/ghgande/j2mod/modbus/msg/WriteSingleRegisterRequest:setRegister	(Lcom/ghgande/j2mod/modbus/procimg/Register;)V
/*    */     //   311: ldc -119
/*    */     //   313: istore 13
/*    */     //   315: aload 5
/*    */     //   317: invokeinterface 138 1 0
/*    */     //   322: aload 5
/*    */     //   324: invokeinterface 141 1 0
/*    */     //   329: checkcast 145	com/ghgande/j2mod/modbus/msg/ReadInputRegistersResponse
/*    */     //   332: iconst_0
/*    */     //   333: invokevirtual 147	com/ghgande/j2mod/modbus/msg/ReadInputRegistersResponse:getRegister	(I)Lcom/ghgande/j2mod/modbus/procimg/InputRegister;
/*    */     //   336: invokeinterface 151 1 0
/*    */     //   341: istore 14
/*    */     //   343: iload 14
/*    */     //   345: iload 13
/*    */     //   347: if_icmpeq -32 -> 315
/*    */     //   350: aload 12
/*    */     //   352: iload 14
/*    */     //   354: invokevirtual 156	com/ghgande/j2mod/modbus/procimg/SimpleRegister:setValue	(I)V
/*    */     //   357: aload 6
/*    */     //   359: invokeinterface 138 1 0
/*    */     //   364: iload 14
/*    */     //   366: istore 13
/*    */     //   368: getstatic 73	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*    */     //   371: ifeq -56 -> 315
/*    */     //   374: getstatic 15	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   377: ldc -97
/*    */     //   379: invokevirtual 23	java/io/PrintStream:println	(Ljava/lang/String;)V
/*    */     //   382: goto -67 -> 315
/*    */     //   385: astore 12
/*    */     //   387: aload 12
/*    */     //   389: invokevirtual 57	java/lang/Exception:printStackTrace	()V
/*    */     //   392: aload_2
/*    */     //   393: invokevirtual 161	com/ghgande/j2mod/modbus/net/TCPMasterConnection:close	()V
/*    */     //   396: goto +12 -> 408
/*    */     //   399: astore 15
/*    */     //   401: aload_2
/*    */     //   402: invokevirtual 161	com/ghgande/j2mod/modbus/net/TCPMasterConnection:close	()V
/*    */     //   405: aload 15
/*    */     //   407: athrow
/*    */     //   408: return
/*    */     // Line number table:
/*    */     //   Java source line #80	-> byte code offset #0
/*    */     //   Java source line #81	-> byte code offset #2
/*    */     //   Java source line #82	-> byte code offset #4
/*    */     //   Java source line #83	-> byte code offset #6
/*    */     //   Java source line #85	-> byte code offset #9
/*    */     //   Java source line #86	-> byte code offset #12
/*    */     //   Java source line #88	-> byte code offset #15
/*    */     //   Java source line #89	-> byte code offset #18
/*    */     //   Java source line #90	-> byte code offset #21
/*    */     //   Java source line #91	-> byte code offset #26
/*    */     //   Java source line #92	-> byte code offset #29
/*    */     //   Java source line #95	-> byte code offset #32
/*    */     //   Java source line #96	-> byte code offset #38
/*    */     //   Java source line #97	-> byte code offset #41
/*    */     //   Java source line #102	-> byte code offset #45
/*    */     //   Java source line #103	-> byte code offset #50
/*    */     //   Java source line #105	-> byte code offset #59
/*    */     //   Java source line #106	-> byte code offset #65
/*    */     //   Java source line #107	-> byte code offset #72
/*    */     //   Java source line #108	-> byte code offset #81
/*    */     //   Java source line #109	-> byte code offset #88
/*    */     //   Java source line #110	-> byte code offset #100
/*    */     //   Java source line #111	-> byte code offset #107
/*    */     //   Java source line #115	-> byte code offset #116
/*    */     //   Java source line #116	-> byte code offset #122
/*    */     //   Java source line #117	-> byte code offset #130
/*    */     //   Java source line #118	-> byte code offset #138
/*    */     //   Java source line #119	-> byte code offset #143
/*    */     //   Java source line #120	-> byte code offset #148
/*    */     //   Java source line #121	-> byte code offset #151
/*    */     //   Java source line #125	-> byte code offset #155
/*    */     //   Java source line #126	-> byte code offset #164
/*    */     //   Java source line #127	-> byte code offset #170
/*    */     //   Java source line #128	-> byte code offset #174
/*    */     //   Java source line #129	-> byte code offset #180
/*    */     //   Java source line #130	-> byte code offset #204
/*    */     //   Java source line #129	-> byte code offset #214
/*    */     //   Java source line #133	-> byte code offset #217
/*    */     //   Java source line #134	-> byte code offset #228
/*    */     //   Java source line #135	-> byte code offset #237
/*    */     //   Java source line #137	-> byte code offset #244
/*    */     //   Java source line #138	-> byte code offset #250
/*    */     //   Java source line #141	-> byte code offset #257
/*    */     //   Java source line #142	-> byte code offset #267
/*    */     //   Java source line #143	-> byte code offset #275
/*    */     //   Java source line #144	-> byte code offset #285
/*    */     //   Java source line #147	-> byte code offset #294
/*    */     //   Java source line #148	-> byte code offset #304
/*    */     //   Java source line #149	-> byte code offset #311
/*    */     //   Java source line #153	-> byte code offset #315
/*    */     //   Java source line #154	-> byte code offset #322
/*    */     //   Java source line #155	-> byte code offset #324
/*    */     //   Java source line #154	-> byte code offset #329
/*    */     //   Java source line #155	-> byte code offset #332
/*    */     //   Java source line #154	-> byte code offset #341
/*    */     //   Java source line #158	-> byte code offset #343
/*    */     //   Java source line #159	-> byte code offset #350
/*    */     //   Java source line #160	-> byte code offset #357
/*    */     //   Java source line #161	-> byte code offset #364
/*    */     //   Java source line #162	-> byte code offset #368
/*    */     //   Java source line #163	-> byte code offset #374
/*    */     //   Java source line #164	-> byte code offset #377
/*    */     //   Java source line #166	-> byte code offset #382
/*    */     //   Java source line #168	-> byte code offset #385
/*    */     //   Java source line #169	-> byte code offset #387
/*    */     //   Java source line #172	-> byte code offset #392
/*    */     //   Java source line #170	-> byte code offset #399
/*    */     //   Java source line #172	-> byte code offset #401
/*    */     //   Java source line #173	-> byte code offset #405
/*    */     //   Java source line #174	-> byte code offset #408
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	409	0	args	String[]
/*    */     //   1	192	1	addr	java.net.InetAddress
/*    */     //   3	399	2	con	com.ghgande.j2mod.modbus.net.TCPMasterConnection
/*    */     //   5	265	3	ai_req	com.ghgande.j2mod.modbus.msg.ModbusRequest
/*    */     //   7	298	4	ao_req	com.ghgande.j2mod.modbus.msg.WriteSingleRegisterRequest
/*    */     //   10	313	5	ai_trans	com.ghgande.j2mod.modbus.io.ModbusTransaction
/*    */     //   13	345	6	ao_trans	com.ghgande.j2mod.modbus.io.ModbusTransaction
/*    */     //   16	206	7	ai_ref	int
/*    */     //   19	221	8	ao_ref	int
/*    */     //   24	142	9	port	int
/*    */     //   27	219	10	unit_in	int
/*    */     //   30	223	11	unit_out	int
/*    */     //   48	3	12	serverAddress	String
/*    */     //   141	3	12	ex	Exception
/*    */     //   302	49	12	new_out	com.ghgande.j2mod.modbus.procimg.SimpleRegister
/*    */     //   385	3	12	ex	Exception
/*    */     //   57	51	13	parts	String[]
/*    */     //   313	54	13	last_out	int
/*    */     //   63	54	14	address	String
/*    */     //   341	24	14	new_in	int
/*    */     //   399	7	15	localObject	Object
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   45	138	141	java/lang/Exception
/*    */     //   45	385	385	java/lang/Exception
/*    */     //   45	392	399	finally
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\AIAOTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */