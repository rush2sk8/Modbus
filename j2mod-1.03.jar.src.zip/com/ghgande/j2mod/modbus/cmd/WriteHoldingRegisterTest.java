/*    */ package com.ghgande.j2mod.modbus.cmd;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WriteHoldingRegisterTest
/*    */ {
/*    */   private static void printUsage()
/*    */   {
/* 76 */     System.out.println("java com.ghgande.j2mod.modbus.cmd.WriteHoldingRegisterTest <connection [String]> <register [int]> <value [int]> {<repeat [int]>}");
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public static void main(String[] args)
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aconst_null
/*    */     //   1: astore_1
/*    */     //   2: aconst_null
/*    */     //   3: astore_2
/*    */     //   4: aconst_null
/*    */     //   5: astore_3
/*    */     //   6: iconst_0
/*    */     //   7: istore 4
/*    */     //   9: iconst_0
/*    */     //   10: istore 5
/*    */     //   12: iconst_1
/*    */     //   13: istore 6
/*    */     //   15: iconst_0
/*    */     //   16: istore 7
/*    */     //   18: aload_0
/*    */     //   19: arraylength
/*    */     //   20: iconst_3
/*    */     //   21: if_icmpge +10 -> 31
/*    */     //   24: invokestatic 31	com/ghgande/j2mod/modbus/cmd/WriteHoldingRegisterTest:printUsage	()V
/*    */     //   27: iconst_1
/*    */     //   28: invokestatic 33	java/lang/System:exit	(I)V
/*    */     //   31: aload_0
/*    */     //   32: iconst_0
/*    */     //   33: aaload
/*    */     //   34: invokestatic 37	com/ghgande/j2mod/modbus/net/ModbusMasterFactory:createModbusMaster	(Ljava/lang/String;)Lcom/ghgande/j2mod/modbus/io/ModbusTransport;
/*    */     //   37: astore_3
/*    */     //   38: aload_0
/*    */     //   39: iconst_1
/*    */     //   40: aaload
/*    */     //   41: invokestatic 43	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*    */     //   44: istore 4
/*    */     //   46: aload_0
/*    */     //   47: iconst_2
/*    */     //   48: aaload
/*    */     //   49: invokestatic 43	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*    */     //   52: istore 5
/*    */     //   54: aload_0
/*    */     //   55: arraylength
/*    */     //   56: iconst_4
/*    */     //   57: if_icmpne +28 -> 85
/*    */     //   60: aload_0
/*    */     //   61: iconst_3
/*    */     //   62: aaload
/*    */     //   63: invokestatic 43	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*    */     //   66: istore 6
/*    */     //   68: goto +17 -> 85
/*    */     //   71: astore 8
/*    */     //   73: aload 8
/*    */     //   75: invokevirtual 49	java/lang/Exception:printStackTrace	()V
/*    */     //   78: invokestatic 31	com/ghgande/j2mod/modbus/cmd/WriteHoldingRegisterTest:printUsage	()V
/*    */     //   81: iconst_1
/*    */     //   82: invokestatic 33	java/lang/System:exit	(I)V
/*    */     //   85: new 54	com/ghgande/j2mod/modbus/msg/WriteSingleRegisterRequest
/*    */     //   88: dup
/*    */     //   89: iload 4
/*    */     //   91: new 56	com/ghgande/j2mod/modbus/procimg/SimpleRegister
/*    */     //   94: dup
/*    */     //   95: iload 5
/*    */     //   97: invokespecial 58	com/ghgande/j2mod/modbus/procimg/SimpleRegister:<init>	(I)V
/*    */     //   100: invokespecial 60	com/ghgande/j2mod/modbus/msg/WriteSingleRegisterRequest:<init>	(ILcom/ghgande/j2mod/modbus/procimg/Register;)V
/*    */     //   103: astore_1
/*    */     //   104: aload_1
/*    */     //   105: iload 7
/*    */     //   107: invokevirtual 63	com/ghgande/j2mod/modbus/msg/ModbusRequest:setUnitID	(I)V
/*    */     //   110: getstatic 68	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*    */     //   113: ifeq +28 -> 141
/*    */     //   116: getstatic 15	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   119: new 74	java/lang/StringBuilder
/*    */     //   122: dup
/*    */     //   123: ldc 76
/*    */     //   125: invokespecial 78	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*    */     //   128: aload_1
/*    */     //   129: invokevirtual 80	com/ghgande/j2mod/modbus/msg/ModbusRequest:getHexMessage	()Ljava/lang/String;
/*    */     //   132: invokevirtual 84	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   135: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*    */     //   138: invokevirtual 23	java/io/PrintStream:println	(Ljava/lang/String;)V
/*    */     //   141: aload_3
/*    */     //   142: invokeinterface 91 1 0
/*    */     //   147: astore_2
/*    */     //   148: aload_2
/*    */     //   149: aload_1
/*    */     //   150: invokeinterface 97 2 0
/*    */     //   155: iconst_0
/*    */     //   156: istore 8
/*    */     //   158: goto +48 -> 206
/*    */     //   161: aload_2
/*    */     //   162: invokeinterface 103 1 0
/*    */     //   167: getstatic 68	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*    */     //   170: ifeq +33 -> 203
/*    */     //   173: getstatic 15	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   176: new 74	java/lang/StringBuilder
/*    */     //   179: dup
/*    */     //   180: ldc 106
/*    */     //   182: invokespecial 78	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*    */     //   185: aload_2
/*    */     //   186: invokeinterface 108 1 0
/*    */     //   191: invokevirtual 112	com/ghgande/j2mod/modbus/msg/ModbusResponse:getHexMessage	()Ljava/lang/String;
/*    */     //   194: invokevirtual 84	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   197: invokevirtual 88	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*    */     //   200: invokevirtual 23	java/io/PrintStream:println	(Ljava/lang/String;)V
/*    */     //   203: iinc 8 1
/*    */     //   206: iload 8
/*    */     //   208: iload 6
/*    */     //   210: if_icmplt -49 -> 161
/*    */     //   213: goto +40 -> 253
/*    */     //   216: astore 8
/*    */     //   218: aload 8
/*    */     //   220: invokevirtual 49	java/lang/Exception:printStackTrace	()V
/*    */     //   223: aload_3
/*    */     //   224: invokeinterface 115 1 0
/*    */     //   229: goto +35 -> 264
/*    */     //   232: astore 10
/*    */     //   234: goto +30 -> 264
/*    */     //   237: astore 9
/*    */     //   239: aload_3
/*    */     //   240: invokeinterface 115 1 0
/*    */     //   245: goto +5 -> 250
/*    */     //   248: astore 10
/*    */     //   250: aload 9
/*    */     //   252: athrow
/*    */     //   253: aload_3
/*    */     //   254: invokeinterface 115 1 0
/*    */     //   259: goto +5 -> 264
/*    */     //   262: astore 10
/*    */     //   264: return
/*    */     // Line number table:
/*    */     //   Java source line #83	-> byte code offset #0
/*    */     //   Java source line #84	-> byte code offset #2
/*    */     //   Java source line #85	-> byte code offset #4
/*    */     //   Java source line #86	-> byte code offset #6
/*    */     //   Java source line #87	-> byte code offset #9
/*    */     //   Java source line #88	-> byte code offset #12
/*    */     //   Java source line #89	-> byte code offset #15
/*    */     //   Java source line #92	-> byte code offset #18
/*    */     //   Java source line #93	-> byte code offset #24
/*    */     //   Java source line #94	-> byte code offset #27
/*    */     //   Java source line #99	-> byte code offset #31
/*    */     //   Java source line #100	-> byte code offset #38
/*    */     //   Java source line #101	-> byte code offset #46
/*    */     //   Java source line #103	-> byte code offset #54
/*    */     //   Java source line #104	-> byte code offset #60
/*    */     //   Java source line #105	-> byte code offset #68
/*    */     //   Java source line #106	-> byte code offset #73
/*    */     //   Java source line #107	-> byte code offset #78
/*    */     //   Java source line #108	-> byte code offset #81
/*    */     //   Java source line #111	-> byte code offset #85
/*    */     //   Java source line #112	-> byte code offset #91
/*    */     //   Java source line #111	-> byte code offset #100
/*    */     //   Java source line #114	-> byte code offset #104
/*    */     //   Java source line #115	-> byte code offset #110
/*    */     //   Java source line #116	-> byte code offset #116
/*    */     //   Java source line #119	-> byte code offset #141
/*    */     //   Java source line #120	-> byte code offset #148
/*    */     //   Java source line #124	-> byte code offset #155
/*    */     //   Java source line #125	-> byte code offset #161
/*    */     //   Java source line #127	-> byte code offset #167
/*    */     //   Java source line #128	-> byte code offset #173
/*    */     //   Java source line #129	-> byte code offset #185
/*    */     //   Java source line #128	-> byte code offset #200
/*    */     //   Java source line #124	-> byte code offset #203
/*    */     //   Java source line #131	-> byte code offset #213
/*    */     //   Java source line #132	-> byte code offset #218
/*    */     //   Java source line #135	-> byte code offset #223
/*    */     //   Java source line #136	-> byte code offset #229
/*    */     //   Java source line #133	-> byte code offset #237
/*    */     //   Java source line #135	-> byte code offset #239
/*    */     //   Java source line #136	-> byte code offset #245
/*    */     //   Java source line #139	-> byte code offset #250
/*    */     //   Java source line #135	-> byte code offset #253
/*    */     //   Java source line #136	-> byte code offset #259
/*    */     //   Java source line #140	-> byte code offset #264
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	265	0	args	String[]
/*    */     //   1	149	1	req	com.ghgande.j2mod.modbus.msg.ModbusRequest
/*    */     //   3	183	2	trans	com.ghgande.j2mod.modbus.io.ModbusTransaction
/*    */     //   5	249	3	transport	com.ghgande.j2mod.modbus.io.ModbusTransport
/*    */     //   7	83	4	ref	int
/*    */     //   10	86	5	value	int
/*    */     //   13	196	6	repeat	int
/*    */     //   16	90	7	unit	int
/*    */     //   71	3	8	ex	Exception
/*    */     //   156	51	8	count	int
/*    */     //   216	3	8	ex	Exception
/*    */     //   237	14	9	localObject	Object
/*    */     //   232	1	10	localIOException	java.io.IOException
/*    */     //   248	1	10	localIOException1	java.io.IOException
/*    */     //   262	1	10	localIOException2	java.io.IOException
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   31	68	71	java/lang/Exception
/*    */     //   31	213	216	java/lang/Exception
/*    */     //   223	229	232	java/io/IOException
/*    */     //   31	223	237	finally
/*    */     //   239	245	248	java/io/IOException
/*    */     //   253	259	262	java/io/IOException
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\cmd\WriteHoldingRegisterTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */