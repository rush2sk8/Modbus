/*     */ package com.ghgande.j2mod.modbus.facade;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusException;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTCPTransaction;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadCoilsRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadCoilsResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputDiscretesRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputDiscretesResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputRegistersRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputRegistersResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadMultipleRegistersRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadMultipleRegistersResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteCoilRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteCoilResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteMultipleCoilsRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteMultipleRegistersRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteSingleRegisterRequest;
/*     */ import com.ghgande.j2mod.modbus.net.TCPMasterConnection;
/*     */ import com.ghgande.j2mod.modbus.procimg.InputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import com.ghgande.j2mod.modbus.util.BitVector;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusTCPMaster
/*     */ {
/*     */   private TCPMasterConnection m_Connection;
/*     */   private InetAddress m_SlaveAddress;
/*     */   private ModbusTCPTransaction m_Transaction;
/*     */   private ReadCoilsRequest m_ReadCoilsRequest;
/*     */   private ReadInputDiscretesRequest m_ReadInputDiscretesRequest;
/*     */   private WriteCoilRequest m_WriteCoilRequest;
/*     */   private WriteMultipleCoilsRequest m_WriteMultipleCoilsRequest;
/*     */   private ReadInputRegistersRequest m_ReadInputRegistersRequest;
/*     */   private ReadMultipleRegistersRequest m_ReadMultipleRegistersRequest;
/*     */   private WriteSingleRegisterRequest m_WriteSingleRegisterRequest;
/*     */   private WriteMultipleRegistersRequest m_WriteMultipleRegistersRequest;
/*  67 */   private boolean m_Reconnecting = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusTCPMaster(String addr)
/*     */   {
/*     */     try
/*     */     {
/*  78 */       this.m_SlaveAddress = InetAddress.getByName(addr);
/*  79 */       this.m_Connection = new TCPMasterConnection(this.m_SlaveAddress);
/*  80 */       this.m_ReadCoilsRequest = new ReadCoilsRequest();
/*  81 */       this.m_ReadInputDiscretesRequest = new ReadInputDiscretesRequest();
/*  82 */       this.m_WriteCoilRequest = new WriteCoilRequest();
/*  83 */       this.m_WriteMultipleCoilsRequest = new WriteMultipleCoilsRequest();
/*  84 */       this.m_ReadInputRegistersRequest = new ReadInputRegistersRequest();
/*  85 */       this.m_ReadMultipleRegistersRequest = new ReadMultipleRegistersRequest();
/*  86 */       this.m_WriteSingleRegisterRequest = new WriteSingleRegisterRequest();
/*  87 */       this.m_WriteMultipleRegistersRequest = new WriteMultipleRegistersRequest();
/*     */     }
/*     */     catch (UnknownHostException e) {
/*  90 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusTCPMaster(String addr, int port)
/*     */   {
/* 103 */     this(addr);
/* 104 */     this.m_Connection.setPort(port);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void connect()
/*     */     throws Exception
/*     */   {
/* 114 */     if ((this.m_Connection != null) && (!this.m_Connection.isConnected())) {
/* 115 */       this.m_Connection.connect();
/* 116 */       this.m_Transaction = new ModbusTCPTransaction(this.m_Connection);
/* 117 */       this.m_Transaction.setReconnecting(this.m_Reconnecting);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void disconnect()
/*     */   {
/* 125 */     if ((this.m_Connection != null) && (this.m_Connection.isConnected())) {
/* 126 */       this.m_Connection.close();
/* 127 */       this.m_Transaction = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReconnecting(boolean b)
/*     */   {
/* 139 */     this.m_Reconnecting = b;
/* 140 */     if (this.m_Transaction != null) {
/* 141 */       this.m_Transaction.setReconnecting(b);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReconnecting()
/*     */   {
/* 153 */     return this.m_Reconnecting;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized BitVector readCoils(int ref, int count)
/*     */     throws ModbusException
/*     */   {
/* 171 */     this.m_ReadCoilsRequest.setReference(ref);
/* 172 */     this.m_ReadCoilsRequest.setBitCount(count);
/* 173 */     this.m_Transaction.setRequest(this.m_ReadCoilsRequest);
/* 174 */     this.m_Transaction.execute();
/* 175 */     BitVector bv = ((ReadCoilsResponse)this.m_Transaction.getResponse()).getCoils();
/* 176 */     bv.forceSize(count);
/* 177 */     return bv;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean writeCoil(int unitid, int ref, boolean state)
/*     */     throws ModbusException
/*     */   {
/* 192 */     this.m_WriteCoilRequest.setUnitID(unitid);
/* 193 */     this.m_WriteCoilRequest.setReference(ref);
/* 194 */     this.m_WriteCoilRequest.setCoil(state);
/* 195 */     this.m_Transaction.setRequest(this.m_WriteCoilRequest);
/* 196 */     this.m_Transaction.execute();
/* 197 */     return ((WriteCoilResponse)this.m_Transaction.getResponse()).getCoil();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void writeMultipleCoils(int ref, BitVector coils)
/*     */     throws ModbusException
/*     */   {
/* 213 */     this.m_WriteMultipleCoilsRequest.setReference(ref);
/* 214 */     this.m_WriteMultipleCoilsRequest.setCoils(coils);
/* 215 */     this.m_Transaction.setRequest(this.m_WriteMultipleCoilsRequest);
/* 216 */     this.m_Transaction.execute();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized BitVector readInputDiscretes(int ref, int count)
/*     */     throws ModbusException
/*     */   {
/* 234 */     this.m_ReadInputDiscretesRequest.setReference(ref);
/* 235 */     this.m_ReadInputDiscretesRequest.setBitCount(count);
/* 236 */     this.m_Transaction.setRequest(this.m_ReadInputDiscretesRequest);
/* 237 */     this.m_Transaction.execute();
/* 238 */     BitVector bv = ((ReadInputDiscretesResponse)this.m_Transaction.getResponse()).getDiscretes();
/* 239 */     bv.forceSize(count);
/* 240 */     return bv;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized InputRegister[] readInputRegisters(int ref, int count)
/*     */     throws ModbusException
/*     */   {
/* 258 */     this.m_ReadInputRegistersRequest.setReference(ref);
/* 259 */     this.m_ReadInputRegistersRequest.setWordCount(count);
/* 260 */     this.m_Transaction.setRequest(this.m_ReadInputRegistersRequest);
/* 261 */     this.m_Transaction.execute();
/* 262 */     return ((ReadInputRegistersResponse)this.m_Transaction.getResponse()).getRegisters();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Register[] readMultipleRegisters(int ref, int count)
/*     */     throws ModbusException
/*     */   {
/* 279 */     this.m_ReadMultipleRegistersRequest.setReference(ref);
/* 280 */     this.m_ReadMultipleRegistersRequest.setWordCount(count);
/* 281 */     this.m_Transaction.setRequest(this.m_ReadMultipleRegistersRequest);
/* 282 */     this.m_Transaction.execute();
/* 283 */     return ((ReadMultipleRegistersResponse)this.m_Transaction.getResponse()).getRegisters();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void writeSingleRegister(int ref, Register register)
/*     */     throws ModbusException
/*     */   {
/* 297 */     this.m_WriteSingleRegisterRequest.setReference(ref);
/* 298 */     this.m_WriteSingleRegisterRequest.setRegister(register);
/* 299 */     this.m_Transaction.setRequest(this.m_WriteSingleRegisterRequest);
/* 300 */     this.m_Transaction.execute();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void writeMultipleRegisters(int ref, Register[] registers)
/*     */     throws ModbusException
/*     */   {
/* 314 */     this.m_WriteMultipleRegistersRequest.setReference(ref);
/* 315 */     this.m_WriteMultipleRegistersRequest.setRegisters(registers);
/* 316 */     this.m_Transaction.setRequest(this.m_WriteMultipleRegistersRequest);
/* 317 */     this.m_Transaction.execute();
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\facade\ModbusTCPMaster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */