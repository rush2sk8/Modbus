/*     */ package com.ghgande.j2mod.modbus.facade;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusException;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusUDPTransaction;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadCoilsRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadCoilsResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputDiscretesRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputDiscretesResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputRegistersRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputRegistersResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadMultipleRegistersRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadMultipleRegistersResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteCoilRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteCoilResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteMultipleCoilsRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteMultipleRegistersRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteSingleRegisterRequest;
/*     */ import com.ghgande.j2mod.modbus.net.UDPMasterConnection;
/*     */ import com.ghgande.j2mod.modbus.procimg.InputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import com.ghgande.j2mod.modbus.util.BitVector;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusUDPMaster
/*     */ {
/*     */   private UDPMasterConnection m_Connection;
/*     */   private InetAddress m_SlaveAddress;
/*     */   private ModbusUDPTransaction m_Transaction;
/*     */   private ReadCoilsRequest m_ReadCoilsRequest;
/*     */   private ReadInputDiscretesRequest m_ReadInputDiscretesRequest;
/*     */   private WriteCoilRequest m_WriteCoilRequest;
/*     */   private WriteMultipleCoilsRequest m_WriteMultipleCoilsRequest;
/*     */   private ReadInputRegistersRequest m_ReadInputRegistersRequest;
/*     */   private ReadMultipleRegistersRequest m_ReadMultipleRegistersRequest;
/*     */   private WriteSingleRegisterRequest m_WriteSingleRegisterRequest;
/*     */   private WriteMultipleRegistersRequest m_WriteMultipleRegistersRequest;
/*     */   
/*     */   public ModbusUDPMaster(String addr)
/*     */   {
/*     */     try
/*     */     {
/*  77 */       this.m_SlaveAddress = InetAddress.getByName(addr);
/*  78 */       this.m_Connection = new UDPMasterConnection(this.m_SlaveAddress);
/*  79 */       this.m_ReadCoilsRequest = new ReadCoilsRequest();
/*  80 */       this.m_ReadInputDiscretesRequest = new ReadInputDiscretesRequest();
/*  81 */       this.m_WriteCoilRequest = new WriteCoilRequest();
/*  82 */       this.m_WriteMultipleCoilsRequest = new WriteMultipleCoilsRequest();
/*  83 */       this.m_ReadInputRegistersRequest = new ReadInputRegistersRequest();
/*  84 */       this.m_ReadMultipleRegistersRequest = new ReadMultipleRegistersRequest();
/*  85 */       this.m_WriteSingleRegisterRequest = new WriteSingleRegisterRequest();
/*  86 */       this.m_WriteMultipleRegistersRequest = new WriteMultipleRegistersRequest();
/*     */     }
/*     */     catch (UnknownHostException e) {
/*  89 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusUDPMaster(String addr, int port)
/*     */   {
/* 102 */     this(addr);
/* 103 */     this.m_Connection.setPort(port);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void connect()
/*     */     throws Exception
/*     */   {
/* 113 */     if ((this.m_Connection != null) && (!this.m_Connection.isConnected())) {
/* 114 */       this.m_Connection.connect();
/* 115 */       this.m_Transaction = new ModbusUDPTransaction(this.m_Connection);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void disconnect()
/*     */   {
/* 123 */     if ((this.m_Connection != null) && (this.m_Connection.isConnected())) {
/* 124 */       this.m_Connection.close();
/* 125 */       this.m_Transaction = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized BitVector readCoils(int ref, int count)
/*     */     throws ModbusException
/*     */   {
/* 144 */     this.m_ReadCoilsRequest.setReference(ref);
/* 145 */     this.m_ReadCoilsRequest.setBitCount(count);
/* 146 */     this.m_Transaction.setRequest(this.m_ReadCoilsRequest);
/* 147 */     this.m_Transaction.execute();
/* 148 */     BitVector bv = ((ReadCoilsResponse)this.m_Transaction.getResponse()).getCoils();
/* 149 */     bv.forceSize(count);
/* 150 */     return bv;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean writeCoil(int unitid, int ref, boolean state)
/*     */     throws ModbusException
/*     */   {
/* 165 */     this.m_WriteCoilRequest.setUnitID(unitid);
/* 166 */     this.m_WriteCoilRequest.setReference(ref);
/* 167 */     this.m_WriteCoilRequest.setCoil(state);
/* 168 */     this.m_Transaction.setRequest(this.m_WriteCoilRequest);
/* 169 */     this.m_Transaction.execute();
/* 170 */     return ((WriteCoilResponse)this.m_Transaction.getResponse()).getCoil();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void writeMultipleCoils(int ref, BitVector coils)
/*     */     throws ModbusException
/*     */   {
/* 186 */     this.m_WriteMultipleCoilsRequest.setReference(ref);
/* 187 */     this.m_WriteMultipleCoilsRequest.setCoils(coils);
/* 188 */     this.m_Transaction.setRequest(this.m_WriteMultipleCoilsRequest);
/* 189 */     this.m_Transaction.execute();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized BitVector readInputDiscretes(int ref, int count)
/*     */     throws ModbusException
/*     */   {
/* 207 */     this.m_ReadInputDiscretesRequest.setReference(ref);
/* 208 */     this.m_ReadInputDiscretesRequest.setBitCount(count);
/* 209 */     this.m_Transaction.setRequest(this.m_ReadInputDiscretesRequest);
/* 210 */     this.m_Transaction.execute();
/* 211 */     BitVector bv = ((ReadInputDiscretesResponse)this.m_Transaction.getResponse()).getDiscretes();
/* 212 */     bv.forceSize(count);
/* 213 */     return bv;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized InputRegister[] readInputRegisters(int ref, int count)
/*     */     throws ModbusException
/*     */   {
/* 231 */     this.m_ReadInputRegistersRequest.setReference(ref);
/* 232 */     this.m_ReadInputRegistersRequest.setWordCount(count);
/* 233 */     this.m_Transaction.setRequest(this.m_ReadInputRegistersRequest);
/* 234 */     this.m_Transaction.execute();
/* 235 */     return ((ReadInputRegistersResponse)this.m_Transaction.getResponse()).getRegisters();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Register[] readMultipleRegisters(int ref, int count)
/*     */     throws ModbusException
/*     */   {
/* 252 */     this.m_ReadMultipleRegistersRequest.setReference(ref);
/* 253 */     this.m_ReadMultipleRegistersRequest.setWordCount(count);
/* 254 */     this.m_Transaction.setRequest(this.m_ReadMultipleRegistersRequest);
/* 255 */     this.m_Transaction.execute();
/* 256 */     return ((ReadMultipleRegistersResponse)this.m_Transaction.getResponse()).getRegisters();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void writeSingleRegister(int ref, Register register)
/*     */     throws ModbusException
/*     */   {
/* 270 */     this.m_WriteSingleRegisterRequest.setReference(ref);
/* 271 */     this.m_WriteSingleRegisterRequest.setRegister(register);
/* 272 */     this.m_Transaction.setRequest(this.m_WriteSingleRegisterRequest);
/* 273 */     this.m_Transaction.execute();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void writeMultipleRegisters(int ref, Register[] registers)
/*     */     throws ModbusException
/*     */   {
/* 287 */     this.m_WriteMultipleRegistersRequest.setReference(ref);
/* 288 */     this.m_WriteMultipleRegistersRequest.setRegisters(registers);
/* 289 */     this.m_Transaction.setRequest(this.m_WriteMultipleRegistersRequest);
/* 290 */     this.m_Transaction.execute();
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\facade\ModbusUDPMaster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */