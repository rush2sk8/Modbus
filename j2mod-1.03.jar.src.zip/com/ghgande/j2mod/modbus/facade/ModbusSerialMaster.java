/*     */ package com.ghgande.j2mod.modbus.facade;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.ModbusException;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusSerialTransaction;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadCoilsRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadCoilsResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputDiscretesRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputDiscretesResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputRegistersRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadInputRegistersResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadMultipleRegistersRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ReadMultipleRegistersResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteCoilRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteCoilResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteMultipleCoilsRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteMultipleRegistersRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.WriteSingleRegisterRequest;
/*     */ import com.ghgande.j2mod.modbus.net.SerialConnection;
/*     */ import com.ghgande.j2mod.modbus.procimg.InputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import com.ghgande.j2mod.modbus.util.BitVector;
/*     */ import com.ghgande.j2mod.modbus.util.SerialParameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusSerialMaster
/*     */ {
/*     */   private SerialParameters m_CommParameters;
/*     */   private SerialConnection m_Connection;
/*     */   private ModbusSerialTransaction m_Transaction;
/*     */   private ReadCoilsRequest m_ReadCoilsRequest;
/*     */   private ReadInputDiscretesRequest m_ReadInputDiscretesRequest;
/*     */   private WriteCoilRequest m_WriteCoilRequest;
/*     */   private WriteMultipleCoilsRequest m_WriteMultipleCoilsRequest;
/*     */   private ReadInputRegistersRequest m_ReadInputRegistersRequest;
/*     */   private ReadMultipleRegistersRequest m_ReadMultipleRegistersRequest;
/*     */   private WriteSingleRegisterRequest m_WriteSingleRegisterRequest;
/*     */   private WriteMultipleRegistersRequest m_WriteMultipleRegistersRequest;
/*     */   
/*     */   public ModbusSerialMaster(SerialParameters param)
/*     */   {
/*     */     try
/*     */     {
/*  77 */       this.m_CommParameters = param;
/*  78 */       this.m_Connection = new SerialConnection(this.m_CommParameters);
/*  79 */       this.m_ReadCoilsRequest = new ReadCoilsRequest();
/*  80 */       this.m_ReadInputDiscretesRequest = new ReadInputDiscretesRequest();
/*  81 */       this.m_WriteCoilRequest = new WriteCoilRequest();
/*  82 */       this.m_WriteMultipleCoilsRequest = new WriteMultipleCoilsRequest();
/*  83 */       this.m_ReadInputRegistersRequest = new ReadInputRegistersRequest();
/*  84 */       this.m_ReadMultipleRegistersRequest = new ReadMultipleRegistersRequest();
/*  85 */       this.m_WriteSingleRegisterRequest = new WriteSingleRegisterRequest();
/*  86 */       this.m_WriteMultipleRegistersRequest = new WriteMultipleRegistersRequest();
/*     */     } catch (Exception e) {
/*  88 */       throw new RuntimeException(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUnitIdentifier(int unitid)
/*     */   {
/*  98 */     ModbusCoupler.getReference().setUnitID(unitid);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUnitIdentifier()
/*     */   {
/* 107 */     return ModbusCoupler.getReference().getUnitID();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void connect()
/*     */     throws Exception
/*     */   {
/* 117 */     if ((this.m_Connection != null) && (!this.m_Connection.isOpen())) {
/* 118 */       this.m_Connection.open();
/* 119 */       this.m_Transaction = new ModbusSerialTransaction(this.m_Connection);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void disconnect()
/*     */   {
/* 127 */     if ((this.m_Connection != null) && (this.m_Connection.isOpen())) {
/* 128 */       this.m_Connection.close();
/* 129 */       this.m_Transaction = null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized BitVector readCoils(int unitid, int ref, int count)
/*     */     throws ModbusException
/*     */   {
/* 149 */     this.m_ReadCoilsRequest.setUnitID(unitid);
/* 150 */     this.m_ReadCoilsRequest.setReference(ref);
/* 151 */     this.m_ReadCoilsRequest.setBitCount(count);
/* 152 */     this.m_Transaction.setRequest(this.m_ReadCoilsRequest);
/* 153 */     this.m_Transaction.execute();
/* 154 */     BitVector bv = ((ReadCoilsResponse)this.m_Transaction.getResponse()).getCoils();
/* 155 */     bv.forceSize(count);
/* 156 */     return bv;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean writeCoil(int unitid, int ref, boolean state)
/*     */     throws ModbusException
/*     */   {
/* 171 */     this.m_WriteCoilRequest.setUnitID(unitid);
/* 172 */     this.m_WriteCoilRequest.setReference(ref);
/* 173 */     this.m_WriteCoilRequest.setCoil(state);
/* 174 */     this.m_Transaction.setRequest(this.m_WriteCoilRequest);
/* 175 */     this.m_Transaction.execute();
/* 176 */     return ((WriteCoilResponse)this.m_Transaction.getResponse()).getCoil();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void writeMultipleCoils(int unitid, int ref, BitVector coils)
/*     */     throws ModbusException
/*     */   {
/* 193 */     this.m_WriteMultipleCoilsRequest.setUnitID(unitid);
/* 194 */     this.m_WriteMultipleCoilsRequest.setReference(ref);
/* 195 */     this.m_WriteMultipleCoilsRequest.setCoils(coils);
/* 196 */     this.m_Transaction.setRequest(this.m_WriteMultipleCoilsRequest);
/* 197 */     this.m_Transaction.execute();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized BitVector readInputDiscretes(int unitid, int ref, int count)
/*     */     throws ModbusException
/*     */   {
/* 216 */     this.m_ReadInputDiscretesRequest.setUnitID(unitid);
/* 217 */     this.m_ReadInputDiscretesRequest.setReference(ref);
/* 218 */     this.m_ReadInputDiscretesRequest.setBitCount(count);
/* 219 */     this.m_Transaction.setRequest(this.m_ReadInputDiscretesRequest);
/* 220 */     this.m_Transaction.execute();
/* 221 */     BitVector bv = ((ReadInputDiscretesResponse)this.m_Transaction.getResponse()).getDiscretes();
/* 222 */     bv.forceSize(count);
/* 223 */     return bv;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized InputRegister[] readInputRegisters(int unitid, int ref, int count)
/*     */     throws ModbusException
/*     */   {
/* 242 */     this.m_ReadInputRegistersRequest.setUnitID(unitid);
/* 243 */     this.m_ReadInputRegistersRequest.setReference(ref);
/* 244 */     this.m_ReadInputRegistersRequest.setWordCount(count);
/* 245 */     this.m_Transaction.setRequest(this.m_ReadInputRegistersRequest);
/* 246 */     this.m_Transaction.execute();
/* 247 */     return ((ReadInputRegistersResponse)this.m_Transaction.getResponse()).getRegisters();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized Register[] readMultipleRegisters(int unitid, int ref, int count)
/*     */     throws ModbusException
/*     */   {
/* 265 */     this.m_ReadMultipleRegistersRequest.setUnitID(unitid);
/* 266 */     this.m_ReadMultipleRegistersRequest.setReference(ref);
/* 267 */     this.m_ReadMultipleRegistersRequest.setWordCount(count);
/* 268 */     this.m_Transaction.setRequest(this.m_ReadMultipleRegistersRequest);
/* 269 */     this.m_Transaction.execute();
/* 270 */     return ((ReadMultipleRegistersResponse)this.m_Transaction.getResponse()).getRegisters();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void writeSingleRegister(int unitid, int ref, Register register)
/*     */     throws ModbusException
/*     */   {
/* 285 */     this.m_WriteSingleRegisterRequest.setUnitID(unitid);
/* 286 */     this.m_WriteSingleRegisterRequest.setReference(ref);
/* 287 */     this.m_WriteSingleRegisterRequest.setRegister(register);
/* 288 */     this.m_Transaction.setRequest(this.m_WriteSingleRegisterRequest);
/* 289 */     this.m_Transaction.execute();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void writeMultipleRegisters(int unitid, int ref, Register[] registers)
/*     */     throws ModbusException
/*     */   {
/* 304 */     this.m_WriteMultipleRegistersRequest.setUnitID(unitid);
/* 305 */     this.m_WriteMultipleRegistersRequest.setReference(ref);
/* 306 */     this.m_WriteMultipleRegistersRequest.setRegisters(registers);
/* 307 */     this.m_Transaction.setRequest(this.m_WriteMultipleRegistersRequest);
/* 308 */     this.m_Transaction.execute();
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\facade\ModbusSerialMaster.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */