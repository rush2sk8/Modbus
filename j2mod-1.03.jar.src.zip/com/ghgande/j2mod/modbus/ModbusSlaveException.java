/*     */ package com.ghgande.j2mod.modbus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusSlaveException
/*     */   extends ModbusException
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  53 */   private int m_Type = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusSlaveException(int TYPE)
/*     */   {
/*  72 */     this.m_Type = TYPE;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getType()
/*     */   {
/*  86 */     return this.m_Type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isType(int TYPE)
/*     */   {
/* 107 */     return TYPE == this.m_Type;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getMessage()
/*     */   {
/* 116 */     return getMessage(this.m_Type);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static String getMessage(int type)
/*     */   {
/* 128 */     switch (type) {
/*     */     case 1: 
/* 130 */       return "Illegal Function";
/*     */     case 2: 
/* 132 */       return "Illegal Data Address";
/*     */     case 3: 
/* 134 */       return "Illegal Data Value";
/*     */     case 4: 
/* 136 */       return "Slave Device Failure";
/*     */     case 5: 
/* 138 */       return "Acknowledge";
/*     */     case 6: 
/* 140 */       return "Slave Device Busy";
/*     */     case 8: 
/* 142 */       return "Memory Parity Error";
/*     */     }
/* 144 */     return "Error Code = " + type;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\ModbusSlaveException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */