package com.ghgande.j2mod.modbus.net;

public abstract interface ModbusListener
  extends Runnable
{
  public abstract void run();
  
  public abstract void setUnit(int paramInt);
  
  public abstract int getUnit();
  
  public abstract void setListening(boolean paramBoolean);
  
  public abstract boolean isListening();
  
  public abstract Thread listen();
  
  public abstract void stop();
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\ModbusListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */