/*    */ package com.ghgande.j2mod.modbus.net;
/*    */ 
/*    */ import com.ghgande.j2mod.modbus.util.SerialParameters;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ModbusListenerFactory
/*    */ {
/*    */   public static ModbusListener createModbusListener(String address)
/*    */   {
/* 14 */     String[] parts = address.split(":");
/* 15 */     if ((parts == null) || (parts.length < 2)) {
/* 16 */       throw new IllegalArgumentException("missing connection information");
/*    */     }
/* 18 */     if (parts[0].toLowerCase().equals("device"))
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 25 */       SerialParameters parms = new SerialParameters();
/* 26 */       parms.setPortName(parts[1]);
/* 27 */       parms.setBaudRate(19200);
/* 28 */       parms.setDatabits(8);
/* 29 */       parms.setEcho(false);
/* 30 */       parms.setParity(0);
/* 31 */       parms.setFlowControlIn(0);
/*    */       
/* 33 */       ModbusSerialListener listener = new ModbusSerialListener(parms);
/* 34 */       if (parts.length > 2) {
/* 35 */         int unit = Integer.parseInt(parts[2]);
/* 36 */         if ((unit < 0) || (unit > 248)) {
/* 37 */           throw new IllegalArgumentException("illegal unit number");
/*    */         }
/* 39 */         listener.setUnit(unit);
/*    */       }
/* 41 */       listener.setListening(true);
/*    */       
/* 43 */       Thread result = new Thread(listener);
/* 44 */       result.start();
/*    */       
/* 46 */       return listener; }
/* 47 */     if (parts[0].toLowerCase().equals("tcp"))
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 53 */       ModbusTCPListener listener = new ModbusTCPListener(5);
/* 54 */       if (parts.length > 2) {
/* 55 */         int port = Integer.parseInt(parts[2]);
/* 56 */         listener.setPort(port);
/*    */         
/* 58 */         if (parts.length > 3) {
/* 59 */           int unit = Integer.parseInt(parts[3]);
/* 60 */           listener.setUnit(unit);
/*    */         }
/*    */       }
/* 63 */       listener.setListening(true);
/*    */       
/* 65 */       Thread result = new Thread(listener);
/* 66 */       result.start();
/*    */       
/* 68 */       return listener; }
/* 69 */     if (parts[0].toLowerCase().equals("udp"))
/*    */     {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 75 */       ModbusUDPListener listener = new ModbusUDPListener();
/* 76 */       if (parts.length > 2) {
/* 77 */         int port = Integer.parseInt(parts[2]);
/* 78 */         listener.setPort(port);
/*    */         
/* 80 */         if (parts.length > 3) {
/* 81 */           int unit = Integer.parseInt(parts[3]);
/* 82 */           listener.setUnit(unit);
/*    */         }
/*    */       }
/* 85 */       listener.setListening(true);
/*    */       
/* 87 */       Thread result = new Thread(listener);
/* 88 */       result.start();
/*    */       
/* 90 */       return listener;
/*    */     }
/* 92 */     throw new IllegalArgumentException("unknown type " + parts[0]);
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\ModbusListenerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */