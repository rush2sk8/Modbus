/*     */ package com.ghgande.j2mod.modbus.net;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusUDPTransport;
/*     */ import java.io.PrintStream;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.InetAddress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UDPMasterTerminal
/*     */   implements UDPTerminal
/*     */ {
/*     */   private DatagramSocket m_Socket;
/*  52 */   private int m_Timeout = 3000;
/*     */   private boolean m_Active;
/*     */   protected InetAddress m_LocalAddress;
/*     */   protected InetAddress m_RemoteAddress;
/*  56 */   private int m_RemotePort = 502;
/*  57 */   private int m_LocalPort = 502;
/*     */   protected ModbusUDPTransport m_ModbusTransport;
/*     */   
/*     */   public InetAddress getLocalAddress() {
/*  61 */     return this.m_LocalAddress;
/*     */   }
/*     */   
/*     */   public void setLocalAddress(InetAddress addr) {
/*  65 */     this.m_LocalAddress = addr;
/*     */   }
/*     */   
/*     */   public int getLocalPort() {
/*  69 */     return this.m_LocalPort;
/*     */   }
/*     */   
/*     */   protected void setLocalPort(int port) {
/*  73 */     this.m_LocalPort = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRemotePort()
/*     */   {
/*  82 */     return this.m_RemotePort;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemotePort(int port)
/*     */   {
/*  93 */     this.m_RemotePort = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InetAddress getRemoteAddress()
/*     */   {
/* 103 */     return this.m_RemoteAddress;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRemoteAddress(InetAddress adr)
/*     */   {
/* 114 */     this.m_RemoteAddress = adr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActive()
/*     */   {
/* 123 */     return this.m_Active;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void activate()
/*     */     throws Exception
/*     */   {
/* 133 */     if (!isActive()) {
/* 134 */       if (Modbus.debug) {
/* 135 */         System.out.println("UDPMasterTerminal::activate()::laddr=:" + 
/* 136 */           this.m_LocalAddress + ":lport=" + this.m_LocalPort);
/*     */       }
/* 138 */       if (this.m_Socket == null) {
/* 139 */         if ((this.m_LocalAddress != null) && (this.m_LocalPort != -1)) {
/* 140 */           this.m_Socket = new DatagramSocket(this.m_LocalPort, this.m_LocalAddress);
/*     */         } else {
/* 142 */           this.m_Socket = new DatagramSocket();
/* 143 */           this.m_LocalPort = this.m_Socket.getLocalPort();
/* 144 */           this.m_LocalAddress = this.m_Socket.getLocalAddress();
/*     */         }
/*     */       }
/* 147 */       if (Modbus.debug)
/* 148 */         System.out.println("UDPMasterTerminal::haveSocket():" + 
/* 149 */           this.m_Socket.toString());
/* 150 */       if (Modbus.debug)
/* 151 */         System.out.println("UDPMasterTerminal::laddr=:" + 
/* 152 */           this.m_LocalAddress.toString() + ":lport=" + this.m_LocalPort);
/* 153 */       if (Modbus.debug)
/*     */       {
/* 155 */         System.out.println("UDPMasterTerminal::raddr=:" + 
/* 156 */           this.m_RemoteAddress.toString() + ":rport=" + 
/* 157 */           this.m_RemotePort);
/*     */       }
/* 159 */       this.m_Socket.setReceiveBufferSize(1024);
/* 160 */       this.m_Socket.setSendBufferSize(1024);
/*     */       
/* 162 */       this.m_ModbusTransport = new ModbusUDPTransport(this);
/* 163 */       this.m_Active = true;
/*     */     }
/* 165 */     if (Modbus.debug) {
/* 166 */       System.out.println("UDPMasterTerminal::activated");
/*     */     }
/*     */   }
/*     */   
/*     */   public void deactivate()
/*     */   {
/*     */     try
/*     */     {
/* 174 */       if (Modbus.debug) {
/* 175 */         System.out.println("UDPMasterTerminal::deactivate()");
/*     */       }
/* 177 */       this.m_Socket.close();
/* 178 */       this.m_ModbusTransport = null;
/* 179 */       this.m_Active = false;
/*     */     } catch (Exception ex) {
/* 181 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusUDPTransport getModbusTransport()
/*     */   {
/* 192 */     return this.m_ModbusTransport;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTimeout()
/*     */   {
/* 201 */     return this.m_Timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeout(int timeout)
/*     */   {
/* 211 */     this.m_Timeout = timeout;
/*     */   }
/*     */   
/*     */   public void sendMessage(byte[] msg) throws Exception
/*     */   {
/* 216 */     DatagramPacket req = new DatagramPacket(msg, msg.length, 
/* 217 */       this.m_RemoteAddress, this.m_RemotePort);
/* 218 */     synchronized (this.m_Socket) {
/* 219 */       this.m_Socket.send(req);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] receiveMessage()
/*     */     throws Exception
/*     */   {
/* 229 */     byte[] buffer = new byte['Ć'];
/* 230 */     DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
/* 231 */     synchronized (this.m_Socket) {
/* 232 */       this.m_Socket.setSoTimeout(this.m_Timeout);
/* 233 */       this.m_Socket.receive(packet);
/*     */     }
/* 235 */     return buffer;
/*     */   }
/*     */   
/*     */   public void receiveMessage(byte[] buffer) throws Exception {
/* 239 */     DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
/* 240 */     synchronized (this.m_Socket) {
/* 241 */       this.m_Socket.setSoTimeout(this.m_Timeout);
/* 242 */       this.m_Socket.receive(packet);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected UDPMasterTerminal(InetAddress addr)
/*     */   {
/* 252 */     this.m_RemoteAddress = addr;
/*     */   }
/*     */   
/*     */   public UDPMasterTerminal() {}
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\UDPMasterTerminal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */