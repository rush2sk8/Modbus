/*     */ package com.ghgande.j2mod.modbus.net;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransport;
/*     */ import java.net.InetAddress;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class UDPMasterConnection
/*     */ {
/*     */   private UDPMasterTerminal m_Terminal;
/*  52 */   private int m_Timeout = 3000;
/*     */   
/*     */   private boolean m_Connected;
/*     */   private InetAddress m_Address;
/*  56 */   private int m_Port = 502;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UDPMasterConnection(InetAddress adr)
/*     */   {
/*  65 */     this.m_Address = adr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void connect()
/*     */     throws Exception
/*     */   {
/*  75 */     if (!this.m_Connected) {
/*  76 */       this.m_Terminal = new UDPMasterTerminal();
/*  77 */       this.m_Terminal.setLocalAddress(InetAddress.getLocalHost());
/*  78 */       this.m_Terminal.setLocalPort(5000);
/*  79 */       this.m_Terminal.setRemoteAddress(this.m_Address);
/*  80 */       this.m_Terminal.setRemotePort(this.m_Port);
/*  81 */       this.m_Terminal.setTimeout(this.m_Timeout);
/*  82 */       this.m_Terminal.activate();
/*  83 */       this.m_Connected = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/*  91 */     if (this.m_Connected) {
/*     */       try {
/*  93 */         this.m_Terminal.deactivate();
/*     */       } catch (Exception ex) {
/*  95 */         if (Modbus.debug) ex.printStackTrace();
/*     */       }
/*  97 */       this.m_Connected = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusTransport getModbusTransport()
/*     */   {
/* 108 */     return this.m_Terminal.getModbusTransport();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public UDPTerminal getTerminal()
/*     */   {
/* 117 */     return this.m_Terminal;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTimeout()
/*     */   {
/* 126 */     return this.m_Timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeout(int timeout)
/*     */   {
/* 135 */     this.m_Timeout = timeout;
/* 136 */     this.m_Terminal.setTimeout(timeout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 146 */     return this.m_Port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 157 */     this.m_Port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InetAddress getAddress()
/*     */   {
/* 167 */     return this.m_Address;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAddress(InetAddress adr)
/*     */   {
/* 177 */     this.m_Address = adr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isConnected()
/*     */   {
/* 186 */     return this.m_Connected;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\UDPMasterConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */