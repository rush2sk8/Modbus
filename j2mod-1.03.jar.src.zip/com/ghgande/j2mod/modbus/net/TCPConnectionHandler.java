/*    */ package com.ghgande.j2mod.modbus.net;
/*    */ 
/*    */ import com.ghgande.j2mod.modbus.io.ModbusTransport;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TCPConnectionHandler
/*    */   implements Runnable
/*    */ {
/*    */   private TCPSlaveConnection m_Connection;
/*    */   private ModbusTransport m_Transport;
/*    */   
/*    */   public TCPConnectionHandler(TCPSlaveConnection con)
/*    */   {
/* 66 */     setConnection(con);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setConnection(TCPSlaveConnection con)
/*    */   {
/* 77 */     this.m_Connection = con;
/* 78 */     this.m_Transport = this.m_Connection.getModbusTransport();
/*    */   }
/*    */   
/*    */   /* Error */
/*    */   public void run()
/*    */   {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: getfield 33	com/ghgande/j2mod/modbus/net/TCPConnectionHandler:m_Transport	Lcom/ghgande/j2mod/modbus/io/ModbusTransport;
/*    */     //   4: invokeinterface 36 1 0
/*    */     //   9: astore_1
/*    */     //   10: aconst_null
/*    */     //   11: astore_2
/*    */     //   12: invokestatic 42	com/ghgande/j2mod/modbus/ModbusCoupler:getReference	()Lcom/ghgande/j2mod/modbus/ModbusCoupler;
/*    */     //   15: invokevirtual 48	com/ghgande/j2mod/modbus/ModbusCoupler:getProcessImage	()Lcom/ghgande/j2mod/modbus/procimg/ProcessImage;
/*    */     //   18: astore_3
/*    */     //   19: aload_3
/*    */     //   20: ifnonnull +6 -> 26
/*    */     //   23: goto -23 -> 0
/*    */     //   26: aload_3
/*    */     //   27: invokeinterface 52 1 0
/*    */     //   32: ifeq +19 -> 51
/*    */     //   35: aload_1
/*    */     //   36: invokevirtual 58	com/ghgande/j2mod/modbus/msg/ModbusRequest:getUnitID	()I
/*    */     //   39: aload_3
/*    */     //   40: invokeinterface 52 1 0
/*    */     //   45: if_icmpeq +6 -> 51
/*    */     //   48: goto -48 -> 0
/*    */     //   51: aload_1
/*    */     //   52: invokevirtual 61	com/ghgande/j2mod/modbus/msg/ModbusRequest:createResponse	()Lcom/ghgande/j2mod/modbus/msg/ModbusResponse;
/*    */     //   55: astore_2
/*    */     //   56: getstatic 65	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*    */     //   59: ifeq +53 -> 112
/*    */     //   62: getstatic 71	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   65: new 77	java/lang/StringBuilder
/*    */     //   68: dup
/*    */     //   69: ldc 79
/*    */     //   71: invokespecial 81	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*    */     //   74: aload_1
/*    */     //   75: invokevirtual 84	com/ghgande/j2mod/modbus/msg/ModbusRequest:getHexMessage	()Ljava/lang/String;
/*    */     //   78: invokevirtual 88	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   81: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*    */     //   84: invokevirtual 95	java/io/PrintStream:println	(Ljava/lang/String;)V
/*    */     //   87: getstatic 71	java/lang/System:out	Ljava/io/PrintStream;
/*    */     //   90: new 77	java/lang/StringBuilder
/*    */     //   93: dup
/*    */     //   94: ldc 100
/*    */     //   96: invokespecial 81	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*    */     //   99: aload_2
/*    */     //   100: invokevirtual 102	com/ghgande/j2mod/modbus/msg/ModbusResponse:getHexMessage	()Ljava/lang/String;
/*    */     //   103: invokevirtual 88	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   106: invokevirtual 92	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*    */     //   109: invokevirtual 95	java/io/PrintStream:println	(Ljava/lang/String;)V
/*    */     //   112: aload_0
/*    */     //   113: getfield 33	com/ghgande/j2mod/modbus/net/TCPConnectionHandler:m_Transport	Lcom/ghgande/j2mod/modbus/io/ModbusTransport;
/*    */     //   116: aload_2
/*    */     //   117: invokeinterface 105 2 0
/*    */     //   122: goto -122 -> 0
/*    */     //   125: astore_1
/*    */     //   126: aload_1
/*    */     //   127: invokevirtual 109	com/ghgande/j2mod/modbus/ModbusIOException:isEOF	()Z
/*    */     //   130: ifne +13 -> 143
/*    */     //   133: getstatic 65	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*    */     //   136: ifeq +7 -> 143
/*    */     //   139: aload_1
/*    */     //   140: invokevirtual 115	com/ghgande/j2mod/modbus/ModbusIOException:printStackTrace	()V
/*    */     //   143: aload_0
/*    */     //   144: getfield 25	com/ghgande/j2mod/modbus/net/TCPConnectionHandler:m_Connection	Lcom/ghgande/j2mod/modbus/net/TCPSlaveConnection;
/*    */     //   147: invokevirtual 118	com/ghgande/j2mod/modbus/net/TCPSlaveConnection:close	()V
/*    */     //   150: goto +25 -> 175
/*    */     //   153: astore 5
/*    */     //   155: goto +20 -> 175
/*    */     //   158: astore 4
/*    */     //   160: aload_0
/*    */     //   161: getfield 25	com/ghgande/j2mod/modbus/net/TCPConnectionHandler:m_Connection	Lcom/ghgande/j2mod/modbus/net/TCPSlaveConnection;
/*    */     //   164: invokevirtual 118	com/ghgande/j2mod/modbus/net/TCPSlaveConnection:close	()V
/*    */     //   167: goto +5 -> 172
/*    */     //   170: astore 5
/*    */     //   172: aload 4
/*    */     //   174: athrow
/*    */     //   175: return
/*    */     // Line number table:
/*    */     //   Java source line #85	-> byte code offset #0
/*    */     //   Java source line #86	-> byte code offset #10
/*    */     //   Java source line #91	-> byte code offset #12
/*    */     //   Java source line #92	-> byte code offset #15
/*    */     //   Java source line #91	-> byte code offset #18
/*    */     //   Java source line #93	-> byte code offset #19
/*    */     //   Java source line #98	-> byte code offset #23
/*    */     //   Java source line #100	-> byte code offset #26
/*    */     //   Java source line #101	-> byte code offset #35
/*    */     //   Java source line #106	-> byte code offset #48
/*    */     //   Java source line #110	-> byte code offset #51
/*    */     //   Java source line #112	-> byte code offset #56
/*    */     //   Java source line #113	-> byte code offset #62
/*    */     //   Java source line #114	-> byte code offset #87
/*    */     //   Java source line #118	-> byte code offset #112
/*    */     //   Java source line #119	-> byte code offset #122
/*    */     //   Java source line #120	-> byte code offset #125
/*    */     //   Java source line #121	-> byte code offset #126
/*    */     //   Java source line #122	-> byte code offset #139
/*    */     //   Java source line #125	-> byte code offset #143
/*    */     //   Java source line #126	-> byte code offset #150
/*    */     //   Java source line #123	-> byte code offset #158
/*    */     //   Java source line #125	-> byte code offset #160
/*    */     //   Java source line #126	-> byte code offset #167
/*    */     //   Java source line #129	-> byte code offset #172
/*    */     //   Java source line #130	-> byte code offset #175
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	signature
/*    */     //   0	176	0	this	TCPConnectionHandler
/*    */     //   9	66	1	request	com.ghgande.j2mod.modbus.msg.ModbusRequest
/*    */     //   125	15	1	ex	com.ghgande.j2mod.modbus.ModbusIOException
/*    */     //   11	106	2	response	com.ghgande.j2mod.modbus.msg.ModbusResponse
/*    */     //   18	22	3	image	com.ghgande.j2mod.modbus.procimg.ProcessImage
/*    */     //   158	15	4	localObject	Object
/*    */     //   153	1	5	localException	Exception
/*    */     //   170	1	5	localException1	Exception
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   0	125	125	com/ghgande/j2mod/modbus/ModbusIOException
/*    */     //   143	150	153	java/lang/Exception
/*    */     //   0	143	158	finally
/*    */     //   160	167	170	java/lang/Exception
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\TCPConnectionHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */