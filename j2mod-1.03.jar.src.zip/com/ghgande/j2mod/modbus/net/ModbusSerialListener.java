/*     */ package com.ghgande.j2mod.modbus.net;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.util.SerialParameters;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusSerialListener
/*     */   implements ModbusListener
/*     */ {
/*     */   private boolean m_Listening;
/*  89 */   private boolean m_Running = true;
/*     */   private SerialConnection m_SerialCon;
/*  91 */   private int m_Unit = 0;
/*     */   
/*     */   /* Error */
/*     */   public void run()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: iconst_1
/*     */     //   2: putfield 17	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_Listening	Z
/*     */     //   5: aload_0
/*     */     //   6: getfield 19	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_SerialCon	Lcom/ghgande/j2mod/modbus/net/SerialConnection;
/*     */     //   9: invokevirtual 21	com/ghgande/j2mod/modbus/net/SerialConnection:open	()V
/*     */     //   12: aload_0
/*     */     //   13: getfield 19	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_SerialCon	Lcom/ghgande/j2mod/modbus/net/SerialConnection;
/*     */     //   16: invokevirtual 26	com/ghgande/j2mod/modbus/net/SerialConnection:getModbusTransport	()Lcom/ghgande/j2mod/modbus/io/ModbusTransport;
/*     */     //   19: astore_1
/*     */     //   20: goto +150 -> 170
/*     */     //   23: aload_0
/*     */     //   24: getfield 17	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_Listening	Z
/*     */     //   27: ifeq +136 -> 163
/*     */     //   30: aload_1
/*     */     //   31: invokeinterface 30 1 0
/*     */     //   36: astore_2
/*     */     //   37: aload_0
/*     */     //   38: getfield 36	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_Unit	I
/*     */     //   41: ifeq +17 -> 58
/*     */     //   44: aload_0
/*     */     //   45: getfield 36	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_Unit	I
/*     */     //   48: aload_2
/*     */     //   49: invokevirtual 38	com/ghgande/j2mod/modbus/msg/ModbusRequest:getUnitID	()I
/*     */     //   52: if_icmpeq +6 -> 58
/*     */     //   55: goto +115 -> 170
/*     */     //   58: aconst_null
/*     */     //   59: astore_3
/*     */     //   60: invokestatic 44	com/ghgande/j2mod/modbus/ModbusCoupler:getReference	()Lcom/ghgande/j2mod/modbus/ModbusCoupler;
/*     */     //   63: invokevirtual 50	com/ghgande/j2mod/modbus/ModbusCoupler:getProcessImage	()Lcom/ghgande/j2mod/modbus/procimg/ProcessImage;
/*     */     //   66: ifnonnull +12 -> 78
/*     */     //   69: aload_2
/*     */     //   70: iconst_1
/*     */     //   71: invokevirtual 54	com/ghgande/j2mod/modbus/msg/ModbusRequest:createExceptionResponse	(I)Lcom/ghgande/j2mod/modbus/msg/ModbusResponse;
/*     */     //   74: astore_3
/*     */     //   75: goto +8 -> 83
/*     */     //   78: aload_2
/*     */     //   79: invokevirtual 58	com/ghgande/j2mod/modbus/msg/ModbusRequest:createResponse	()Lcom/ghgande/j2mod/modbus/msg/ModbusResponse;
/*     */     //   82: astore_3
/*     */     //   83: getstatic 62	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*     */     //   86: ifeq +53 -> 139
/*     */     //   89: getstatic 67	java/lang/System:out	Ljava/io/PrintStream;
/*     */     //   92: new 73	java/lang/StringBuilder
/*     */     //   95: dup
/*     */     //   96: ldc 75
/*     */     //   98: invokespecial 77	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   101: aload_2
/*     */     //   102: invokevirtual 81	com/ghgande/j2mod/modbus/msg/ModbusRequest:getHexMessage	()Ljava/lang/String;
/*     */     //   105: invokevirtual 85	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   108: invokevirtual 89	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   111: invokevirtual 92	java/io/PrintStream:println	(Ljava/lang/String;)V
/*     */     //   114: getstatic 67	java/lang/System:out	Ljava/io/PrintStream;
/*     */     //   117: new 73	java/lang/StringBuilder
/*     */     //   120: dup
/*     */     //   121: ldc 97
/*     */     //   123: invokespecial 77	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   126: aload_3
/*     */     //   127: invokevirtual 99	com/ghgande/j2mod/modbus/msg/ModbusResponse:getHexMessage	()Ljava/lang/String;
/*     */     //   130: invokevirtual 85	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   133: invokevirtual 89	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   136: invokevirtual 92	java/io/PrintStream:println	(Ljava/lang/String;)V
/*     */     //   139: aload_1
/*     */     //   140: aload_3
/*     */     //   141: invokeinterface 102 2 0
/*     */     //   146: goto +24 -> 170
/*     */     //   149: astore_2
/*     */     //   150: getstatic 62	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*     */     //   153: ifeq +17 -> 170
/*     */     //   156: aload_2
/*     */     //   157: invokevirtual 106	com/ghgande/j2mod/modbus/ModbusIOException:printStackTrace	()V
/*     */     //   160: goto +10 -> 170
/*     */     //   163: aload_1
/*     */     //   164: invokeinterface 30 1 0
/*     */     //   169: pop
/*     */     //   170: aload_0
/*     */     //   171: getfield 111	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_Running	Z
/*     */     //   174: ifne -151 -> 23
/*     */     //   177: goto +54 -> 231
/*     */     //   180: astore_1
/*     */     //   181: aload_1
/*     */     //   182: invokevirtual 113	java/lang/Exception:printStackTrace	()V
/*     */     //   185: aload_0
/*     */     //   186: iconst_0
/*     */     //   187: putfield 17	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_Listening	Z
/*     */     //   190: aload_0
/*     */     //   191: getfield 19	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_SerialCon	Lcom/ghgande/j2mod/modbus/net/SerialConnection;
/*     */     //   194: ifnull +56 -> 250
/*     */     //   197: aload_0
/*     */     //   198: getfield 19	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_SerialCon	Lcom/ghgande/j2mod/modbus/net/SerialConnection;
/*     */     //   201: invokevirtual 116	com/ghgande/j2mod/modbus/net/SerialConnection:close	()V
/*     */     //   204: goto +46 -> 250
/*     */     //   207: astore 4
/*     */     //   209: aload_0
/*     */     //   210: iconst_0
/*     */     //   211: putfield 17	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_Listening	Z
/*     */     //   214: aload_0
/*     */     //   215: getfield 19	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_SerialCon	Lcom/ghgande/j2mod/modbus/net/SerialConnection;
/*     */     //   218: ifnull +10 -> 228
/*     */     //   221: aload_0
/*     */     //   222: getfield 19	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_SerialCon	Lcom/ghgande/j2mod/modbus/net/SerialConnection;
/*     */     //   225: invokevirtual 116	com/ghgande/j2mod/modbus/net/SerialConnection:close	()V
/*     */     //   228: aload 4
/*     */     //   230: athrow
/*     */     //   231: aload_0
/*     */     //   232: iconst_0
/*     */     //   233: putfield 17	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_Listening	Z
/*     */     //   236: aload_0
/*     */     //   237: getfield 19	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_SerialCon	Lcom/ghgande/j2mod/modbus/net/SerialConnection;
/*     */     //   240: ifnull +10 -> 250
/*     */     //   243: aload_0
/*     */     //   244: getfield 19	com/ghgande/j2mod/modbus/net/ModbusSerialListener:m_SerialCon	Lcom/ghgande/j2mod/modbus/net/SerialConnection;
/*     */     //   247: invokevirtual 116	com/ghgande/j2mod/modbus/net/SerialConnection:close	()V
/*     */     //   250: return
/*     */     // Line number table:
/*     */     //   Java source line #100	-> byte code offset #0
/*     */     //   Java source line #101	-> byte code offset #5
/*     */     //   Java source line #103	-> byte code offset #12
/*     */     //   Java source line #105	-> byte code offset #20
/*     */     //   Java source line #106	-> byte code offset #23
/*     */     //   Java source line #114	-> byte code offset #30
/*     */     //   Java source line #115	-> byte code offset #37
/*     */     //   Java source line #116	-> byte code offset #55
/*     */     //   Java source line #123	-> byte code offset #58
/*     */     //   Java source line #124	-> byte code offset #60
/*     */     //   Java source line #125	-> byte code offset #69
/*     */     //   Java source line #126	-> byte code offset #70
/*     */     //   Java source line #125	-> byte code offset #74
/*     */     //   Java source line #127	-> byte code offset #75
/*     */     //   Java source line #128	-> byte code offset #78
/*     */     //   Java source line #134	-> byte code offset #83
/*     */     //   Java source line #135	-> byte code offset #89
/*     */     //   Java source line #136	-> byte code offset #101
/*     */     //   Java source line #135	-> byte code offset #111
/*     */     //   Java source line #138	-> byte code offset #114
/*     */     //   Java source line #139	-> byte code offset #126
/*     */     //   Java source line #138	-> byte code offset #136
/*     */     //   Java source line #145	-> byte code offset #139
/*     */     //   Java source line #146	-> byte code offset #146
/*     */     //   Java source line #147	-> byte code offset #150
/*     */     //   Java source line #148	-> byte code offset #156
/*     */     //   Java source line #150	-> byte code offset #160
/*     */     //   Java source line #157	-> byte code offset #163
/*     */     //   Java source line #105	-> byte code offset #170
/*     */     //   Java source line #160	-> byte code offset #177
/*     */     //   Java source line #165	-> byte code offset #181
/*     */     //   Java source line #167	-> byte code offset #185
/*     */     //   Java source line #169	-> byte code offset #190
/*     */     //   Java source line #170	-> byte code offset #197
/*     */     //   Java source line #166	-> byte code offset #207
/*     */     //   Java source line #167	-> byte code offset #209
/*     */     //   Java source line #169	-> byte code offset #214
/*     */     //   Java source line #170	-> byte code offset #221
/*     */     //   Java source line #172	-> byte code offset #228
/*     */     //   Java source line #167	-> byte code offset #231
/*     */     //   Java source line #169	-> byte code offset #236
/*     */     //   Java source line #170	-> byte code offset #243
/*     */     //   Java source line #173	-> byte code offset #250
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	251	0	this	ModbusSerialListener
/*     */     //   19	145	1	transport	com.ghgande.j2mod.modbus.io.ModbusTransport
/*     */     //   180	2	1	e	Exception
/*     */     //   36	66	2	request	com.ghgande.j2mod.modbus.msg.ModbusRequest
/*     */     //   149	8	2	ex	com.ghgande.j2mod.modbus.ModbusIOException
/*     */     //   59	82	3	response	com.ghgande.j2mod.modbus.msg.ModbusResponse
/*     */     //   207	22	4	localObject	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   30	55	149	com/ghgande/j2mod/modbus/ModbusIOException
/*     */     //   58	146	149	com/ghgande/j2mod/modbus/ModbusIOException
/*     */     //   0	177	180	java/lang/Exception
/*     */     //   0	185	207	finally
/*     */   }
/*     */   
/*     */   public void setUnit(int unit)
/*     */   {
/* 182 */     this.m_Unit = unit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUnit()
/*     */   {
/* 191 */     return this.m_Unit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setListening(boolean b)
/*     */   {
/* 202 */     this.m_Listening = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isListening()
/*     */   {
/* 213 */     return this.m_Listening;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/* 220 */     this.m_Listening = false;
/* 221 */     this.m_Running = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Thread listen()
/*     */   {
/* 228 */     this.m_Listening = true;
/* 229 */     Thread result = new Thread(this);
/* 230 */     result.start();
/*     */     
/* 232 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusSerialListener(SerialParameters params)
/*     */   {
/* 242 */     this.m_SerialCon = new SerialConnection(params);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\ModbusSerialListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */