/*     */ package com.ghgande.j2mod.modbus.net;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTCPTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransport;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TCPMasterConnection
/*     */ {
/*     */   private Socket m_Socket;
/*  54 */   private int m_Timeout = 3000;
/*     */   
/*     */   private boolean m_Connected;
/*     */   private InetAddress m_Address;
/*  58 */   private int m_Port = 502;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private ModbusTCPTransport m_ModbusTransport;
/*     */   
/*     */ 
/*     */ 
/*  67 */   private boolean m_useUrgentData = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prepareTransport()
/*     */     throws IOException
/*     */   {
/*  77 */     if (this.m_ModbusTransport == null) {
/*  78 */       this.m_ModbusTransport = new ModbusTCPTransport(this.m_Socket);
/*     */     } else {
/*  80 */       this.m_ModbusTransport.setSocket(this.m_Socket);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void connect()
/*     */     throws Exception
/*     */   {
/*  91 */     if (!isConnected()) {
/*  92 */       if (Modbus.debug) {
/*  93 */         System.out.println("connect()");
/*     */       }
/*  95 */       this.m_Socket = new Socket(this.m_Address, this.m_Port);
/*  96 */       this.m_Socket.setReuseAddress(true);
/*  97 */       this.m_Socket.setSoLinger(true, 1);
/*  98 */       this.m_Socket.setKeepAlive(true);
/*     */       
/* 100 */       setTimeout(this.m_Timeout);
/* 101 */       prepareTransport();
/*     */       
/* 103 */       this.m_Connected = true;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean isConnected()
/*     */   {
/* 113 */     if ((this.m_Connected) && (this.m_Socket != null)) {
/* 114 */       if ((!this.m_Socket.isConnected()) || (this.m_Socket.isClosed()) || 
/* 115 */         (this.m_Socket.isInputShutdown()) || 
/* 116 */         (this.m_Socket.isOutputShutdown())) {
/*     */         try {
/* 118 */           this.m_Socket.close();
/*     */         }
/*     */         catch (IOException localIOException1) {}
/*     */         
/* 122 */         this.m_Connected = false;
/*     */       } else {
/*     */         try {
/* 125 */           this.m_Socket.sendUrgentData(0);
/*     */         } catch (IOException e) {
/* 127 */           this.m_Connected = false;
/*     */           try {
/* 129 */             this.m_Socket.close();
/*     */           }
/*     */           catch (IOException localIOException2) {}
/*     */         }
/*     */       }
/*     */     }
/*     */     
/* 136 */     return this.m_Connected;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 143 */     if (this.m_Connected) {
/*     */       try {
/* 145 */         this.m_ModbusTransport.close();
/*     */       } catch (IOException ex) {
/* 147 */         if (Modbus.debug)
/* 148 */           System.out.println("close()");
/*     */       }
/* 150 */       this.m_Connected = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusTransport getModbusTransport()
/*     */   {
/* 161 */     return this.m_ModbusTransport;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setModbusTransport(ModbusTCPTransport trans)
/*     */   {
/* 169 */     this.m_ModbusTransport = trans;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTimeout()
/*     */   {
/* 178 */     return this.m_Timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeout(int timeout)
/*     */   {
/* 188 */     this.m_Timeout = timeout;
/*     */     try {
/* 190 */       this.m_Socket.setSoTimeout(this.m_Timeout);
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 202 */     return this.m_Port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 213 */     this.m_Port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InetAddress getAddress()
/*     */   {
/* 223 */     return this.m_Address;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAddress(InetAddress adr)
/*     */   {
/* 234 */     this.m_Address = adr;
/*     */   }
/*     */   
/*     */   public boolean getUseUrgentData() {
/* 238 */     return this.m_useUrgentData;
/*     */   }
/*     */   
/*     */   public void setUseUrgentData(boolean b) {
/* 242 */     this.m_useUrgentData = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TCPMasterConnection(InetAddress adr)
/*     */   {
/* 253 */     this.m_Address = adr;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\TCPMasterConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */