/*     */ package com.ghgande.j2mod.modbus.net;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransport;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusUDPListener
/*     */   implements ModbusListener
/*     */ {
/*  91 */   private int m_Port = 502;
/*  92 */   private boolean m_Listening = false;
/*  93 */   private boolean m_Continue = false;
/*     */   private InetAddress m_Interface;
/*     */   private UDPSlaveTerminal m_Terminal;
/*     */   private ModbusTransport m_Transport;
/*  97 */   private int m_Unit = 0;
/*     */   
/*     */   public int getUnit() {
/* 100 */     return this.m_Unit;
/*     */   }
/*     */   
/*     */   public void setUnit(int unit) {
/* 104 */     this.m_Unit = unit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 114 */     return this.m_Port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 125 */     this.m_Port = (port > 0 ? port : 502);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public void run()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 39	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Interface	Ljava/net/InetAddress;
/*     */     //   4: ifnonnull +22 -> 26
/*     */     //   7: aload_0
/*     */     //   8: new 41	com/ghgande/j2mod/modbus/net/UDPSlaveTerminal
/*     */     //   11: dup
/*     */     //   12: ldc 43
/*     */     //   14: invokestatic 45	java/net/InetAddress:getByName	(Ljava/lang/String;)Ljava/net/InetAddress;
/*     */     //   17: invokespecial 51	com/ghgande/j2mod/modbus/net/UDPSlaveTerminal:<init>	(Ljava/net/InetAddress;)V
/*     */     //   20: putfield 55	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Terminal	Lcom/ghgande/j2mod/modbus/net/UDPSlaveTerminal;
/*     */     //   23: goto +18 -> 41
/*     */     //   26: aload_0
/*     */     //   27: new 41	com/ghgande/j2mod/modbus/net/UDPSlaveTerminal
/*     */     //   30: dup
/*     */     //   31: aload_0
/*     */     //   32: getfield 39	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Interface	Ljava/net/InetAddress;
/*     */     //   35: invokespecial 51	com/ghgande/j2mod/modbus/net/UDPSlaveTerminal:<init>	(Ljava/net/InetAddress;)V
/*     */     //   38: putfield 55	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Terminal	Lcom/ghgande/j2mod/modbus/net/UDPSlaveTerminal;
/*     */     //   41: aload_0
/*     */     //   42: getfield 55	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Terminal	Lcom/ghgande/j2mod/modbus/net/UDPSlaveTerminal;
/*     */     //   45: aload_0
/*     */     //   46: getfield 32	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Port	I
/*     */     //   49: invokevirtual 57	com/ghgande/j2mod/modbus/net/UDPSlaveTerminal:setLocalPort	(I)V
/*     */     //   52: aload_0
/*     */     //   53: getfield 55	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Terminal	Lcom/ghgande/j2mod/modbus/net/UDPSlaveTerminal;
/*     */     //   56: invokevirtual 60	com/ghgande/j2mod/modbus/net/UDPSlaveTerminal:activate	()V
/*     */     //   59: aload_0
/*     */     //   60: new 63	com/ghgande/j2mod/modbus/io/ModbusUDPTransport
/*     */     //   63: dup
/*     */     //   64: aload_0
/*     */     //   65: getfield 55	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Terminal	Lcom/ghgande/j2mod/modbus/net/UDPSlaveTerminal;
/*     */     //   68: invokespecial 65	com/ghgande/j2mod/modbus/io/ModbusUDPTransport:<init>	(Lcom/ghgande/j2mod/modbus/net/UDPTerminal;)V
/*     */     //   71: putfield 68	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Transport	Lcom/ghgande/j2mod/modbus/io/ModbusTransport;
/*     */     //   74: goto +20 -> 94
/*     */     //   77: astore_1
/*     */     //   78: getstatic 70	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*     */     //   81: ifeq +7 -> 88
/*     */     //   84: aload_1
/*     */     //   85: invokevirtual 75	java/lang/Exception:printStackTrace	()V
/*     */     //   88: aload_0
/*     */     //   89: iconst_0
/*     */     //   90: putfield 80	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Listening	Z
/*     */     //   93: return
/*     */     //   94: aload_0
/*     */     //   95: iconst_1
/*     */     //   96: putfield 80	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Listening	Z
/*     */     //   99: aload_0
/*     */     //   100: iconst_1
/*     */     //   101: putfield 82	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Continue	Z
/*     */     //   104: goto +104 -> 208
/*     */     //   107: aload_0
/*     */     //   108: getfield 68	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Transport	Lcom/ghgande/j2mod/modbus/io/ModbusTransport;
/*     */     //   111: invokeinterface 84 1 0
/*     */     //   116: astore_1
/*     */     //   117: aconst_null
/*     */     //   118: astore_2
/*     */     //   119: invokestatic 90	com/ghgande/j2mod/modbus/ModbusCoupler:getReference	()Lcom/ghgande/j2mod/modbus/ModbusCoupler;
/*     */     //   122: invokevirtual 96	com/ghgande/j2mod/modbus/ModbusCoupler:getProcessImage	()Lcom/ghgande/j2mod/modbus/procimg/ProcessImage;
/*     */     //   125: ifnonnull +12 -> 137
/*     */     //   128: aload_1
/*     */     //   129: iconst_1
/*     */     //   130: invokevirtual 100	com/ghgande/j2mod/modbus/msg/ModbusRequest:createExceptionResponse	(I)Lcom/ghgande/j2mod/modbus/msg/ModbusResponse;
/*     */     //   133: astore_2
/*     */     //   134: goto +8 -> 142
/*     */     //   137: aload_1
/*     */     //   138: invokevirtual 106	com/ghgande/j2mod/modbus/msg/ModbusRequest:createResponse	()Lcom/ghgande/j2mod/modbus/msg/ModbusResponse;
/*     */     //   141: astore_2
/*     */     //   142: getstatic 70	com/ghgande/j2mod/modbus/Modbus:debug	Z
/*     */     //   145: ifeq +53 -> 198
/*     */     //   148: getstatic 110	java/lang/System:err	Ljava/io/PrintStream;
/*     */     //   151: new 116	java/lang/StringBuilder
/*     */     //   154: dup
/*     */     //   155: ldc 118
/*     */     //   157: invokespecial 120	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   160: aload_1
/*     */     //   161: invokevirtual 123	com/ghgande/j2mod/modbus/msg/ModbusRequest:getHexMessage	()Ljava/lang/String;
/*     */     //   164: invokevirtual 127	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   167: invokevirtual 131	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   170: invokevirtual 134	java/io/PrintStream:println	(Ljava/lang/String;)V
/*     */     //   173: getstatic 110	java/lang/System:err	Ljava/io/PrintStream;
/*     */     //   176: new 116	java/lang/StringBuilder
/*     */     //   179: dup
/*     */     //   180: ldc -117
/*     */     //   182: invokespecial 120	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
/*     */     //   185: aload_2
/*     */     //   186: invokevirtual 141	com/ghgande/j2mod/modbus/msg/ModbusResponse:getHexMessage	()Ljava/lang/String;
/*     */     //   189: invokevirtual 127	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
/*     */     //   192: invokevirtual 131	java/lang/StringBuilder:toString	()Ljava/lang/String;
/*     */     //   195: invokevirtual 134	java/io/PrintStream:println	(Ljava/lang/String;)V
/*     */     //   198: aload_0
/*     */     //   199: getfield 68	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Transport	Lcom/ghgande/j2mod/modbus/io/ModbusTransport;
/*     */     //   202: aload_2
/*     */     //   203: invokeinterface 144 2 0
/*     */     //   208: aload_0
/*     */     //   209: getfield 82	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Continue	Z
/*     */     //   212: ifne -105 -> 107
/*     */     //   215: goto +63 -> 278
/*     */     //   218: astore_1
/*     */     //   219: aload_1
/*     */     //   220: invokevirtual 148	com/ghgande/j2mod/modbus/ModbusIOException:isEOF	()Z
/*     */     //   223: ifne +7 -> 230
/*     */     //   226: aload_1
/*     */     //   227: invokevirtual 154	com/ghgande/j2mod/modbus/ModbusIOException:printStackTrace	()V
/*     */     //   230: aload_0
/*     */     //   231: getfield 55	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Terminal	Lcom/ghgande/j2mod/modbus/net/UDPSlaveTerminal;
/*     */     //   234: invokevirtual 155	com/ghgande/j2mod/modbus/net/UDPSlaveTerminal:deactivate	()V
/*     */     //   237: aload_0
/*     */     //   238: getfield 68	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Transport	Lcom/ghgande/j2mod/modbus/io/ModbusTransport;
/*     */     //   241: invokeinterface 158 1 0
/*     */     //   246: goto +53 -> 299
/*     */     //   249: astore 4
/*     */     //   251: goto +48 -> 299
/*     */     //   254: astore_3
/*     */     //   255: aload_0
/*     */     //   256: getfield 55	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Terminal	Lcom/ghgande/j2mod/modbus/net/UDPSlaveTerminal;
/*     */     //   259: invokevirtual 155	com/ghgande/j2mod/modbus/net/UDPSlaveTerminal:deactivate	()V
/*     */     //   262: aload_0
/*     */     //   263: getfield 68	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Transport	Lcom/ghgande/j2mod/modbus/io/ModbusTransport;
/*     */     //   266: invokeinterface 158 1 0
/*     */     //   271: goto +5 -> 276
/*     */     //   274: astore 4
/*     */     //   276: aload_3
/*     */     //   277: athrow
/*     */     //   278: aload_0
/*     */     //   279: getfield 55	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Terminal	Lcom/ghgande/j2mod/modbus/net/UDPSlaveTerminal;
/*     */     //   282: invokevirtual 155	com/ghgande/j2mod/modbus/net/UDPSlaveTerminal:deactivate	()V
/*     */     //   285: aload_0
/*     */     //   286: getfield 68	com/ghgande/j2mod/modbus/net/ModbusUDPListener:m_Transport	Lcom/ghgande/j2mod/modbus/io/ModbusTransport;
/*     */     //   289: invokeinterface 158 1 0
/*     */     //   294: goto +5 -> 299
/*     */     //   297: astore 4
/*     */     //   299: return
/*     */     // Line number table:
/*     */     //   Java source line #133	-> byte code offset #0
/*     */     //   Java source line #134	-> byte code offset #7
/*     */     //   Java source line #135	-> byte code offset #12
/*     */     //   Java source line #134	-> byte code offset #20
/*     */     //   Java source line #136	-> byte code offset #23
/*     */     //   Java source line #137	-> byte code offset #26
/*     */     //   Java source line #139	-> byte code offset #41
/*     */     //   Java source line #140	-> byte code offset #52
/*     */     //   Java source line #142	-> byte code offset #59
/*     */     //   Java source line #143	-> byte code offset #74
/*     */     //   Java source line #148	-> byte code offset #78
/*     */     //   Java source line #149	-> byte code offset #84
/*     */     //   Java source line #151	-> byte code offset #88
/*     */     //   Java source line #152	-> byte code offset #93
/*     */     //   Java source line #155	-> byte code offset #94
/*     */     //   Java source line #156	-> byte code offset #99
/*     */     //   Java source line #159	-> byte code offset #104
/*     */     //   Java source line #165	-> byte code offset #107
/*     */     //   Java source line #166	-> byte code offset #117
/*     */     //   Java source line #171	-> byte code offset #119
/*     */     //   Java source line #172	-> byte code offset #128
/*     */     //   Java source line #173	-> byte code offset #129
/*     */     //   Java source line #172	-> byte code offset #133
/*     */     //   Java source line #174	-> byte code offset #134
/*     */     //   Java source line #175	-> byte code offset #137
/*     */     //   Java source line #178	-> byte code offset #142
/*     */     //   Java source line #179	-> byte code offset #148
/*     */     //   Java source line #181	-> byte code offset #173
/*     */     //   Java source line #183	-> byte code offset #198
/*     */     //   Java source line #159	-> byte code offset #208
/*     */     //   Java source line #185	-> byte code offset #215
/*     */     //   Java source line #186	-> byte code offset #219
/*     */     //   Java source line #188	-> byte code offset #226
/*     */     //   Java source line #192	-> byte code offset #230
/*     */     //   Java source line #193	-> byte code offset #237
/*     */     //   Java source line #194	-> byte code offset #246
/*     */     //   Java source line #190	-> byte code offset #254
/*     */     //   Java source line #192	-> byte code offset #255
/*     */     //   Java source line #193	-> byte code offset #262
/*     */     //   Java source line #194	-> byte code offset #271
/*     */     //   Java source line #197	-> byte code offset #276
/*     */     //   Java source line #192	-> byte code offset #278
/*     */     //   Java source line #193	-> byte code offset #285
/*     */     //   Java source line #194	-> byte code offset #294
/*     */     //   Java source line #198	-> byte code offset #299
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	300	0	this	ModbusUDPListener
/*     */     //   77	8	1	e	Exception
/*     */     //   116	45	1	request	com.ghgande.j2mod.modbus.msg.ModbusRequest
/*     */     //   218	9	1	ex	com.ghgande.j2mod.modbus.ModbusIOException
/*     */     //   118	85	2	response	com.ghgande.j2mod.modbus.msg.ModbusResponse
/*     */     //   254	23	3	localObject	Object
/*     */     //   249	1	4	localException1	Exception
/*     */     //   274	1	4	localException2	Exception
/*     */     //   297	1	4	localException3	Exception
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   0	74	77	java/lang/Exception
/*     */     //   104	215	218	com/ghgande/j2mod/modbus/ModbusIOException
/*     */     //   230	246	249	java/lang/Exception
/*     */     //   104	230	254	finally
/*     */     //   255	271	274	java/lang/Exception
/*     */     //   278	294	297	java/lang/Exception
/*     */   }
/*     */   
/*     */   public void stop()
/*     */   {
/* 204 */     this.m_Terminal.deactivate();
/* 205 */     this.m_Listening = false;
/* 206 */     this.m_Continue = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setListening(boolean listen)
/*     */   {
/* 218 */     this.m_Listening = listen;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isListening()
/*     */   {
/* 229 */     return this.m_Listening;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Thread listen()
/*     */   {
/* 236 */     this.m_Listening = true;
/* 237 */     Thread result = new Thread(this);
/* 238 */     result.start();
/*     */     
/* 240 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusUDPListener(InetAddress ifc)
/*     */   {
/* 251 */     this.m_Interface = ifc;
/* 252 */     this.m_Listening = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModbusUDPListener()
/*     */   {
/*     */     try
/*     */     {
/* 261 */       this.m_Interface = InetAddress.getByAddress(new byte[4]);
/*     */     }
/*     */     catch (UnknownHostException localUnknownHostException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\ModbusUDPListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */