package com.ghgande.j2mod.modbus.net;

import com.ghgande.j2mod.modbus.io.ModbusUDPTransport;
import java.net.InetAddress;

public abstract interface UDPTerminal
{
  public abstract InetAddress getLocalAddress();
  
  public abstract int getLocalPort();
  
  public abstract boolean isActive();
  
  public abstract void activate()
    throws Exception;
  
  public abstract void deactivate();
  
  public abstract ModbusUDPTransport getModbusTransport();
  
  public abstract void sendMessage(byte[] paramArrayOfByte)
    throws Exception;
  
  public abstract byte[] receiveMessage()
    throws Exception;
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\UDPTerminal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */