/*     */ package com.ghgande.j2mod.modbus.net;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusASCIITransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusBINTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusRTUTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusSerialTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransport;
/*     */ import com.ghgande.j2mod.modbus.util.SerialParameters;
/*     */ import gnu.io.CommPortIdentifier;
/*     */ import gnu.io.NoSuchPortException;
/*     */ import gnu.io.PortInUseException;
/*     */ import gnu.io.RXTXPort;
/*     */ import gnu.io.SerialPort;
/*     */ import gnu.io.SerialPortEvent;
/*     */ import gnu.io.SerialPortEventListener;
/*     */ import gnu.io.UnsupportedCommOperationException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.TooManyListenersException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerialConnection
/*     */   implements SerialPortEventListener
/*     */ {
/*     */   private SerialParameters m_Parameters;
/*     */   private ModbusSerialTransport m_Transport;
/*     */   private SerialPort m_SerialPort;
/*     */   private boolean m_Open;
/*     */   private InputStream m_SerialIn;
/*     */   
/*     */   public ModbusTransport getModbusTransport()
/*     */   {
/* 102 */     return this.m_Transport;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void open()
/*     */     throws Exception
/*     */   {
/*     */     try
/*     */     {
/* 118 */       CommPortIdentifier m_PortIdentifier = 
/* 119 */         CommPortIdentifier.getPortIdentifier(this.m_Parameters.getPortName());
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 124 */       this.m_SerialPort = ((SerialPort)m_PortIdentifier.open(
/* 125 */         "Modbus Serial Master", 30000));
/*     */     } catch (PortInUseException e) {
/* 127 */       if (Modbus.debug) {
/* 128 */         System.out.println(e.getMessage());
/*     */       }
/* 130 */       throw new Exception(e.getMessage());
/*     */ 
/*     */     }
/*     */     catch (NoSuchPortException e)
/*     */     {
/*     */ 
/*     */       try
/*     */       {
/* 138 */         this.m_SerialPort = new RXTXPort(this.m_Parameters.getPortName());
/*     */       } catch (PortInUseException x) {
/* 140 */         if (Modbus.debug) {
/* 141 */           x.printStackTrace();
/*     */         }
/* 143 */         throw new Exception(x.getMessage());
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 148 */       setConnectionParameters();
/*     */     }
/*     */     catch (Exception e) {
/* 151 */       this.m_SerialPort.close();
/* 152 */       if (Modbus.debug)
/* 153 */         System.out.println(e.getMessage());
/* 154 */       throw e;
/*     */     }
/*     */     
/* 157 */     if ("ascii".equals(this.m_Parameters.getEncoding())) {
/* 158 */       this.m_Transport = new ModbusASCIITransport();
/*     */     }
/* 160 */     else if ("rtu".equals(this.m_Parameters.getEncoding())) {
/* 161 */       this.m_Transport = new ModbusRTUTransport();
/*     */     }
/* 163 */     else if ("bin".equals(this.m_Parameters.getEncoding())) {
/* 164 */       this.m_Transport = new ModbusBINTransport();
/*     */     }
/* 166 */     this.m_Transport.setEcho(this.m_Parameters.isEcho());
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 171 */       this.m_SerialIn = this.m_SerialPort.getInputStream();
/* 172 */       this.m_Transport.setCommPort(this.m_SerialPort);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 176 */       this.m_SerialPort.close();
/* 177 */       if (Modbus.debug) {
/* 178 */         System.out.println(e.getMessage());
/*     */       }
/* 180 */       throw new Exception("Error opening i/o streams");
/*     */     }
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 186 */       this.m_SerialPort.addEventListener(this);
/*     */     } catch (TooManyListenersException e) {
/* 188 */       this.m_SerialPort.close();
/* 189 */       if (Modbus.debug)
/* 190 */         System.out.println(e.getMessage());
/* 191 */       throw new Exception("too many listeners added");
/*     */     }
/*     */     
/*     */ 
/* 195 */     this.m_SerialPort.notifyOnBreakInterrupt(true);
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 200 */       this.m_SerialPort.enableReceiveTimeout(200);
/*     */     } catch (UnsupportedCommOperationException e) {
/* 202 */       if (Modbus.debug) {
/* 203 */         System.out.println(e.getMessage());
/*     */       }
/*     */     }
/* 206 */     this.m_Open = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnectionParameters()
/*     */     throws Exception
/*     */   {
/* 221 */     int oldBaudRate = this.m_SerialPort.getBaudRate();
/* 222 */     int oldDatabits = this.m_SerialPort.getDataBits();
/* 223 */     int oldStopbits = this.m_SerialPort.getStopBits();
/* 224 */     int oldParity = this.m_SerialPort.getParity();
/* 225 */     int oldFlowControl = this.m_SerialPort.getFlowControlMode();
/*     */     
/*     */ 
/*     */     try
/*     */     {
/* 230 */       this.m_SerialPort.setSerialPortParams(this.m_Parameters.getBaudRate(), 
/* 231 */         this.m_Parameters.getDatabits(), this.m_Parameters.getStopbits(), 
/* 232 */         this.m_Parameters.getParity());
/*     */     } catch (UnsupportedCommOperationException e) {
/* 234 */       this.m_Parameters.setBaudRate(oldBaudRate);
/* 235 */       this.m_Parameters.setDatabits(oldDatabits);
/* 236 */       this.m_Parameters.setStopbits(oldStopbits);
/* 237 */       this.m_Parameters.setParity(oldParity);
/* 238 */       this.m_Parameters.setFlowControlIn(oldFlowControl);
/*     */       
/* 240 */       if (Modbus.debug) {
/* 241 */         System.out.println(e.getMessage());
/*     */       }
/* 243 */       throw new Exception("Unsupported parameter");
/*     */     }
/*     */     
/*     */     try
/*     */     {
/* 248 */       this.m_SerialPort.setFlowControlMode(this.m_Parameters.getFlowControlIn() | 
/* 249 */         this.m_Parameters.getFlowControlOut());
/*     */     } catch (UnsupportedCommOperationException e) {
/* 251 */       if (Modbus.debug) {
/* 252 */         System.out.println(e.getMessage());
/*     */       }
/* 254 */       throw new Exception("Unsupported flow control");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 263 */     if (!this.m_Open) {
/* 264 */       return;
/*     */     }
/*     */     
/*     */ 
/* 268 */     if (this.m_SerialPort != null) {
/*     */       try {
/* 270 */         this.m_Transport.close();
/* 271 */         this.m_SerialIn.close();
/*     */       } catch (IOException e) {
/* 273 */         System.err.println(e);
/*     */       }
/*     */       
/* 276 */       this.m_SerialPort.close();
/*     */     }
/* 278 */     this.m_Open = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isOpen()
/*     */   {
/* 287 */     return this.m_Open;
/*     */   }
/*     */   
/*     */   public void serialEvent(SerialPortEvent e)
/*     */   {
/* 292 */     switch (e.getEventType())
/*     */     {
/*     */     case 1: 
/*     */       break;
/*     */     
/*     */     case 10: 
/* 298 */       if (Modbus.debug) {
/* 299 */         System.out.println("Serial port break detected");
/*     */       }
/* 301 */       break;
/*     */     default: 
/* 303 */       if (Modbus.debug) {
/* 304 */         System.out.println("Serial port event: " + e.getEventType());
/*     */       }
/*     */       
/*     */ 
/*     */       break;
/*     */     }
/*     */     
/*     */   }
/*     */   
/*     */ 
/*     */   public SerialConnection(SerialParameters parameters)
/*     */   {
/* 316 */     this.m_Parameters = parameters;
/* 317 */     this.m_Open = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\SerialConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */