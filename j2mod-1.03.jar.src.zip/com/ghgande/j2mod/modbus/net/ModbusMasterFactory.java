/*     */ package com.ghgande.j2mod.modbus.net;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusRTUTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTCPTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusUDPTransport;
/*     */ import com.ghgande.j2mod.modbus.util.SerialParameters;
/*     */ import gnu.io.CommPort;
/*     */ import gnu.io.PortInUseException;
/*     */ import gnu.io.RXTXPort;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusMasterFactory
/*     */ {
/*     */   public static ModbusTransport createModbusMaster(String address)
/*     */   {
/*  28 */     String[] parts = address.split(":");
/*  29 */     if ((parts == null) || (parts.length < 2)) {
/*  30 */       throw new IllegalArgumentException("missing connection information");
/*     */     }
/*  32 */     if (parts[0].toLowerCase().equals("device"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  39 */       SerialParameters parms = new SerialParameters();
/*  40 */       parms.setPortName(parts[1]);
/*  41 */       parms.setBaudRate(19200);
/*  42 */       parms.setDatabits(8);
/*  43 */       parms.setEcho(false);
/*  44 */       parms.setParity(0);
/*  45 */       parms.setFlowControlIn(0);
/*     */       try
/*     */       {
/*  48 */         ModbusRTUTransport transport = new ModbusRTUTransport();
/*  49 */         CommPort port = new RXTXPort(parms.getPortName());
/*     */         
/*  51 */         transport.setCommPort(port);
/*  52 */         transport.setEcho(false);
/*     */         
/*  54 */         return transport;
/*     */       } catch (PortInUseException e) {
/*  56 */         return null;
/*     */       } catch (IOException e) {
/*  58 */         return null;
/*     */       } }
/*  60 */     if (parts[0].toLowerCase().equals("tcp"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */       String hostName = parts[1];
/*  67 */       int port = 502;
/*     */       
/*  69 */       if (parts.length > 2) {
/*  70 */         port = Integer.parseInt(parts[2]);
/*     */       }
/*     */       try {
/*  73 */         Socket socket = new Socket(hostName, port);
/*  74 */         if (Modbus.debug) {
/*  75 */           System.err.println("connecting to " + socket);
/*     */         }
/*  77 */         return new ModbusTCPTransport(socket);
/*     */       }
/*     */       catch (UnknownHostException x)
/*     */       {
/*  81 */         return null;
/*     */       } catch (IOException e) {
/*  83 */         return null;
/*     */       } }
/*  85 */     if (parts[0].toLowerCase().equals("udp"))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  91 */       String hostName = parts[1];
/*  92 */       int port = 502;
/*     */       
/*  94 */       if (parts.length > 2) {
/*  95 */         port = Integer.parseInt(parts[2]);
/*     */       }
/*     */       try
/*     */       {
/*  99 */         UDPMasterTerminal terminal = new UDPMasterTerminal(
/* 100 */           InetAddress.getByName(hostName));
/* 101 */         terminal.setRemotePort(port);
/* 102 */         terminal.activate();
/*     */       } catch (UnknownHostException e) {
/* 104 */         e.printStackTrace();
/* 105 */         return null;
/*     */       } catch (Exception e) {
/* 107 */         e.printStackTrace();
/* 108 */         return null;
/*     */       }
/*     */       UDPMasterTerminal terminal;
/* 111 */       ModbusUDPTransport transport = terminal.getModbusTransport();
/*     */       
/* 113 */       return transport;
/*     */     }
/* 115 */     throw new IllegalArgumentException("unknown type " + parts[0]);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\ModbusMasterFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */