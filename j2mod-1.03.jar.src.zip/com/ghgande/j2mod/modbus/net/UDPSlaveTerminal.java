/*     */ package com.ghgande.j2mod.modbus.net;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusUDPTransport;
/*     */ import com.ghgande.j2mod.modbus.util.LinkedQueue;
/*     */ import com.ghgande.j2mod.modbus.util.ModbusUtil;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.DatagramPacket;
/*     */ import java.net.DatagramSocket;
/*     */ import java.net.InetAddress;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class UDPSlaveTerminal
/*     */   implements UDPTerminal
/*     */ {
/*     */   private DatagramSocket m_Socket;
/*  55 */   private int m_Timeout = 3000;
/*     */   private boolean m_Active;
/*     */   protected InetAddress m_LocalAddress;
/*  58 */   private int m_LocalPort = 502;
/*     */   
/*     */   protected ModbusUDPTransport m_ModbusTransport;
/*     */   private LinkedQueue m_SendQueue;
/*     */   private LinkedQueue m_ReceiveQueue;
/*     */   private PacketSender m_PacketSender;
/*     */   private PacketReceiver m_PacketReceiver;
/*     */   private Thread m_Receiver;
/*     */   private Thread m_Sender;
/*     */   protected Hashtable<Integer, DatagramPacket> m_Requests;
/*     */   
/*     */   protected UDPSlaveTerminal()
/*     */   {
/*  71 */     this.m_SendQueue = new LinkedQueue();
/*  72 */     this.m_ReceiveQueue = new LinkedQueue();
/*  73 */     this.m_Requests = new Hashtable(342);
/*     */   }
/*     */   
/*     */   protected UDPSlaveTerminal(InetAddress localaddress) {
/*  77 */     this.m_LocalAddress = localaddress;
/*  78 */     this.m_SendQueue = new LinkedQueue();
/*  79 */     this.m_ReceiveQueue = new LinkedQueue();
/*  80 */     this.m_Requests = new Hashtable(342);
/*     */   }
/*     */   
/*     */   public InetAddress getLocalAddress() {
/*  84 */     return this.m_LocalAddress;
/*     */   }
/*     */   
/*     */   public int getLocalPort() {
/*  88 */     return this.m_LocalPort;
/*     */   }
/*     */   
/*     */   protected void setLocalPort(int port) {
/*  92 */     this.m_LocalPort = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isActive()
/*     */   {
/* 101 */     return this.m_Active;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void activate()
/*     */     throws Exception
/*     */   {
/* 111 */     if (!isActive()) {
/* 112 */       if (Modbus.debug)
/* 113 */         System.out.println("UDPSlaveTerminal.activate()");
/* 114 */       if (this.m_Socket == null) {
/* 115 */         if ((this.m_LocalAddress != null) && (this.m_LocalPort != -1)) {
/* 116 */           this.m_Socket = new DatagramSocket(this.m_LocalPort, this.m_LocalAddress);
/*     */         } else {
/* 118 */           this.m_Socket = new DatagramSocket();
/* 119 */           this.m_LocalPort = this.m_Socket.getLocalPort();
/* 120 */           this.m_LocalAddress = this.m_Socket.getLocalAddress();
/*     */         }
/*     */       }
/* 123 */       if (Modbus.debug)
/* 124 */         System.out.println("UDPSlaveTerminal::haveSocket():" + 
/* 125 */           this.m_Socket.toString());
/* 126 */       if (Modbus.debug) {
/* 127 */         System.out.println("UDPSlaveTerminal::addr=:" + 
/* 128 */           this.m_LocalAddress.toString() + ":port=" + this.m_LocalPort);
/*     */       }
/* 130 */       this.m_Socket.setReceiveBufferSize(1024);
/* 131 */       this.m_Socket.setSendBufferSize(1024);
/* 132 */       this.m_PacketReceiver = new PacketReceiver();
/* 133 */       this.m_Receiver = new Thread(this.m_PacketReceiver);
/* 134 */       this.m_Receiver.start();
/* 135 */       if (Modbus.debug)
/* 136 */         System.out.println("UDPSlaveTerminal::receiver started()");
/* 137 */       this.m_PacketSender = new PacketSender();
/* 138 */       this.m_Sender = new Thread(this.m_PacketSender);
/* 139 */       this.m_Sender.start();
/* 140 */       if (Modbus.debug)
/* 141 */         System.out.println("UDPSlaveTerminal::sender started()");
/* 142 */       this.m_ModbusTransport = new ModbusUDPTransport(this);
/* 143 */       if (Modbus.debug)
/* 144 */         System.out.println("UDPSlaveTerminal::transport created");
/* 145 */       this.m_Active = true;
/*     */     }
/* 147 */     if (Modbus.debug) {
/* 148 */       System.out.println("UDPSlaveTerminal::activated");
/*     */     }
/*     */   }
/*     */   
/*     */   public void deactivate()
/*     */   {
/*     */     try
/*     */     {
/* 156 */       if (this.m_Active)
/*     */       {
/* 158 */         this.m_PacketReceiver.stop();
/* 159 */         this.m_Receiver.join();
/*     */         
/* 161 */         this.m_PacketSender.stop();
/* 162 */         this.m_Sender.join();
/*     */         
/* 164 */         this.m_Socket.close();
/* 165 */         this.m_ModbusTransport = null;
/* 166 */         this.m_Active = false;
/*     */       }
/*     */     } catch (Exception ex) {
/* 169 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusUDPTransport getModbusTransport()
/*     */   {
/* 180 */     return this.m_ModbusTransport;
/*     */   }
/*     */   
/*     */   protected boolean hasResponse() {
/* 184 */     return !this.m_ReceiveQueue.isEmpty();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeout(int timeout)
/*     */   {
/* 200 */     this.m_Timeout = timeout;
/*     */     try
/*     */     {
/* 203 */       this.m_Socket.setSoTimeout(this.m_Timeout);
/*     */     } catch (IOException ex) {
/* 205 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DatagramSocket getSocket()
/*     */   {
/* 215 */     return this.m_Socket;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setSocket(DatagramSocket sock)
/*     */   {
/* 225 */     this.m_Socket = sock;
/*     */   }
/*     */   
/*     */   public void sendMessage(byte[] msg) throws Exception {
/* 229 */     this.m_SendQueue.put(msg);
/*     */   }
/*     */   
/*     */   public byte[] receiveMessage() throws Exception {
/* 233 */     return (byte[])this.m_ReceiveQueue.take();
/*     */   }
/*     */   
/*     */   class PacketSender implements Runnable
/*     */   {
/*     */     private boolean m_Continue;
/*     */     
/*     */     public PacketSender() {
/* 241 */       this.m_Continue = true;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/*     */       do {
/*     */         try {
/* 248 */           byte[] message = (byte[])UDPSlaveTerminal.this.m_SendQueue.take();
/* 249 */           DatagramPacket req = 
/* 250 */             (DatagramPacket)UDPSlaveTerminal.this.m_Requests.remove(new Integer(
/* 251 */             ModbusUtil.registersToInt(message)));
/*     */           
/* 253 */           DatagramPacket res = new DatagramPacket(message, 
/* 254 */             message.length, req.getAddress(), req.getPort());
/* 255 */           UDPSlaveTerminal.this.m_Socket.send(res);
/* 256 */           if (Modbus.debug)
/* 257 */             System.out.println("Sent package from queue.");
/*     */         } catch (Exception ex) {
/* 259 */           ex.printStackTrace();
/*     */         }
/* 261 */       } while ((this.m_Continue) || (!UDPSlaveTerminal.this.m_SendQueue.isEmpty()));
/*     */     }
/*     */     
/*     */     public void stop() {
/* 265 */       this.m_Continue = false;
/*     */     }
/*     */   }
/*     */   
/*     */   class PacketReceiver implements Runnable
/*     */   {
/*     */     private boolean m_Continue;
/*     */     
/*     */     public PacketReceiver()
/*     */     {
/* 275 */       this.m_Continue = true;
/*     */     }
/*     */     
/*     */     public void run()
/*     */     {
/*     */       do {
/*     */         try {
/* 282 */           byte[] buffer = new byte['Ā'];
/* 283 */           DatagramPacket packet = new DatagramPacket(buffer, 
/* 284 */             buffer.length);
/* 285 */           UDPSlaveTerminal.this.m_Socket.receive(packet);
/*     */           
/* 287 */           Integer tid = new Integer(ModbusUtil.registersToInt(buffer));
/* 288 */           UDPSlaveTerminal.this.m_Requests.put(tid, packet);
/*     */           
/* 290 */           UDPSlaveTerminal.this.m_ReceiveQueue.put(buffer);
/* 291 */           if (Modbus.debug)
/* 292 */             System.out.println("Received package to queue.");
/*     */         } catch (Exception ex) {
/* 294 */           ex.printStackTrace();
/*     */         }
/* 296 */       } while (this.m_Continue);
/*     */     }
/*     */     
/*     */     public void stop() {
/* 300 */       this.m_Continue = false;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\UDPSlaveTerminal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */