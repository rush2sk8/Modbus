/*     */ package com.ghgande.j2mod.modbus.net;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTCPTransport;
/*     */ import com.ghgande.j2mod.modbus.io.ModbusTransport;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TCPSlaveConnection
/*     */ {
/*     */   private Socket m_Socket;
/*  54 */   private int m_Unit = 0;
/*  55 */   private int m_Timeout = 3000;
/*     */   
/*     */ 
/*     */   private boolean m_Connected;
/*     */   
/*     */ 
/*     */   private ModbusTCPTransport m_ModbusTransport;
/*     */   
/*     */ 
/*     */   public TCPSlaveConnection(Socket socket)
/*     */   {
/*     */     try
/*     */     {
/*  68 */       setSocket(socket);
/*     */     } catch (IOException ex) {
/*  70 */       if (Modbus.debug) {
/*  71 */         System.out.println("TCPSlaveConnection::Socket invalid.");
/*     */       }
/*  73 */       throw new IllegalStateException("Socket invalid.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public TCPSlaveConnection(Socket socket, int unit)
/*     */   {
/*  87 */     this.m_Unit = unit;
/*     */     try
/*     */     {
/*  90 */       setSocket(socket);
/*     */     } catch (IOException ex) {
/*  92 */       if (Modbus.debug) {
/*  93 */         System.out.println("TCPSlaveConnection::Socket invalid.");
/*     */       }
/*  95 */       throw new IllegalStateException("Socket invalid.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void close()
/*     */   {
/* 103 */     if (this.m_Connected) {
/*     */       try {
/* 105 */         this.m_ModbusTransport.close();
/* 106 */         this.m_Socket.close();
/*     */       } catch (IOException ex) {
/* 108 */         if (Modbus.debug)
/* 109 */           ex.printStackTrace();
/*     */       }
/* 111 */       this.m_Connected = false;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusTransport getModbusTransport()
/*     */   {
/* 122 */     return this.m_ModbusTransport;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setSocket(Socket socket)
/*     */     throws IOException
/*     */   {
/* 135 */     this.m_Socket = socket;
/*     */     
/* 137 */     if (this.m_ModbusTransport == null) {
/* 138 */       this.m_ModbusTransport = new ModbusTCPTransport(this.m_Socket);
/*     */     } else {
/* 140 */       this.m_ModbusTransport.setSocket(this.m_Socket);
/*     */     }
/* 142 */     this.m_Connected = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTimeout()
/*     */   {
/* 151 */     return this.m_Timeout;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTimeout(int timeout)
/*     */   {
/* 161 */     this.m_Timeout = timeout;
/*     */     try
/*     */     {
/* 164 */       this.m_Socket.setSoTimeout(this.m_Timeout);
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getPort()
/*     */   {
/* 176 */     return this.m_Socket.getLocalPort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InetAddress getAddress()
/*     */   {
/* 186 */     return this.m_Socket.getLocalAddress();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUnitNumber()
/*     */   {
/* 197 */     return this.m_Unit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isConnected()
/*     */   {
/* 206 */     return this.m_Connected;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\TCPSlaveConnection.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */