/*     */ package com.ghgande.j2mod.modbus.net;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.util.ThreadPool;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusTCPListener
/*     */   implements ModbusListener
/*     */ {
/*  93 */   private ServerSocket m_ServerSocket = null;
/*     */   private ThreadPool m_ThreadPool;
/*     */   private Thread m_Listener;
/*  96 */   private int m_Port = 502;
/*  97 */   private int m_Unit = 0;
/*  98 */   private int m_FloodProtection = 5;
/*     */   
/*     */ 
/*     */   private boolean m_Listening;
/*     */   
/*     */ 
/*     */   private InetAddress m_Address;
/*     */   
/*     */ 
/*     */   public void setPort(int port)
/*     */   {
/* 109 */     this.m_Port = port;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUnit()
/*     */   {
/* 122 */     return this.m_Unit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUnit(int unit)
/*     */   {
/* 134 */     this.m_Unit = unit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setAddress(InetAddress addr)
/*     */   {
/* 144 */     this.m_Address = addr;
/*     */   }
/*     */   
/*     */ 
/*     */   /**
/*     */    * @deprecated
/*     */    */
/*     */   public void start()
/*     */   {
/* 153 */     this.m_Listening = true;
/*     */     
/* 155 */     this.m_Listener = new Thread(this);
/* 156 */     this.m_Listener.start();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void stop()
/*     */   {
/* 163 */     this.m_Listening = false;
/*     */     try {
/* 165 */       this.m_ServerSocket.close();
/* 166 */       this.m_Listener.join();
/*     */     }
/*     */     catch (Exception localException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 185 */       this.m_ServerSocket = new ServerSocket(this.m_Port, this.m_FloodProtection, 
/* 186 */         this.m_Address);
/* 187 */       if (Modbus.debug) {
/* 188 */         System.out.println("Listenening to " + 
/* 189 */           this.m_ServerSocket.toString() + "(Port " + this.m_Port + ")");
/*     */       }
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 196 */       this.m_Listening = true;
/* 197 */       while (this.m_Listening) {
/* 198 */         Socket incoming = this.m_ServerSocket.accept();
/* 199 */         if (Modbus.debug) {
/* 200 */           System.out.println("Making new connection " + 
/* 201 */             incoming.toString());
/*     */         }
/* 203 */         if (this.m_Listening)
/*     */         {
/* 205 */           this.m_ThreadPool.execute(new TCPConnectionHandler(
/* 206 */             new TCPSlaveConnection(incoming)));
/*     */         } else {
/* 208 */           incoming.close();
/*     */         }
/*     */       }
/*     */     } catch (SocketException iex) {
/* 212 */       if (!this.m_Listening) {
/* 213 */         return;
/*     */       }
/* 215 */       if (Modbus.debug) {
/* 216 */         iex.printStackTrace();
/*     */       }
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setListening(boolean b)
/*     */   {
/* 231 */     this.m_Listening = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isListening()
/*     */   {
/* 242 */     return this.m_Listening;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public Thread listen()
/*     */   {
/* 249 */     this.m_Listening = true;
/* 250 */     Thread result = new Thread(this);
/* 251 */     result.start();
/*     */     
/* 253 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusTCPListener(int poolsize, InetAddress addr)
/*     */   {
/* 266 */     this.m_ThreadPool = new ThreadPool(poolsize);
/* 267 */     this.m_Address = addr;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusTCPListener(int poolsize)
/*     */   {
/* 281 */     this.m_ThreadPool = new ThreadPool(poolsize);
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 287 */       this.m_Address = InetAddress.getByAddress(new byte[4]);
/*     */     }
/*     */     catch (UnknownHostException localUnknownHostException) {}
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\net\ModbusTCPListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */