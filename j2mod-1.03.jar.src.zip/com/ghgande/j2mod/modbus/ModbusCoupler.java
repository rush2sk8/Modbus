/*     */ package com.ghgande.j2mod.modbus;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.procimg.DefaultProcessImageFactory;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImageFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusCoupler
/*     */ {
/*     */   private static ModbusCoupler c_Self;
/*     */   private ProcessImage m_ProcessImage;
/*  58 */   private int m_UnitID = 0;
/*  59 */   private boolean m_Master = true;
/*     */   
/*     */   private ProcessImageFactory m_PIFactory;
/*     */   
/*     */ 
/*     */   private ModbusCoupler()
/*     */   {
/*  66 */     this.m_PIFactory = new DefaultProcessImageFactory();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private ModbusCoupler(ProcessImage procimg)
/*     */   {
/*  76 */     setProcessImage(procimg);
/*  77 */     c_Self = this;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ProcessImageFactory getProcessImageFactory()
/*     */   {
/*  86 */     return this.m_PIFactory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProcessImageFactory(ProcessImageFactory factory)
/*     */   {
/*  96 */     this.m_PIFactory = factory;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized ProcessImage getProcessImage()
/*     */   {
/* 106 */     return this.m_ProcessImage;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setProcessImage(ProcessImage procimg)
/*     */   {
/* 117 */     this.m_ProcessImage = procimg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getUnitID()
/*     */   {
/* 127 */     return this.m_UnitID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUnitID(int id)
/*     */   {
/* 138 */     this.m_UnitID = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMaster()
/*     */   {
/* 147 */     return this.m_Master;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isSlave()
/*     */   {
/* 156 */     return !this.m_Master;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setMaster(boolean master)
/*     */   {
/* 166 */     this.m_Master = master;
/*     */   }
/*     */   
/*     */   public static final boolean isInitialized() {
/* 170 */     return c_Self != null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final synchronized ModbusCoupler getReference()
/*     */   {
/* 179 */     if (c_Self == null) {
/* 180 */       return c_Self = new ModbusCoupler();
/*     */     }
/* 182 */     return c_Self;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\ModbusCoupler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */