/*     */ package com.ghgande.j2mod.modbus.procimg;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleProcessImage
/*     */   implements ProcessImageImplementation
/*     */ {
/*     */   protected Vector<DigitalIn> m_DigitalInputs;
/*     */   protected Vector<DigitalOut> m_DigitalOutputs;
/*     */   protected Vector<InputRegister> m_InputRegisters;
/*     */   protected Vector<Register> m_Registers;
/*     */   protected Vector<File> m_Files;
/*     */   protected Vector<FIFO> m_FIFOs;
/*  94 */   protected boolean m_Locked = false;
/*  95 */   protected int m_Unit = 0;
/*     */   
/*     */ 
/*     */ 
/*     */   public SimpleProcessImage()
/*     */   {
/* 101 */     this.m_DigitalInputs = new Vector();
/* 102 */     this.m_DigitalOutputs = new Vector();
/* 103 */     this.m_InputRegisters = new Vector();
/* 104 */     this.m_Registers = new Vector();
/* 105 */     this.m_Files = new Vector();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleProcessImage(int unit)
/*     */   {
/* 113 */     this.m_DigitalInputs = new Vector();
/* 114 */     this.m_DigitalOutputs = new Vector();
/* 115 */     this.m_InputRegisters = new Vector();
/* 116 */     this.m_Registers = new Vector();
/* 117 */     this.m_Files = new Vector();
/* 118 */     this.m_Unit = unit;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean isLocked()
/*     */   {
/* 127 */     return this.m_Locked;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized boolean setLocked(boolean locked)
/*     */   {
/* 143 */     if ((this.m_Locked) && (locked)) {
/* 144 */       return false;
/*     */     }
/* 146 */     this.m_Locked = locked;
/* 147 */     return true;
/*     */   }
/*     */   
/*     */   public int getUnitID() {
/* 151 */     return this.m_Unit;
/*     */   }
/*     */   
/*     */   public void addDigitalIn(DigitalIn di) {
/* 155 */     if (!isLocked()) {
/* 156 */       this.m_DigitalInputs.addElement(di);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeDigitalIn(DigitalIn di) {
/* 161 */     if (!isLocked()) {
/* 162 */       this.m_DigitalInputs.removeElement(di);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setDigitalIn(int ref, DigitalIn di) throws IllegalAddressException
/*     */   {
/* 168 */     if (!isLocked()) {
/*     */       try {
/* 170 */         this.m_DigitalInputs.setElementAt(di, ref);
/*     */       } catch (IndexOutOfBoundsException ex) {
/* 172 */         throw new IllegalAddressException();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public DigitalIn getDigitalIn(int ref) throws IllegalAddressException {
/*     */     try {
/* 179 */       return (DigitalIn)this.m_DigitalInputs.elementAt(ref);
/*     */     } catch (IndexOutOfBoundsException ex) {
/* 181 */       throw new IllegalAddressException();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getDigitalInCount() {
/* 186 */     return this.m_DigitalInputs.size();
/*     */   }
/*     */   
/*     */   public DigitalIn[] getDigitalInRange(int ref, int count)
/*     */   {
/* 191 */     if ((ref < 0) || (ref + count > this.m_DigitalInputs.size())) {
/* 192 */       throw new IllegalAddressException();
/*     */     }
/* 194 */     DigitalIn[] dins = new DigitalIn[count];
/* 195 */     for (int i = 0; i < dins.length; i++) {
/* 196 */       dins[i] = getDigitalIn(ref + i);
/*     */     }
/* 198 */     return dins;
/*     */   }
/*     */   
/*     */   public void addDigitalOut(DigitalOut _do)
/*     */   {
/* 203 */     if (!isLocked()) {
/* 204 */       this.m_DigitalOutputs.addElement(_do);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeDigitalOut(DigitalOut _do) {
/* 209 */     if (!isLocked()) {
/* 210 */       this.m_DigitalOutputs.removeElement(_do);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setDigitalOut(int ref, DigitalOut _do) throws IllegalAddressException
/*     */   {
/* 216 */     if (!isLocked()) {
/*     */       try {
/* 218 */         this.m_DigitalOutputs.setElementAt(_do, ref);
/*     */       } catch (IndexOutOfBoundsException ex) {
/* 220 */         throw new IllegalAddressException();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public DigitalOut getDigitalOut(int ref) throws IllegalAddressException {
/*     */     try {
/* 227 */       return (DigitalOut)this.m_DigitalOutputs.elementAt(ref);
/*     */     } catch (IndexOutOfBoundsException ex) {
/* 229 */       throw new IllegalAddressException();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getDigitalOutCount() {
/* 234 */     return this.m_DigitalOutputs.size();
/*     */   }
/*     */   
/*     */   public DigitalOut[] getDigitalOutRange(int ref, int count)
/*     */   {
/* 239 */     if ((ref < 0) || (ref + count > this.m_DigitalOutputs.size())) {
/* 240 */       throw new IllegalAddressException();
/*     */     }
/* 242 */     DigitalOut[] douts = new DigitalOut[count];
/* 243 */     for (int i = 0; i < douts.length; i++) {
/* 244 */       douts[i] = getDigitalOut(ref + i);
/*     */     }
/* 246 */     return douts;
/*     */   }
/*     */   
/*     */   public void addInputRegister(InputRegister reg)
/*     */   {
/* 251 */     if (!isLocked()) {
/* 252 */       this.m_InputRegisters.addElement(reg);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeInputRegister(InputRegister reg) {
/* 257 */     if (!isLocked()) {
/* 258 */       this.m_InputRegisters.removeElement(reg);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setInputRegister(int ref, InputRegister reg) throws IllegalAddressException
/*     */   {
/* 264 */     if (!isLocked()) {
/*     */       try {
/* 266 */         this.m_InputRegisters.setElementAt(reg, ref);
/*     */       } catch (IndexOutOfBoundsException ex) {
/* 268 */         throw new IllegalAddressException();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public InputRegister getInputRegister(int ref) throws IllegalAddressException
/*     */   {
/*     */     try {
/* 276 */       return (InputRegister)this.m_InputRegisters.elementAt(ref);
/*     */     } catch (IndexOutOfBoundsException ex) {
/* 278 */       throw new IllegalAddressException();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getInputRegisterCount() {
/* 283 */     return this.m_InputRegisters.size();
/*     */   }
/*     */   
/*     */   public InputRegister[] getInputRegisterRange(int ref, int count)
/*     */   {
/* 288 */     if ((ref < 0) || (ref + count > this.m_InputRegisters.size())) {
/* 289 */       throw new IllegalAddressException();
/*     */     }
/* 291 */     InputRegister[] iregs = new InputRegister[count];
/* 292 */     for (int i = 0; i < iregs.length; i++) {
/* 293 */       iregs[i] = getInputRegister(ref + i);
/*     */     }
/* 295 */     return iregs;
/*     */   }
/*     */   
/*     */   public void addRegister(Register reg) {
/* 299 */     if (!isLocked()) {
/* 300 */       this.m_Registers.addElement(reg);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeRegister(Register reg) {
/* 305 */     if (!isLocked()) {
/* 306 */       this.m_Registers.removeElement(reg);
/*     */     }
/*     */   }
/*     */   
/*     */   public void setRegister(int ref, Register reg) throws IllegalAddressException
/*     */   {
/* 312 */     if (!isLocked()) {
/*     */       try {
/* 314 */         this.m_Registers.setElementAt(reg, ref);
/*     */       } catch (IndexOutOfBoundsException ex) {
/* 316 */         throw new IllegalAddressException();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Register getRegister(int ref) throws IllegalAddressException {
/*     */     try {
/* 323 */       return (Register)this.m_Registers.elementAt(ref);
/*     */     } catch (IndexOutOfBoundsException ex) {
/* 325 */       throw new IllegalAddressException();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getRegisterCount() {
/* 330 */     return this.m_Registers.size();
/*     */   }
/*     */   
/*     */   public Register[] getRegisterRange(int ref, int count) {
/* 334 */     if ((ref < 0) || (ref + count > this.m_Registers.size())) {
/* 335 */       throw new IllegalAddressException();
/*     */     }
/* 337 */     Register[] iregs = new Register[count];
/* 338 */     for (int i = 0; i < iregs.length; i++) {
/* 339 */       iregs[i] = getRegister(ref + i);
/*     */     }
/* 341 */     return iregs;
/*     */   }
/*     */   
/*     */   public void addFile(File newFile)
/*     */   {
/* 346 */     if (!isLocked())
/* 347 */       this.m_Files.add(newFile);
/*     */   }
/*     */   
/*     */   public void removeFile(File oldFile) {
/* 351 */     if (!isLocked())
/* 352 */       this.m_Files.removeElement(oldFile);
/*     */   }
/*     */   
/*     */   public void setFile(int fileNumber, File file) {
/* 356 */     if (!isLocked()) {
/*     */       try {
/* 358 */         this.m_Files.setElementAt(file, fileNumber);
/*     */       } catch (IndexOutOfBoundsException ex) {
/* 360 */         throw new IllegalAddressException();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public File getFile(int fileNumber) {
/*     */     try {
/* 367 */       return (File)this.m_Files.elementAt(fileNumber);
/*     */     } catch (IndexOutOfBoundsException ex) {
/* 369 */       throw new IllegalAddressException();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getFileCount() {
/* 374 */     return this.m_Files.size();
/*     */   }
/*     */   
/*     */   public File getFileByNumber(int ref) {
/* 378 */     if ((ref < 0) || (ref >= 10000) || (this.m_Files == null)) {
/* 379 */       throw new IllegalAddressException();
/*     */     }
/* 381 */     synchronized (this.m_Files) {
/* 382 */       for (File file : this.m_Files) {
/* 383 */         if (file.getFileNumber() == ref) {
/* 384 */           return file;
/*     */         }
/*     */       }
/*     */     }
/* 388 */     throw new IllegalAddressException();
/*     */   }
/*     */   
/*     */   public void addFIFO(FIFO fifo) {
/* 392 */     if (!isLocked())
/* 393 */       this.m_FIFOs.add(fifo);
/*     */   }
/*     */   
/*     */   public void removeFIFO(FIFO oldFIFO) {
/* 397 */     if (!isLocked())
/* 398 */       this.m_FIFOs.removeElement(oldFIFO);
/*     */   }
/*     */   
/*     */   public void setFIFO(int fifoNumber, FIFO fifo) {
/* 402 */     if (!isLocked()) {
/*     */       try {
/* 404 */         this.m_FIFOs.setElementAt(fifo, fifoNumber);
/*     */       } catch (IndexOutOfBoundsException ex) {
/* 406 */         throw new IllegalAddressException();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public FIFO getFIFO(int fifoNumber) {
/*     */     try {
/* 413 */       return (FIFO)this.m_FIFOs.elementAt(fifoNumber);
/*     */     } catch (IndexOutOfBoundsException ex) {
/* 415 */       throw new IllegalAddressException();
/*     */     }
/*     */   }
/*     */   
/*     */   public int getFIFOCount() {
/* 420 */     if (this.m_FIFOs == null) {
/* 421 */       return 0;
/*     */     }
/* 423 */     return this.m_FIFOs.size();
/*     */   }
/*     */   
/*     */   public FIFO getFIFOByAddress(int ref) {
/* 427 */     for (FIFO fifo : this.m_FIFOs) {
/* 428 */       if (fifo.getAddress() == ref) {
/* 429 */         return fifo;
/*     */       }
/*     */     }
/* 432 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\SimpleProcessImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */