package com.ghgande.j2mod.modbus.procimg;

public abstract interface DigitalIn
{
  public abstract boolean isSet();
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\DigitalIn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */