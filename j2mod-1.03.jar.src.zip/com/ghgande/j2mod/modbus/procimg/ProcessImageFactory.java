package com.ghgande.j2mod.modbus.procimg;

public abstract interface ProcessImageFactory
{
  public abstract ProcessImageImplementation createProcessImageImplementation();
  
  public abstract DigitalIn createDigitalIn();
  
  public abstract DigitalIn createDigitalIn(boolean paramBoolean);
  
  public abstract DigitalOut createDigitalOut();
  
  public abstract DigitalOut createDigitalOut(boolean paramBoolean);
  
  public abstract InputRegister createInputRegister();
  
  public abstract InputRegister createInputRegister(byte paramByte1, byte paramByte2);
  
  public abstract Register createRegister();
  
  public abstract Register createRegister(byte paramByte1, byte paramByte2);
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\ProcessImageFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */