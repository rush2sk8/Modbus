/*     */ package com.ghgande.j2mod.modbus.procimg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DefaultProcessImageFactory
/*     */   implements ProcessImageFactory
/*     */ {
/*     */   public ProcessImageImplementation createProcessImageImplementation()
/*     */   {
/*  54 */     return new SimpleProcessImage();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DigitalIn createDigitalIn()
/*     */   {
/*  63 */     return new SimpleDigitalIn();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DigitalIn createDigitalIn(boolean state)
/*     */   {
/*  74 */     return new SimpleDigitalIn(state);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DigitalOut createDigitalOut()
/*     */   {
/*  83 */     return new SimpleDigitalOut();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public DigitalOut createDigitalOut(boolean b)
/*     */   {
/*  94 */     return new SimpleDigitalOut(b);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputRegister createInputRegister()
/*     */   {
/* 103 */     return new SimpleInputRegister();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputRegister createInputRegister(int value)
/*     */   {
/* 115 */     return new SimpleInputRegister(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputRegister createInputRegister(byte b1, byte b2)
/*     */   {
/* 128 */     return new SimpleInputRegister(b1, b2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Register createRegister()
/*     */   {
/* 137 */     return new SimpleRegister();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Register createRegister(int value)
/*     */   {
/* 146 */     return new SimpleRegister(value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Register createRegister(byte b1, byte b2)
/*     */   {
/* 159 */     return new SimpleRegister(b1, b2);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\DefaultProcessImageFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */