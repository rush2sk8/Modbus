/*    */ package com.ghgande.j2mod.modbus.procimg;
/*    */ 
/*    */ import com.ghgande.j2mod.modbus.util.Observable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObservableRegister
/*    */   extends Observable
/*    */   implements Register
/*    */ {
/*    */   protected short m_Register;
/*    */   
/*    */   public int getValue()
/*    */   {
/* 52 */     return this.m_Register & 0xFFFF;
/*    */   }
/*    */   
/*    */   public final int toUnsignedShort() {
/* 56 */     return this.m_Register & 0xFFFF;
/*    */   }
/*    */   
/*    */   public final short toShort() {
/* 60 */     return this.m_Register;
/*    */   }
/*    */   
/*    */   public byte[] toBytes() {
/* 64 */     byte[] result = { (byte)(this.m_Register >> 8), 
/* 65 */       (byte)(this.m_Register & 0xFF) };
/* 66 */     return result;
/*    */   }
/*    */   
/*    */   public final synchronized void setValue(int v) {
/* 70 */     this.m_Register = ((short)v);
/* 71 */     notifyObservers("value");
/*    */   }
/*    */   
/*    */   public final synchronized void setValue(short s) {
/* 75 */     this.m_Register = s;
/* 76 */     notifyObservers("value");
/*    */   }
/*    */   
/*    */   public final synchronized void setValue(byte[] bytes) {
/* 80 */     if (bytes.length < 2) {
/* 81 */       throw new IllegalArgumentException();
/*    */     }
/* 83 */     this.m_Register = 
/* 84 */       ((short)((short)(bytes[0] << 8) | (short)bytes[1] & 0xFF));
/* 85 */     notifyObservers("value");
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\ObservableRegister.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */