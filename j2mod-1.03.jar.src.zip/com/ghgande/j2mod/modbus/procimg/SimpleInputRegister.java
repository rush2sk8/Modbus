/*     */ package com.ghgande.j2mod.modbus.procimg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SimpleInputRegister
/*     */   extends SynchronizedAbstractRegister
/*     */   implements InputRegister
/*     */ {
/*     */   public String toString()
/*     */   {
/*  82 */     if (this.m_Register == null) {
/*  83 */       return "invalid";
/*     */     }
/*  85 */     return getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleInputRegister() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleInputRegister(byte b1, byte b2)
/*     */   {
/* 104 */     this.m_Register[0] = b1;
/* 105 */     this.m_Register[1] = b2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SimpleInputRegister(int value)
/*     */   {
/* 117 */     setValue(value);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\SimpleInputRegister.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */