package com.ghgande.j2mod.modbus.procimg;

public abstract interface ProcessImage
{
  public abstract int getUnitID();
  
  public abstract DigitalOut[] getDigitalOutRange(int paramInt1, int paramInt2)
    throws IllegalAddressException;
  
  public abstract DigitalOut getDigitalOut(int paramInt)
    throws IllegalAddressException;
  
  public abstract int getDigitalOutCount();
  
  public abstract DigitalIn[] getDigitalInRange(int paramInt1, int paramInt2)
    throws IllegalAddressException;
  
  public abstract DigitalIn getDigitalIn(int paramInt)
    throws IllegalAddressException;
  
  public abstract int getDigitalInCount();
  
  public abstract InputRegister[] getInputRegisterRange(int paramInt1, int paramInt2)
    throws IllegalAddressException;
  
  public abstract InputRegister getInputRegister(int paramInt)
    throws IllegalAddressException;
  
  public abstract int getInputRegisterCount();
  
  public abstract Register[] getRegisterRange(int paramInt1, int paramInt2)
    throws IllegalAddressException;
  
  public abstract Register getRegister(int paramInt)
    throws IllegalAddressException;
  
  public abstract int getRegisterCount();
  
  public abstract File getFile(int paramInt)
    throws IllegalAddressException;
  
  public abstract File getFileByNumber(int paramInt)
    throws IllegalAddressException;
  
  public abstract int getFileCount();
  
  public abstract FIFO getFIFO(int paramInt)
    throws IllegalAddressException;
  
  public abstract FIFO getFIFOByAddress(int paramInt)
    throws IllegalAddressException;
  
  public abstract int getFIFOCount();
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\ProcessImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */