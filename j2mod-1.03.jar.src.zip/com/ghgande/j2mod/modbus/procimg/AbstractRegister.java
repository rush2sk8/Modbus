/*    */ package com.ghgande.j2mod.modbus.procimg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class AbstractRegister
/*    */   implements Register
/*    */ {
/* 48 */   protected byte[] m_Register = new byte[2];
/*    */   
/*    */   public int getValue() {
/* 51 */     return (this.m_Register[0] & 0xFF) << 8 | this.m_Register[1] & 0xFF;
/*    */   }
/*    */   
/*    */   public final int toUnsignedShort() {
/* 55 */     return (this.m_Register[0] & 0xFF) << 8 | this.m_Register[1] & 0xFF;
/*    */   }
/*    */   
/*    */   public final void setValue(int v) {
/* 59 */     this.m_Register[0] = ((byte)(0xFF & v >> 8));
/* 60 */     this.m_Register[1] = ((byte)(0xFF & v));
/*    */   }
/*    */   
/*    */   public final short toShort() {
/* 64 */     return (short)(this.m_Register[0] << 8 | this.m_Register[1] & 0xFF);
/*    */   }
/*    */   
/*    */   public final void setValue(short s) {
/* 68 */     this.m_Register[0] = ((byte)(0xFF & s >> 8));
/* 69 */     this.m_Register[1] = ((byte)(0xFF & s));
/*    */   }
/*    */   
/*    */   public byte[] toBytes() {
/* 73 */     return this.m_Register;
/*    */   }
/*    */   
/*    */   public final void setValue(byte[] bytes) {
/* 77 */     if (bytes.length < 2) {
/* 78 */       throw new IllegalArgumentException();
/*    */     }
/* 80 */     this.m_Register[0] = bytes[0];
/* 81 */     this.m_Register[1] = bytes[1];
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\AbstractRegister.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */