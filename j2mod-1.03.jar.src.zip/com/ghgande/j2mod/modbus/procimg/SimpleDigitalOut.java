/*    */ package com.ghgande.j2mod.modbus.procimg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SimpleDigitalOut
/*    */   implements DigitalOut
/*    */ {
/*    */   protected boolean m_Set;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SimpleDigitalOut() {}
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public SimpleDigitalOut(boolean b)
/*    */   {
/* 67 */     set(b);
/*    */   }
/*    */   
/*    */   public boolean isSet() {
/* 71 */     return this.m_Set;
/*    */   }
/*    */   
/*    */   public synchronized void set(boolean b) {
/* 75 */     this.m_Set = b;
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\SimpleDigitalOut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */