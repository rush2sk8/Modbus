package com.ghgande.j2mod.modbus.procimg;

public abstract interface InputRegister
{
  public abstract int getValue();
  
  public abstract int toUnsignedShort();
  
  public abstract short toShort();
  
  public abstract byte[] toBytes();
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\InputRegister.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */