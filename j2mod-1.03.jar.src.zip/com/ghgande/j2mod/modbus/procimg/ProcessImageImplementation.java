package com.ghgande.j2mod.modbus.procimg;

public abstract interface ProcessImageImplementation
  extends ProcessImage
{
  public static final byte DIG_TRUE = 1;
  public static final byte DIG_FALSE = 0;
  public static final byte DIG_INVALID = -1;
  
  public abstract void setDigitalOut(int paramInt, DigitalOut paramDigitalOut)
    throws IllegalAddressException;
  
  public abstract void addDigitalOut(DigitalOut paramDigitalOut);
  
  public abstract void removeDigitalOut(DigitalOut paramDigitalOut);
  
  public abstract void setDigitalIn(int paramInt, DigitalIn paramDigitalIn)
    throws IllegalAddressException;
  
  public abstract void addDigitalIn(DigitalIn paramDigitalIn);
  
  public abstract void removeDigitalIn(DigitalIn paramDigitalIn);
  
  public abstract void setInputRegister(int paramInt, InputRegister paramInputRegister)
    throws IllegalAddressException;
  
  public abstract void addInputRegister(InputRegister paramInputRegister);
  
  public abstract void removeInputRegister(InputRegister paramInputRegister);
  
  public abstract void setRegister(int paramInt, Register paramRegister)
    throws IllegalAddressException;
  
  public abstract void addRegister(Register paramRegister);
  
  public abstract void removeRegister(Register paramRegister);
  
  public abstract void setFile(int paramInt, File paramFile)
    throws IllegalAddressException;
  
  public abstract void addFile(File paramFile);
  
  public abstract void removeFile(File paramFile);
  
  public abstract void setFIFO(int paramInt, FIFO paramFIFO)
    throws IllegalAddressException;
  
  public abstract void addFIFO(FIFO paramFIFO);
  
  public abstract void removeFIFO(FIFO paramFIFO);
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\ProcessImageImplementation.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */