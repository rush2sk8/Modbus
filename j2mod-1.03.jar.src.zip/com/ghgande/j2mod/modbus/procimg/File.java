/*    */ package com.ghgande.j2mod.modbus.procimg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class File
/*    */ {
/*    */   private int m_File_Number;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private int m_Record_Count;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private Record[] m_Records;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getFileNumber()
/*    */   {
/* 48 */     return this.m_File_Number;
/*    */   }
/*    */   
/*    */   public int getRecordCount() {
/* 52 */     return this.m_Record_Count;
/*    */   }
/*    */   
/*    */   public Record getRecord(int i) {
/* 56 */     if ((i < 0) || (i >= this.m_Record_Count)) {
/* 57 */       throw new IllegalAddressException();
/*    */     }
/* 59 */     return this.m_Records[i];
/*    */   }
/*    */   
/*    */   public File setRecord(int i, Record record) {
/* 63 */     if ((i < 0) || (i >= this.m_Record_Count)) {
/* 64 */       throw new IllegalAddressException();
/*    */     }
/* 66 */     this.m_Records[i] = record;
/*    */     
/* 68 */     return this;
/*    */   }
/*    */   
/*    */   public File(int fileNumber, int records) {
/* 72 */     this.m_File_Number = fileNumber;
/* 73 */     this.m_Record_Count = records;
/* 74 */     this.m_Records = new Record[records];
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\File.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */