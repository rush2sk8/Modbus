/*    */ package com.ghgande.j2mod.modbus.procimg;
/*    */ 
/*    */ import com.ghgande.j2mod.modbus.util.Observable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ObservableDigitalOut
/*    */   extends Observable
/*    */   implements DigitalOut
/*    */ {
/*    */   protected boolean m_Set;
/*    */   
/*    */   public boolean isSet()
/*    */   {
/* 57 */     return this.m_Set;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public void set(boolean b)
/*    */   {
/* 65 */     this.m_Set = b;
/* 66 */     notifyObservers("value");
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\ObservableDigitalOut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */