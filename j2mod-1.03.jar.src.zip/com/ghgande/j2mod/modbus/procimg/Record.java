/*    */ package com.ghgande.j2mod.modbus.procimg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Record
/*    */ {
/*    */   private int m_Record_Number;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private int m_Register_Count;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private Register[] m_Registers;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getRecordNumber()
/*    */   {
/* 48 */     return this.m_Record_Number;
/*    */   }
/*    */   
/*    */   public int getRegisterCount() {
/* 52 */     return this.m_Register_Count;
/*    */   }
/*    */   
/*    */   public Register getRegister(int register) {
/* 56 */     if ((register < 0) || (register >= this.m_Register_Count)) {
/* 57 */       throw new IllegalAddressException();
/*    */     }
/* 59 */     return this.m_Registers[register];
/*    */   }
/*    */   
/*    */   public Record setRegister(int ref, Register register) {
/* 63 */     if ((ref < 0) || (ref >= this.m_Register_Count)) {
/* 64 */       throw new IllegalAddressException();
/*    */     }
/* 66 */     this.m_Registers[ref] = register;
/*    */     
/* 68 */     return this;
/*    */   }
/*    */   
/*    */   public Record(int recordNumber, int registers) {
/* 72 */     this.m_Record_Number = recordNumber;
/* 73 */     this.m_Register_Count = registers;
/* 74 */     this.m_Registers = new Register[registers];
/*    */     
/* 76 */     for (int i = 0; i < this.m_Register_Count; i++) {
/* 77 */       this.m_Registers[i] = new SimpleRegister(0);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\Record.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */