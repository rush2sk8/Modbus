/*    */ package com.ghgande.j2mod.modbus.procimg;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FIFO
/*    */ {
/*    */   private int m_Address;
/*    */   private int m_Register_Count;
/*    */   private Vector<Register> m_Registers;
/*    */   
/*    */   public synchronized int getRegisterCount()
/*    */   {
/* 54 */     return this.m_Register_Count;
/*    */   }
/*    */   
/*    */   public synchronized Register[] getRegisters() {
/* 58 */     Register[] result = new Register[this.m_Register_Count + 1];
/*    */     
/* 60 */     result[0] = new SimpleRegister(this.m_Register_Count);
/* 61 */     for (int i = 0; i < this.m_Register_Count; i++) {
/* 62 */       result[(i + 1)] = ((Register)this.m_Registers.get(i));
/*    */     }
/* 64 */     return result;
/*    */   }
/*    */   
/*    */   public synchronized void pushRegister(Register register) {
/* 68 */     if (this.m_Register_Count == 31) {
/* 69 */       this.m_Registers.remove(0);
/*    */     } else {
/* 71 */       this.m_Register_Count += 1;
/*    */     }
/* 73 */     this.m_Registers.add(new SimpleRegister(register.getValue()));
/*    */   }
/*    */   
/*    */   public synchronized void resetRegisters() {
/* 77 */     this.m_Registers.removeAllElements();
/* 78 */     this.m_Register_Count = 0;
/*    */   }
/*    */   
/*    */   public int getAddress() {
/* 82 */     return this.m_Address;
/*    */   }
/*    */   
/*    */   public FIFO(int address) {
/* 86 */     this.m_Address = address;
/* 87 */     this.m_Register_Count = 0;
/* 88 */     this.m_Registers = new Vector();
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\FIFO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */