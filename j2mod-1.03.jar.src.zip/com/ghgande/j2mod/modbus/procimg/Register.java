package com.ghgande.j2mod.modbus.procimg;

public abstract interface Register
  extends InputRegister
{
  public abstract void setValue(int paramInt);
  
  public abstract void setValue(short paramShort);
  
  public abstract void setValue(byte[] paramArrayOfByte);
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\Register.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */