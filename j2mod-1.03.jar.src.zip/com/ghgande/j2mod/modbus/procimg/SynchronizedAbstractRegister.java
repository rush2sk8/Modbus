/*     */ package com.ghgande.j2mod.modbus.procimg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class SynchronizedAbstractRegister
/*     */   implements Register
/*     */ {
/*  83 */   protected byte[] m_Register = new byte[2];
/*     */   
/*     */   public int getValue() {
/*  86 */     if (this.m_Register == null) {
/*  87 */       throw new IllegalAddressException();
/*     */     }
/*  89 */     return (this.m_Register[0] & 0xFF) << 8 | this.m_Register[1] & 0xFF;
/*     */   }
/*     */   
/*     */   public byte[] toBytes() {
/*  93 */     return this.m_Register;
/*     */   }
/*     */   
/*     */   public final short toShort() {
/*  97 */     if (this.m_Register == null) {
/*  98 */       throw new IllegalAddressException();
/*     */     }
/* 100 */     return (short)(this.m_Register[0] << 8 | this.m_Register[1] & 0xFF);
/*     */   }
/*     */   
/*     */   public final int toUnsignedShort() {
/* 104 */     if (this.m_Register == null) {
/* 105 */       throw new IllegalAddressException();
/*     */     }
/* 107 */     return (this.m_Register[0] & 0xFF) << 8 | this.m_Register[1] & 0xFF;
/*     */   }
/*     */   
/*     */   public final synchronized void setValue(int v) {
/* 111 */     if (this.m_Register == null) {
/* 112 */       throw new IllegalAddressException();
/*     */     }
/* 114 */     this.m_Register[0] = ((byte)(0xFF & v >> 8));
/* 115 */     this.m_Register[1] = ((byte)(0xFF & v));
/*     */   }
/*     */   
/*     */   public final synchronized void setValue(short s) {
/* 119 */     if (this.m_Register == null) {
/* 120 */       throw new IllegalAddressException();
/*     */     }
/* 122 */     this.m_Register[0] = ((byte)(0xFF & s >> 8));
/* 123 */     this.m_Register[1] = ((byte)(0xFF & s));
/*     */   }
/*     */   
/*     */   public final synchronized void setValue(byte[] bytes) {
/* 127 */     if (bytes.length < 2) {
/* 128 */       throw new IllegalArgumentException();
/*     */     }
/* 130 */     if (this.m_Register == null) {
/* 131 */       throw new IllegalAddressException();
/*     */     }
/* 133 */     this.m_Register[0] = bytes[0];
/* 134 */     this.m_Register[1] = bytes[1];
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\SynchronizedAbstractRegister.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */