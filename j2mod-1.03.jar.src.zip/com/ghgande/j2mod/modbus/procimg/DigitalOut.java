package com.ghgande.j2mod.modbus.procimg;

public abstract interface DigitalOut
{
  public abstract boolean isSet();
  
  public abstract void set(boolean paramBoolean);
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\procimg\DigitalOut.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */