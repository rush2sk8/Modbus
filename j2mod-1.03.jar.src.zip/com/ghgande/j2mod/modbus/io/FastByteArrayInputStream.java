/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastByteArrayInputStream
/*     */   extends InputStream
/*     */ {
/*     */   protected int count;
/*     */   protected int pos;
/*     */   protected int mark;
/*     */   protected byte[] buf;
/*     */   
/*     */   public FastByteArrayInputStream(byte[] buffer)
/*     */   {
/* 118 */     this.buf = buffer;
/* 119 */     this.count = buffer.length;
/* 120 */     this.pos = 0;
/* 121 */     this.mark = 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FastByteArrayInputStream(byte[] buffer, int offset, int length)
/*     */   {
/* 137 */     this.buf = buffer;
/* 138 */     this.pos = offset;
/* 139 */     this.count = length;
/*     */   }
/*     */   
/*     */ 
/*     */   public int available()
/*     */   {
/* 145 */     return this.count - this.pos;
/*     */   }
/*     */   
/*     */   public boolean markSupported() {
/* 149 */     return true;
/*     */   }
/*     */   
/*     */   public void mark(int readlimit)
/*     */   {
/* 154 */     this.mark = this.pos;
/*     */   }
/*     */   
/*     */ 
/*     */   public void reset()
/*     */   {
/* 160 */     this.pos = this.mark;
/*     */   }
/*     */   
/*     */   public long skip(long count)
/*     */   {
/* 165 */     int myCount = (int)count;
/* 166 */     if (myCount + this.pos > this.count) {
/* 167 */       myCount = this.count - this.pos;
/*     */     }
/* 169 */     this.pos += myCount;
/* 170 */     return myCount;
/*     */   }
/*     */   
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 176 */     return this.pos < this.count ? this.buf[(this.pos++)] & 0xFF : -1;
/*     */   }
/*     */   
/*     */   public int read(byte[] toBuf) throws IOException
/*     */   {
/* 181 */     return read(toBuf, 0, toBuf.length);
/*     */   }
/*     */   
/*     */   public int read(byte[] toBuf, int offset, int length) throws IOException
/*     */   {
/* 186 */     int avail = this.count - this.pos;
/* 187 */     if (avail <= 0) {
/* 188 */       return -1;
/*     */     }
/* 190 */     if (length > avail) {
/* 191 */       length = avail;
/*     */     }
/* 193 */     for (int i = 0; i < length; i++) {
/* 194 */       toBuf[(offset++)] = this.buf[(this.pos++)];
/*     */     }
/* 196 */     return length;
/*     */   }
/*     */   
/*     */ 
/*     */   public byte[] toByteArray()
/*     */   {
/* 202 */     byte[] toBuf = new byte[this.count];
/* 203 */     System.arraycopy(this.buf, 0, toBuf, 0, this.count);
/*     */     
/*     */ 
/*     */ 
/* 207 */     return toBuf;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBufferBytes()
/*     */   {
/* 216 */     return this.buf;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBufferOffset()
/*     */   {
/* 225 */     return this.pos;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBufferLength()
/*     */   {
/* 234 */     return this.count;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\FastByteArrayInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */