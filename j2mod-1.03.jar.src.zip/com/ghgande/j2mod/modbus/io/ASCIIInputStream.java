/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ASCIIInputStream
/*     */   extends FilterInputStream
/*     */ {
/*     */   public ASCIIInputStream(InputStream in)
/*     */   {
/*  67 */     super(in);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/*  77 */     StringBuffer sbuf = new StringBuffer(2);
/*  78 */     int ch = this.in.read();
/*  79 */     if (ch == -1) {
/*  80 */       return -1;
/*     */     }
/*     */     
/*  83 */     sbuf.append((char)ch);
/*  84 */     if (sbuf.charAt(0) == ':')
/*     */     {
/*  86 */       return 1000;
/*     */     }
/*  88 */     if (sbuf.charAt(0) == '\r') {
/*  89 */       if (this.in.read() == 10)
/*     */       {
/*  91 */         return 2000;
/*     */       }
/*     */       
/*  94 */       throw new IOException("Malformed Stream No Frame Delims");
/*     */     }
/*     */     try
/*     */     {
/*  98 */       sbuf.append((char)this.in.read());
/*     */       
/* 100 */       return Integer.parseInt(sbuf.toString().toLowerCase(), 16);
/*     */     }
/*     */     catch (NumberFormatException ex) {
/* 103 */       if (Modbus.debug) System.out.println(sbuf.toString());
/* 104 */       throw new IOException("Malformed Stream - Wrong Characters");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\ASCIIInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */