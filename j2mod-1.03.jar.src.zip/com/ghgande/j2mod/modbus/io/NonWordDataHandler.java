package com.ghgande.j2mod.modbus.io;

import java.io.DataInput;
import java.io.EOFException;
import java.io.IOException;

public abstract interface NonWordDataHandler
{
  public abstract byte[] getData();
  
  public abstract void readData(DataInput paramDataInput, int paramInt1, int paramInt2)
    throws IOException, EOFException;
  
  public abstract int getWordCount();
  
  public abstract int commitUpdate();
  
  public abstract void prepareData(int paramInt1, int paramInt2);
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\NonWordDataHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */