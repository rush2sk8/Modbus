/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusIOException;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusMessage;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.net.UDPTerminal;
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusUDPTransport
/*     */   implements ModbusTransport
/*     */ {
/*     */   private UDPTerminal m_Terminal;
/*     */   private BytesOutputStream m_ByteOut;
/*     */   private BytesInputStream m_ByteIn;
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */   public boolean getDebug()
/*     */   {
/*  69 */     return "true".equals(System.getProperty("com.ghgande.j2mod.modbus.debug"));
/*     */   }
/*     */   
/*     */   public ModbusTransaction createTransaction() {
/*  73 */     ModbusUDPTransaction trans = new ModbusUDPTransaction();
/*  74 */     trans.setTerminal(this.m_Terminal);
/*     */     
/*  76 */     return trans;
/*     */   }
/*     */   
/*     */   public void writeMessage(ModbusMessage msg) throws ModbusIOException
/*     */   {
/*     */     try {
/*  82 */       synchronized (this.m_ByteOut) {
/*  83 */         this.m_ByteOut.reset();
/*  84 */         msg.writeTo(this.m_ByteOut);
/*  85 */         this.m_Terminal.sendMessage(this.m_ByteOut.getBuffer());
/*     */       }
/*     */     } catch (Exception ex) {
/*  88 */       throw new ModbusIOException("I/O exception - failed to write.");
/*     */     }
/*     */   }
/*     */   
/*     */   public ModbusRequest readRequest() throws ModbusIOException
/*     */   {
/*     */     try {
/*  95 */       ModbusRequest req = null;
/*  96 */       synchronized (this.m_ByteIn) {
/*  97 */         this.m_ByteIn.reset(this.m_Terminal.receiveMessage());
/*  98 */         this.m_ByteIn.skip(7);
/*  99 */         int functionCode = this.m_ByteIn.readUnsignedByte();
/* 100 */         this.m_ByteIn.reset();
/* 101 */         req = ModbusRequest.createModbusRequest(functionCode);
/* 102 */         req.readFrom(this.m_ByteIn);
/*     */       }
/* 104 */       return req;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 131 */       throw new ModbusIOException("I/O exception - failed to read.");
/*     */     }
/*     */   }
/*     */   
/*     */   public ModbusResponse readResponse() throws ModbusIOException
/*     */   {
/*     */     try
/*     */     {
/* 139 */       ModbusResponse res = null;
/* 140 */       synchronized (this.m_ByteIn) {
/* 141 */         this.m_ByteIn.reset(this.m_Terminal.receiveMessage());
/* 142 */         this.m_ByteIn.skip(7);
/* 143 */         int functionCode = this.m_ByteIn.readUnsignedByte();
/* 144 */         this.m_ByteIn.reset();
/* 145 */         res = ModbusResponse.createModbusResponse(functionCode);
/* 146 */         res.readFrom(this.m_ByteIn);
/*     */       }
/* 148 */       return res;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (InterruptedIOException ioex)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */       throw new ModbusIOException("Socket timed out.");
/*     */     } catch (Exception ex) {
/* 172 */       ex.printStackTrace();
/* 173 */       throw new ModbusIOException("I/O exception - failed to read.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusUDPTransport(UDPTerminal terminal)
/*     */   {
/* 185 */     this.m_Terminal = terminal;
/* 186 */     this.m_ByteOut = new BytesOutputStream(256);
/* 187 */     this.m_ByteIn = new BytesInputStream(256);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\ModbusUDPTransport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */