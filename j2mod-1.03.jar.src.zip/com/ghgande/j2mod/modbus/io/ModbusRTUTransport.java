/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusIOException;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusMessage;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.util.ModbusUtil;
/*     */ import gnu.io.CommPort;
/*     */ import gnu.io.UnsupportedCommOperationException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusRTUTransport
/*     */   extends ModbusSerialTransport
/*     */ {
/*     */   private InputStream m_InputStream;
/*     */   private OutputStream m_OutputStream;
/*     */   private byte[] m_InBuffer;
/*     */   private BytesInputStream m_ByteIn;
/*     */   private BytesOutputStream m_ByteInOut;
/*     */   private BytesOutputStream m_ByteOut;
/*  66 */   private byte[] lastRequest = null;
/*  67 */   private boolean osIsKnown = false;
/*  68 */   private boolean osIsWindows = false;
/*     */   
/*     */   public ModbusTransaction createTransaction() {
/*  71 */     ModbusSerialTransaction transaction = new ModbusSerialTransaction();
/*  72 */     transaction.setTransport(this);
/*     */     
/*  74 */     return transaction;
/*     */   }
/*     */   
/*     */   public void writeMessage(ModbusMessage msg) throws ModbusIOException
/*     */   {
/*     */     try {
/*  80 */       synchronized (this.m_ByteOut)
/*     */       {
/*     */ 
/*  83 */         clearInput();
/*     */         
/*  85 */         this.m_ByteOut.reset();
/*  86 */         msg.setHeadless();
/*  87 */         msg.writeTo(this.m_ByteOut);
/*  88 */         int len = this.m_ByteOut.size();
/*  89 */         int[] crc = ModbusUtil.calculateCRC(this.m_ByteOut.getBuffer(), 0, 
/*  90 */           len);
/*  91 */         this.m_ByteOut.writeByte(crc[0]);
/*  92 */         this.m_ByteOut.writeByte(crc[1]);
/*     */         
/*  94 */         len = this.m_ByteOut.size();
/*  95 */         byte[] buf = this.m_ByteOut.getBuffer();
/*  96 */         this.m_OutputStream.write(buf, 0, len);
/*  97 */         this.m_OutputStream.flush();
/*  98 */         if (Modbus.debug)
/*     */         {
/* 100 */           System.err.println("Sent: " + ModbusUtil.toHex(buf, 0, len));
/*     */         }
/*     */         
/* 103 */         if (this.m_Echo) {
/* 104 */           readEcho(len);
/*     */         }
/* 106 */         this.lastRequest = new byte[len];
/* 107 */         System.arraycopy(buf, 0, this.lastRequest, 0, len);
/*     */       }
/*     */     }
/*     */     catch (Exception ex) {
/* 111 */       throw new ModbusIOException("I/O failed to write");
/*     */     }
/*     */   }
/*     */   
/*     */   public ModbusRequest readRequest()
/*     */     throws ModbusIOException
/*     */   {
/* 118 */     throw new RuntimeException("Operation not supported.");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void clearInput()
/*     */     throws IOException
/*     */   {
/* 127 */     if (this.m_InputStream.available() > 0) {
/* 128 */       int len = this.m_InputStream.available();
/* 129 */       byte[] buf = new byte[len];
/* 130 */       this.m_InputStream.read(buf, 0, len);
/* 131 */       if (Modbus.debug) {
/* 132 */         System.err.println("Clear input: " + 
/* 133 */           ModbusUtil.toHex(buf, 0, len));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public ModbusResponse readResponse() throws ModbusIOException {
/* 139 */     boolean done = false;
/* 140 */     ModbusResponse response = null;
/* 141 */     int dlength = 0;
/*     */     
/*     */     try
/*     */     {
/*     */       do
/*     */       {
/* 147 */         synchronized (this.m_ByteIn) {
/* 148 */           int uid = this.m_InputStream.read();
/* 149 */           if (uid != -1) {
/* 150 */             int fc = this.m_InputStream.read();
/* 151 */             this.m_ByteInOut.reset();
/* 152 */             this.m_ByteInOut.writeByte(uid);
/* 153 */             this.m_ByteInOut.writeByte(fc);
/*     */             
/*     */ 
/* 156 */             response = ModbusResponse.createModbusResponse(fc);
/* 157 */             response.setHeadless();
/*     */             
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 168 */             getResponse(fc, this.m_ByteInOut);
/* 169 */             dlength = this.m_ByteInOut.size() - 2;
/* 170 */             if (Modbus.debug) {
/* 171 */               System.err.println("Response: " + 
/* 172 */                 ModbusUtil.toHex(this.m_ByteInOut.getBuffer(), 
/* 173 */                 0, dlength + 2));
/*     */             }
/* 175 */             this.m_ByteIn.reset(this.m_InBuffer, dlength);
/*     */             
/*     */ 
/* 178 */             int[] crc = ModbusUtil.calculateCRC(this.m_InBuffer, 0, 
/* 179 */               dlength);
/* 180 */             if ((ModbusUtil.unsignedByteToInt(this.m_InBuffer[dlength]) != crc[0]) && 
/* 181 */               (
/* 182 */               ModbusUtil.unsignedByteToInt(this.m_InBuffer[(dlength + 1)]) != crc[1])) {
/* 183 */               if (Modbus.debug)
/* 184 */                 System.err.println("CRC should be " + crc[0] + 
/* 185 */                   ", " + crc[1]);
/* 186 */               throw new IOException(
/* 187 */                 "CRC Error in received frame: " + 
/* 188 */                 dlength + 
/* 189 */                 " bytes: " + 
/* 190 */                 ModbusUtil.toHex(
/* 191 */                 this.m_ByteIn.getBuffer(), 0, 
/* 192 */                 dlength));
/*     */             }
/*     */           } else {
/* 195 */             throw new IOException("Error reading response");
/*     */           }
/*     */           
/*     */ 
/* 199 */           this.m_ByteIn.reset(this.m_InBuffer, dlength);
/* 200 */           if (response != null) {
/* 201 */             response.readFrom(this.m_ByteIn);
/*     */           }
/* 203 */           done = true;
/*     */         }
/* 205 */       } while (!done);
/* 206 */       return response;
/*     */     } catch (Exception ex) {
/* 208 */       if (Modbus.debug) {
/* 209 */         System.err.println("Last request: " + 
/* 210 */           ModbusUtil.toHex(this.lastRequest));
/* 211 */         System.err.println(ex.getMessage());
/*     */       }
/* 213 */       throw new ModbusIOException("I/O exception - failed to read");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prepareStreams(InputStream in, OutputStream out)
/*     */     throws IOException
/*     */   {
/* 230 */     this.m_InputStream = in;
/* 231 */     this.m_OutputStream = out;
/*     */     
/* 233 */     this.m_ByteOut = new BytesOutputStream(256);
/* 234 */     this.m_InBuffer = new byte['Ā'];
/* 235 */     this.m_ByteIn = new BytesInputStream(this.m_InBuffer);
/* 236 */     this.m_ByteInOut = new BytesOutputStream(this.m_InBuffer);
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 240 */     this.m_InputStream.close();
/* 241 */     this.m_OutputStream.close();
/*     */   }
/*     */   
/*     */   private void getResponse(int function, BytesOutputStream out) throws IOException
/*     */   {
/* 246 */     int byteCount = -1;
/* 247 */     int readCount = 0;
/* 248 */     byte[] inpBuf = new byte['Ā'];
/*     */     
/* 250 */     int tmOut = this.m_CommPort.getReceiveTimeout();
/* 251 */     long timedOut = System.currentTimeMillis() + tmOut;
/* 252 */     if (tmOut == 0) {
/*     */       try {
/* 254 */         this.m_CommPort.enableReceiveTimeout(250);
/* 255 */         timedOut += 250L;
/*     */       }
/*     */       catch (UnsupportedCommOperationException localUnsupportedCommOperationException) {}
/*     */     }
/*     */     
/*     */ 
/* 261 */     if (!this.osIsKnown) {
/* 262 */       String osName = System.getProperty("os.name");
/* 263 */       if (osName.toLowerCase().startsWith("win")) {
/* 264 */         this.osIsWindows = true;
/*     */       }
/* 266 */       this.osIsKnown = true;
/*     */     }
/*     */     try
/*     */     {
/* 270 */       if ((function & 0x80) == 0) {
/* 271 */         switch (function)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */         case 1: 
/*     */         case 2: 
/*     */         case 3: 
/*     */         case 4: 
/*     */         case 12: 
/*     */         case 17: 
/*     */         case 20: 
/*     */         case 21: 
/*     */         case 23: 
/* 285 */           byteCount = this.m_InputStream.read();
/* 286 */           out.write(byteCount);
/*     */           
/* 288 */           int remaining = byteCount + 2;
/* 289 */           int read = 0;
/* 290 */           int loopCount = 0;
/*     */           
/* 292 */           while ((remaining > 0) && (loopCount++ < 5)) {
/* 293 */             if (!this.osIsWindows) {
/* 294 */               setReceiveThreshold(remaining);
/*     */             } else {
/* 296 */               setReceiveThreshold(remaining > 16 ? 16 : remaining);
/*     */             }
/* 298 */             readCount = this.m_InputStream.read(inpBuf, 0, remaining);
/* 299 */             if (readCount > 0) {
/* 300 */               out.write(inpBuf, 0, readCount);
/* 301 */               read += readCount;
/* 302 */               remaining -= readCount;
/* 303 */               loopCount = 0;
/*     */             }
/* 305 */             if ((readCount == 0) && 
/* 306 */               (System.currentTimeMillis() > timedOut)) {
/*     */               break;
/*     */             }
/* 309 */             if (remaining > 0)
/* 310 */               Thread.yield();
/*     */           }
/* 312 */           if ((Modbus.debug) && (remaining > 0)) {
/* 313 */             System.err.println("Error: looking for " + (
/* 314 */               byteCount + 2) + " bytes, received " + read);
/*     */           }
/* 316 */           this.m_CommPort.disableReceiveThreshold();
/* 317 */           break;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */         case 5: 
/*     */         case 6: 
/*     */         case 8: 
/*     */         case 11: 
/*     */         case 15: 
/*     */         case 16: 
/* 328 */           setReceiveThreshold(6);
/* 329 */           readCount = this.m_InputStream.read(inpBuf, 0, 6);
/* 330 */           out.write(inpBuf, 0, readCount);
/* 331 */           this.m_CommPort.disableReceiveThreshold();
/* 332 */           break;
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */         case 7: 
/* 338 */           setReceiveThreshold(3);
/* 339 */           readCount = this.m_InputStream.read(inpBuf, 0, 3);
/* 340 */           out.write(inpBuf, 0, readCount);
/* 341 */           this.m_CommPort.disableReceiveThreshold();
/* 342 */           break;
/*     */         
/*     */         case 22: 
/* 345 */           setReceiveThreshold(8);
/* 346 */           readCount = this.m_InputStream.read(inpBuf, 0, 8);
/* 347 */           out.write(inpBuf, 0, readCount);
/* 348 */           this.m_CommPort.disableReceiveThreshold();
/* 349 */           break;
/*     */         
/*     */ 
/*     */         case 24: 
/* 353 */           int b1 = (byte)(this.m_InputStream.read() & 0xFF);
/* 354 */           out.write(b1);
/* 355 */           int b2 = (byte)(this.m_InputStream.read() & 0xFF);
/* 356 */           out.write(b2);
/*     */           
/* 358 */           byteCount = ModbusUtil.makeWord(b1, b2);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/* 363 */           setReceiveThreshold(byteCount + 2);
/* 364 */           readCount = this.m_InputStream.read(inpBuf, 0, byteCount + 2);
/* 365 */           out.write(inpBuf, 0, readCount);
/* 366 */           this.m_CommPort.disableReceiveThreshold();
/* 367 */           break;
/*     */         
/*     */         case 43: 
/* 370 */           int sc = this.m_InputStream.read();
/* 371 */           if (sc != 14) {
/* 372 */             throw new IOException("Invalid subfunction code");
/*     */           }
/* 374 */           out.write(sc);
/*     */           
/* 376 */           setReceiveThreshold(5);
/*     */           
/*     */ 
/* 379 */           int cnt = this.m_InputStream.read(inpBuf, 0, 5);
/* 380 */           out.write(inpBuf, 0, cnt);
/* 381 */           int id = inpBuf[0];
/* 382 */           int fieldCount = inpBuf[4];
/* 383 */           for (int i = 0; i < fieldCount; i++) {
/* 384 */             setReceiveThreshold(1);
/* 385 */             id = this.m_InputStream.read();
/* 386 */             out.write(id);
/* 387 */             int len = this.m_InputStream.read();
/* 388 */             out.write(len);
/* 389 */             setReceiveThreshold(len);
/* 390 */             len = this.m_InputStream.read(inpBuf, 0, len);
/* 391 */             out.write(inpBuf, 0, len);
/*     */           }
/* 393 */           if (fieldCount == 0) {
/* 394 */             setReceiveThreshold(1);
/* 395 */             int err = this.m_InputStream.read();
/* 396 */             out.write(err);
/*     */           }
/*     */           
/* 399 */           setReceiveThreshold(2);
/* 400 */           readCount = this.m_InputStream.read(inpBuf, 0, 2);
/* 401 */           out.write(inpBuf, 0, 2);
/* 402 */           this.m_CommPort.disableReceiveThreshold();
/* 403 */           this.m_CommPort.disableReceiveTimeout();
/*     */         }
/*     */         
/*     */       } else {
/* 407 */         setReceiveThreshold(3);
/* 408 */         readCount = this.m_InputStream.read(inpBuf, 0, 3);
/* 409 */         out.write(inpBuf, 0, 3);
/* 410 */         this.m_CommPort.disableReceiveThreshold();
/*     */       }
/*     */     }
/*     */     catch (IOException e) {
/* 414 */       this.m_CommPort.disableReceiveThreshold();
/* 415 */       throw new IOException("getResponse serial port exception");
/*     */     }
/* 417 */     if (tmOut == 0) {
/* 418 */       this.m_CommPort.disableReceiveTimeout();
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\ModbusRTUTransport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */