/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusException;
/*     */ import com.ghgande.j2mod.modbus.ModbusIOException;
/*     */ import com.ghgande.j2mod.modbus.ModbusSlaveException;
/*     */ import com.ghgande.j2mod.modbus.msg.ExceptionResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.net.SerialConnection;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusSerialTransaction
/*     */   implements ModbusTransaction
/*     */ {
/*  57 */   private static int c_TransactionID = 0;
/*     */   
/*     */   private ModbusTransport m_IO;
/*     */   
/*     */   private ModbusRequest m_Request;
/*     */   
/*     */   private ModbusResponse m_Response;
/*     */   
/*  65 */   private boolean m_ValidityCheck = true;
/*  66 */   private int m_Retries = 3;
/*  67 */   private int m_TransDelayMS = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private SerialConnection m_SerialCon;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusSerialTransaction() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusSerialTransaction(ModbusRequest request)
/*     */   {
/*  85 */     setRequest(request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusSerialTransaction(SerialConnection con)
/*     */   {
/*  96 */     setSerialConnection(con);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSerialConnection(SerialConnection con)
/*     */   {
/* 106 */     this.m_SerialCon = con;
/* 107 */     this.m_IO = this.m_SerialCon.getModbusTransport();
/*     */   }
/*     */   
/*     */   public void setTransport(ModbusSerialTransport transport) {
/* 111 */     this.m_IO = transport;
/*     */   }
/*     */   
/*     */   public int getTransactionID() {
/* 115 */     return c_TransactionID;
/*     */   }
/*     */   
/*     */   public void setRequest(ModbusRequest req)
/*     */   {
/* 120 */     this.m_Request = req;
/*     */   }
/*     */   
/*     */   public ModbusRequest getRequest()
/*     */   {
/* 125 */     return this.m_Request;
/*     */   }
/*     */   
/*     */   public ModbusResponse getResponse() {
/* 129 */     return this.m_Response;
/*     */   }
/*     */   
/*     */   public void setCheckingValidity(boolean b) {
/* 133 */     this.m_ValidityCheck = b;
/*     */   }
/*     */   
/*     */   public boolean isCheckingValidity() {
/* 137 */     return this.m_ValidityCheck;
/*     */   }
/*     */   
/*     */   public int getRetries() {
/* 141 */     return this.m_Retries;
/*     */   }
/*     */   
/*     */   public void setRetries(int num) {
/* 145 */     this.m_Retries = num;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTransDelayMS()
/*     */   {
/* 153 */     return this.m_TransDelayMS;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTransDelayMS(int newTransDelayMS)
/*     */   {
/* 161 */     this.m_TransDelayMS = newTransDelayMS;
/*     */   }
/*     */   
/*     */ 
/*     */   public void execute()
/*     */     throws ModbusIOException, ModbusSlaveException, ModbusException
/*     */   {
/* 168 */     assertExecutable();
/*     */     
/*     */ 
/*     */ 
/* 172 */     synchronized (this.m_IO) {
/* 173 */       int tries = 0;
/* 174 */       boolean finished = false;
/*     */       do {
/*     */         try {
/* 177 */           if (this.m_TransDelayMS > 0) {
/*     */             try {
/* 179 */               Thread.sleep(this.m_TransDelayMS);
/*     */             } catch (InterruptedException ex) {
/* 181 */               if (Modbus.debug) {
/* 182 */                 System.err.println("InterruptedException: " + 
/* 183 */                   ex.getMessage());
/*     */               }
/*     */             }
/*     */           }
/* 187 */           this.m_IO.writeMessage(this.m_Request);
/*     */           
/* 189 */           this.m_Response = this.m_IO.readResponse();
/* 190 */           finished = true;
/*     */         } catch (ModbusIOException e) {
/* 192 */           tries++; if (tries >= this.m_Retries) {
/* 193 */             throw e;
/*     */           }
/* 195 */           if (Modbus.debug)
/* 196 */             System.err.println("Execute try " + tries + " error: " + 
/* 197 */               e.getMessage());
/*     */         }
/* 199 */       } while (!finished);
/*     */     }
/*     */     
/*     */ 
/* 203 */     if ((this.m_Response instanceof ExceptionResponse)) {
/* 204 */       throw new ModbusSlaveException(
/* 205 */         ((ExceptionResponse)this.m_Response).getExceptionCode());
/*     */     }
/*     */     
/*     */ 
/* 209 */     if (isCheckingValidity()) {
/* 210 */       checkValidity();
/*     */     }
/*     */     
/* 213 */     toggleTransactionID();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void assertExecutable()
/*     */     throws ModbusException
/*     */   {
/* 224 */     if ((this.m_Request == null) || 
/* 225 */       (this.m_IO == null)) {
/* 226 */       throw new ModbusException(
/* 227 */         "Assertion failed, transaction not executable");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkValidity()
/*     */     throws ModbusException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void toggleTransactionID()
/*     */   {
/* 251 */     if (isCheckingValidity()) {
/* 252 */       if (c_TransactionID == 65534) {
/* 253 */         c_TransactionID = 0;
/*     */       } else {
/* 255 */         c_TransactionID += 1;
/*     */       }
/*     */     }
/* 258 */     this.m_Request.setTransactionID(getTransactionID());
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\ModbusSerialTransaction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */