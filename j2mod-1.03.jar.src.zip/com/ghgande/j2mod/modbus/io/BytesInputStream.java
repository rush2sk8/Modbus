/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BytesInputStream
/*     */   extends FastByteArrayInputStream
/*     */   implements DataInput
/*     */ {
/*     */   DataInputStream m_Din;
/*     */   
/*     */   public BytesInputStream(int size)
/*     */   {
/*  60 */     super(new byte[size]);
/*  61 */     this.m_Din = new DataInputStream(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BytesInputStream(byte[] data)
/*     */   {
/*  71 */     super(data);
/*  72 */     this.m_Din = new DataInputStream(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset(byte[] data)
/*     */   {
/*  83 */     this.pos = 0;
/*  84 */     this.mark = 0;
/*  85 */     this.buf = data;
/*  86 */     this.count = data.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset(byte[] data, int length)
/*     */   {
/*  97 */     this.pos = 0;
/*  98 */     this.mark = 0;
/*  99 */     this.count = length;
/* 100 */     this.buf = data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void reset(int length)
/*     */   {
/* 112 */     this.pos = 0;
/* 113 */     this.count = length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int skip(int n)
/*     */   {
/* 124 */     mark(this.pos);
/* 125 */     this.pos += n;
/* 126 */     return n;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBuffer()
/*     */   {
/* 135 */     return this.buf;
/*     */   }
/*     */   
/*     */   public int getBufferLength() {
/* 139 */     return this.buf.length;
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b) throws IOException
/*     */   {
/* 144 */     this.m_Din.readFully(b);
/*     */   }
/*     */   
/*     */   public void readFully(byte[] b, int off, int len) throws IOException
/*     */   {
/* 149 */     this.m_Din.readFully(b, off, len);
/*     */   }
/*     */   
/*     */   public int skipBytes(int n) throws IOException
/*     */   {
/* 154 */     return this.m_Din.skipBytes(n);
/*     */   }
/*     */   
/*     */   public boolean readBoolean() throws IOException
/*     */   {
/* 159 */     return this.m_Din.readBoolean();
/*     */   }
/*     */   
/*     */   public byte readByte() throws IOException
/*     */   {
/* 164 */     return this.m_Din.readByte();
/*     */   }
/*     */   
/*     */   public int readUnsignedByte() throws IOException
/*     */   {
/* 169 */     return this.m_Din.readUnsignedByte();
/*     */   }
/*     */   
/*     */   public short readShort() throws IOException
/*     */   {
/* 174 */     return this.m_Din.readShort();
/*     */   }
/*     */   
/*     */   public int readUnsignedShort() throws IOException
/*     */   {
/* 179 */     return this.m_Din.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public char readChar() throws IOException
/*     */   {
/* 184 */     return this.m_Din.readChar();
/*     */   }
/*     */   
/*     */   public int readInt() throws IOException
/*     */   {
/* 189 */     return this.m_Din.readInt();
/*     */   }
/*     */   
/*     */   public long readLong() throws IOException
/*     */   {
/* 194 */     return this.m_Din.readLong();
/*     */   }
/*     */   
/*     */ 
/*     */   public float readFloat()
/*     */     throws IOException
/*     */   {
/* 201 */     return this.m_Din.readFloat();
/*     */   }
/*     */   
/*     */   public double readDouble() throws IOException
/*     */   {
/* 206 */     return this.m_Din.readDouble();
/*     */   }
/*     */   
/*     */   public String readLine()
/*     */     throws IOException
/*     */   {
/* 212 */     throw new IOException("Not supported.");
/*     */   }
/*     */   
/*     */   public String readUTF() throws IOException
/*     */   {
/* 217 */     return this.m_Din.readUTF();
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\BytesInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */