/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusIOException;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusMessage;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.util.ModbusUtil;
/*     */ import gnu.io.CommPort;
/*     */ import gnu.io.SerialPort;
/*     */ import gnu.io.UnsupportedCommOperationException;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ModbusSerialTransport
/*     */   implements ModbusTransport
/*     */ {
/*     */   protected CommPort m_CommPort;
/*  62 */   protected boolean m_Echo = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void prepareStreams(InputStream paramInputStream, OutputStream paramOutputStream)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ModbusResponse readResponse()
/*     */     throws ModbusIOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ModbusRequest readRequest()
/*     */     throws ModbusIOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeMessage(ModbusMessage paramModbusMessage)
/*     */     throws ModbusIOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void close()
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCommPort(CommPort cp)
/*     */     throws IOException
/*     */   {
/* 122 */     this.m_CommPort = cp;
/* 123 */     if (cp != null) {
/* 124 */       prepareStreams(cp.getInputStream(), cp.getOutputStream());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEcho()
/*     */   {
/* 134 */     return this.m_Echo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEcho(boolean b)
/*     */   {
/* 143 */     this.m_Echo = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReceiveThreshold(int th)
/*     */   {
/*     */     try
/*     */     {
/* 154 */       this.m_CommPort.enableReceiveThreshold(th);
/*     */     } catch (UnsupportedCommOperationException e) {
/* 156 */       System.out.println(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReceiveTimeout(int ms)
/*     */   {
/*     */     try
/*     */     {
/* 167 */       this.m_CommPort.enableReceiveTimeout(ms);
/*     */       
/* 169 */       int thresh = this.m_CommPort.getReceiveThreshold();
/* 170 */       if (thresh <= 0)
/* 171 */         this.m_CommPort.enableReceiveThreshold(2);
/*     */     } catch (UnsupportedCommOperationException e) {
/* 173 */       System.out.println(e.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBaudRate(int baud)
/*     */   {
/*     */     try
/*     */     {
/* 184 */       SerialPort physicalPort = null;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 189 */       if (!(this.m_CommPort instanceof SerialPort)) {
/* 190 */         throw new UnsupportedCommOperationException(
/* 191 */           "Cannot change baud rate on non-serial device.");
/*     */       }
/* 193 */       physicalPort = (SerialPort)this.m_CommPort;
/* 194 */       int stop = physicalPort.getStopBits();
/* 195 */       int data = physicalPort.getDataBits();
/* 196 */       int parity = physicalPort.getParity();
/*     */       
/* 198 */       physicalPort.setSerialPortParams(baud, data, stop, parity);
/*     */       
/* 200 */       if (Modbus.debug)
/* 201 */         System.err.println("baud rate is now " + physicalPort.getBaudRate());
/*     */     } catch (UnsupportedCommOperationException x) {
/* 203 */       System.out.println(x.getMessage());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readEcho(int len)
/*     */     throws IOException
/*     */   {
/* 218 */     byte[] echoBuf = new byte[len];
/* 219 */     setReceiveThreshold(len);
/* 220 */     int echoLen = this.m_CommPort.getInputStream().read(echoBuf, 0, len);
/* 221 */     if (Modbus.debug)
/* 222 */       System.out.println("Echo: " + 
/* 223 */         ModbusUtil.toHex(echoBuf, 0, echoLen));
/* 224 */     this.m_CommPort.disableReceiveThreshold();
/* 225 */     if (echoLen != len) {
/* 226 */       if (Modbus.debug)
/* 227 */         System.err.println("Error: Transmit echo not received.");
/* 228 */       throw new IOException("Echo not received.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\ModbusSerialTransport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */