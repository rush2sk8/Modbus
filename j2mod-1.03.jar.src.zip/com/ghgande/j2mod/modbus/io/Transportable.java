package com.ghgande.j2mod.modbus.io;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public abstract interface Transportable
{
  public abstract int getOutputLength();
  
  public abstract void writeTo(DataOutput paramDataOutput)
    throws IOException;
  
  public abstract void readFrom(DataInput paramDataInput)
    throws IOException;
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\Transportable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */