/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusException;
/*     */ import com.ghgande.j2mod.modbus.ModbusIOException;
/*     */ import com.ghgande.j2mod.modbus.ModbusSlaveException;
/*     */ import com.ghgande.j2mod.modbus.msg.ExceptionResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.net.TCPMasterConnection;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusTCPTransaction
/*     */   implements ModbusTransaction
/*     */ {
/*  57 */   private static int c_TransactionID = 0;
/*     */   
/*     */   private TCPMasterConnection m_Connection;
/*     */   
/*     */   private ModbusTransport m_IO;
/*     */   private ModbusRequest m_Request;
/*     */   private ModbusResponse m_Response;
/*  64 */   private boolean m_ValidityCheck = true;
/*  65 */   private boolean m_Reconnecting = false;
/*  66 */   private int m_Retries = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusTCPTransaction() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusTCPTransaction(ModbusRequest request)
/*     */   {
/*  83 */     setRequest(request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusTCPTransaction(TCPMasterConnection con)
/*     */   {
/*  95 */     setConnection(con);
/*  96 */     this.m_IO = con.getModbusTransport();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setConnection(TCPMasterConnection con)
/*     */   {
/* 111 */     this.m_Connection = con;
/* 112 */     this.m_IO = con.getModbusTransport();
/*     */   }
/*     */   
/*     */   public void setRequest(ModbusRequest req) {
/* 116 */     this.m_Request = req;
/*     */   }
/*     */   
/*     */   public ModbusRequest getRequest() {
/* 120 */     return this.m_Request;
/*     */   }
/*     */   
/*     */   public ModbusResponse getResponse() {
/* 124 */     return this.m_Response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getTransactionID()
/*     */   {
/* 135 */     if ((c_TransactionID == 0) && (isCheckingValidity())) {
/* 136 */       c_TransactionID += 1;
/*     */     }
/* 138 */     return c_TransactionID;
/*     */   }
/*     */   
/*     */   public void setCheckingValidity(boolean b) {
/* 142 */     this.m_ValidityCheck = b;
/*     */   }
/*     */   
/*     */   public boolean isCheckingValidity() {
/* 146 */     return this.m_ValidityCheck;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReconnecting(boolean b)
/*     */   {
/* 158 */     this.m_Reconnecting = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isReconnecting()
/*     */   {
/* 169 */     return this.m_Reconnecting;
/*     */   }
/*     */   
/*     */   public int getRetries() {
/* 173 */     return this.m_Retries;
/*     */   }
/*     */   
/*     */   public void setRetries(int num) {
/* 177 */     this.m_Retries = num;
/*     */   }
/*     */   
/*     */   public void execute()
/*     */     throws ModbusIOException, ModbusSlaveException, ModbusException
/*     */   {
/* 183 */     if ((this.m_Request == null) || (this.m_Connection == null)) {
/* 184 */       throw new ModbusException("Invalid request or connection");
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 189 */     if (!this.m_Connection.isConnected()) {
/*     */       try {
/* 191 */         this.m_Connection.connect();
/*     */       } catch (Exception ex) {
/* 193 */         throw new ModbusIOException("Connection failed.");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 201 */     int retryCounter = 0;
/* 202 */     int retryLimit = this.m_Retries > 0 ? this.m_Retries : 1;
/*     */     break label409;
/*     */     try {
/*     */       do {
/* 206 */         synchronized (this.m_IO) {
/* 207 */           if (Modbus.debug) {
/* 208 */             System.err.println("request transaction ID = " + this.m_Request.getTransactionID());
/*     */           }
/* 210 */           this.m_IO.writeMessage(this.m_Request);
/* 211 */           this.m_Response = null;
/*     */           do {
/* 213 */             this.m_Response = this.m_IO.readResponse();
/* 214 */             if (Modbus.debug) {
/* 215 */               System.err.println("response transaction ID = " + this.m_Response.getTransactionID());
/*     */               
/* 217 */               if (this.m_Response.getTransactionID() != this.m_Request.getTransactionID()) {
/* 218 */                 System.err.println("expected " + this.m_Request.getTransactionID() + 
/* 219 */                   ", got " + this.m_Response.getTransactionID());
/*     */               }
/*     */             }
/* 222 */             if ((this.m_Response == null) || (
/* 223 */               (isCheckingValidity()) && (
/* 224 */               (this.m_Request.getTransactionID() == 0) || 
/* 225 */               (this.m_Request.getTransactionID() == 
/* 226 */               this.m_Response.getTransactionID())))) break;
/* 227 */             retryCounter++;
/* 212 */           } while (
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 227 */             retryCounter < retryLimit);
/*     */           
/* 229 */           if (retryCounter >= retryLimit) {
/* 230 */             throw new ModbusIOException(
/* 231 */               "Executing transaction failed (tried " + 
/* 232 */               this.m_Retries + " times)");
/*     */           }
/*     */         }
/* 204 */       } while (retryCounter < retryLimit);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (ModbusIOException ex)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 242 */       if (!this.m_Connection.isConnected()) {
/*     */         try {
/* 244 */           this.m_Connection.connect();
/*     */ 
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 249 */           throw new ModbusIOException("Connection lost.");
/*     */         }
/*     */       }
/* 252 */       if (retryCounter >= retryLimit) {
/* 253 */         throw new ModbusIOException(
/* 254 */           "Executing transaction failed (tried " + this.m_Retries + 
/* 255 */           " times)");
/*     */       }
/* 257 */       retryCounter++;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     label409:
/*     */     
/*     */ 
/*     */ 
/* 266 */     if ((this.m_Response instanceof ExceptionResponse)) {
/* 267 */       throw new ModbusSlaveException(
/* 268 */         ((ExceptionResponse)this.m_Response).getExceptionCode());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 273 */     if (isReconnecting()) {
/* 274 */       this.m_Connection.close();
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 279 */     if ((isCheckingValidity()) && (this.m_Request != null) && (this.m_Response != null)) {
/* 280 */       checkValidity();
/*     */     }
/* 282 */     incrementTransactionID();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkValidity()
/*     */     throws ModbusException
/*     */   {
/* 292 */     if ((this.m_Request.getTransactionID() == 0) || 
/* 293 */       (this.m_Response.getTransactionID() == 0)) {
/* 294 */       return;
/*     */     }
/* 296 */     if (this.m_Request.getTransactionID() != this.m_Response.getTransactionID()) {
/* 297 */       throw new ModbusException("Transaction ID mismatch");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void incrementTransactionID()
/*     */   {
/* 309 */     if (isCheckingValidity()) {
/* 310 */       if (c_TransactionID == 65534) {
/* 311 */         c_TransactionID = 1;
/*     */       } else {
/* 313 */         c_TransactionID += 1;
/*     */       }
/*     */     }
/* 316 */     this.m_Request.setTransactionID(getTransactionID());
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\ModbusTCPTransaction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */