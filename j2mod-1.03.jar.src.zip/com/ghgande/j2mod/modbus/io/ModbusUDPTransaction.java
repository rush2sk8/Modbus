/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusException;
/*     */ import com.ghgande.j2mod.modbus.ModbusIOException;
/*     */ import com.ghgande.j2mod.modbus.ModbusSlaveException;
/*     */ import com.ghgande.j2mod.modbus.msg.ExceptionResponse;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.net.UDPMasterConnection;
/*     */ import com.ghgande.j2mod.modbus.net.UDPTerminal;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusUDPTransaction
/*     */   implements ModbusTransaction
/*     */ {
/*  58 */   private static int c_TransactionID = 0;
/*     */   
/*     */   private UDPTerminal m_Terminal;
/*     */   
/*     */   private ModbusTransport m_IO;
/*     */   
/*     */   private ModbusRequest m_Request;
/*     */   private ModbusResponse m_Response;
/*  66 */   private boolean m_ValidityCheck = true;
/*  67 */   private int m_Retries = 3;
/*  68 */   private int m_RetryCounter = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusUDPTransaction() {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusUDPTransaction(ModbusRequest request)
/*     */   {
/*  85 */     setRequest(request);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusUDPTransaction(UDPTerminal terminal)
/*     */   {
/*  96 */     setTerminal(terminal);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusUDPTransaction(UDPMasterConnection con)
/*     */   {
/* 107 */     setTerminal(con.getTerminal());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTerminal(UDPTerminal terminal)
/*     */   {
/* 117 */     this.m_Terminal = terminal;
/* 118 */     if (terminal.isActive()) {
/* 119 */       this.m_IO = terminal.getModbusTransport();
/*     */     }
/*     */   }
/*     */   
/*     */   public void setRequest(ModbusRequest req) {
/* 124 */     this.m_Request = req;
/*     */   }
/*     */   
/*     */   public ModbusRequest getRequest()
/*     */   {
/* 129 */     return this.m_Request;
/*     */   }
/*     */   
/*     */   public ModbusResponse getResponse() {
/* 133 */     return this.m_Response;
/*     */   }
/*     */   
/*     */   public int getTransactionID() {
/* 137 */     return c_TransactionID;
/*     */   }
/*     */   
/*     */   public void setCheckingValidity(boolean b) {
/* 141 */     this.m_ValidityCheck = b;
/*     */   }
/*     */   
/*     */   public boolean isCheckingValidity() {
/* 145 */     return this.m_ValidityCheck;
/*     */   }
/*     */   
/*     */   public int getRetries()
/*     */   {
/* 150 */     return this.m_Retries;
/*     */   }
/*     */   
/*     */   public void setRetries(int num) {
/* 154 */     this.m_Retries = num;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void execute()
/*     */     throws ModbusIOException, ModbusSlaveException, ModbusException
/*     */   {
/* 162 */     assertExecutable();
/*     */     
/* 164 */     if (!this.m_Terminal.isActive()) {
/*     */       try {
/* 166 */         this.m_Terminal.activate();
/* 167 */         this.m_IO = this.m_Terminal.getModbusTransport();
/*     */       } catch (Exception ex) {
/* 169 */         ex.printStackTrace();
/* 170 */         throw new ModbusIOException("Activation failed.");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 177 */     this.m_RetryCounter = 0;
/*     */     break label116;
/*     */     try
/*     */     {
/*     */       do {
/* 182 */         synchronized (this.m_IO)
/*     */         {
/* 184 */           this.m_IO.writeMessage(this.m_Request);
/*     */           
/* 186 */           this.m_Response = this.m_IO.readResponse();
/*     */         }
/* 178 */       } while (this.m_RetryCounter <= this.m_Retries);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     }
/*     */     catch (ModbusIOException ex)
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 190 */       this.m_RetryCounter += 1;
/*     */     }
/*     */     
/*     */ 
/*     */     label116:
/*     */     
/* 196 */     if ((this.m_Response instanceof ExceptionResponse)) {
/* 197 */       throw new ModbusSlaveException(
/* 198 */         ((ExceptionResponse)this.m_Response).getExceptionCode());
/*     */     }
/*     */     
/*     */ 
/* 202 */     if (isCheckingValidity()) {
/* 203 */       checkValidity();
/*     */     }
/*     */     
/*     */ 
/* 207 */     toggleTransactionID();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void assertExecutable()
/*     */     throws ModbusException
/*     */   {
/* 219 */     if ((this.m_Request == null) || 
/* 220 */       (this.m_Terminal == null)) {
/* 221 */       throw new ModbusException(
/* 222 */         "Assertion failed, transaction not executable");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void checkValidity()
/*     */     throws ModbusException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void toggleTransactionID()
/*     */   {
/* 250 */     if (isCheckingValidity()) {
/* 251 */       if (c_TransactionID == 65534) {
/* 252 */         c_TransactionID = 0;
/*     */       } else {
/* 254 */         c_TransactionID += 1;
/*     */       }
/*     */     }
/* 257 */     this.m_Request.setTransactionID(getTransactionID());
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\ModbusUDPTransaction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */