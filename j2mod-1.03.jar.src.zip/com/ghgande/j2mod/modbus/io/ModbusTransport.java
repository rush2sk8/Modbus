package com.ghgande.j2mod.modbus.io;

import com.ghgande.j2mod.modbus.ModbusIOException;
import com.ghgande.j2mod.modbus.msg.ModbusMessage;
import com.ghgande.j2mod.modbus.msg.ModbusRequest;
import com.ghgande.j2mod.modbus.msg.ModbusResponse;
import java.io.IOException;

public abstract interface ModbusTransport
{
  public abstract void close()
    throws IOException;
  
  public abstract ModbusTransaction createTransaction();
  
  public abstract void writeMessage(ModbusMessage paramModbusMessage)
    throws ModbusIOException;
  
  public abstract ModbusRequest readRequest()
    throws ModbusIOException;
  
  public abstract ModbusResponse readResponse()
    throws ModbusIOException;
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\ModbusTransport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */