package com.ghgande.j2mod.modbus.io;

import com.ghgande.j2mod.modbus.ModbusException;
import com.ghgande.j2mod.modbus.msg.ModbusRequest;
import com.ghgande.j2mod.modbus.msg.ModbusResponse;

public abstract interface ModbusTransaction
{
  public abstract void setRequest(ModbusRequest paramModbusRequest);
  
  public abstract ModbusRequest getRequest();
  
  public abstract ModbusResponse getResponse();
  
  public abstract int getTransactionID();
  
  public abstract void setRetries(int paramInt);
  
  public abstract int getRetries();
  
  public abstract void setCheckingValidity(boolean paramBoolean);
  
  public abstract boolean isCheckingValidity();
  
  public abstract void execute()
    throws ModbusException;
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\ModbusTransaction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */