/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.ModbusIOException;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusMessage;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.util.ModbusUtil;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusBINTransport
/*     */   extends ModbusSerialTransport
/*     */ {
/*     */   private DataInputStream m_InputStream;
/*     */   private ASCIIOutputStream m_OutputStream;
/*     */   private byte[] m_InBuffer;
/*     */   private BytesInputStream m_ByteIn;
/*     */   private BytesOutputStream m_ByteInOut;
/*     */   private BytesOutputStream m_ByteOut;
/*     */   public static final int FRAME_START = 1000;
/*     */   public static final int FRAME_END = 2000;
/*     */   public static final int FRAME_START_TOKEN = 123;
/*     */   public static final int FRAME_END_TOKEN = 125;
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*  75 */     this.m_InputStream.close();
/*  76 */     this.m_OutputStream.close();
/*     */   }
/*     */   
/*     */   public ModbusTransaction createTransaction() {
/*  80 */     return new ModbusSerialTransaction();
/*     */   }
/*     */   
/*     */   public void writeMessage(ModbusMessage msg)
/*     */     throws ModbusIOException
/*     */   {
/*     */     try
/*     */     {
/*  88 */       synchronized (this.m_ByteOut)
/*     */       {
/*  90 */         msg.setHeadless();
/*  91 */         msg.writeTo(this.m_ByteOut);
/*  92 */         byte[] buf = this.m_ByteOut.getBuffer();
/*  93 */         int len = this.m_ByteOut.size();
/*     */         
/*     */ 
/*  96 */         this.m_OutputStream.write(1000);
/*  97 */         this.m_OutputStream.write(buf, 0, len);
/*  98 */         int[] crc = ModbusUtil.calculateCRC(buf, 0, len);
/*  99 */         this.m_OutputStream.write(crc[0]);
/* 100 */         this.m_OutputStream.write(crc[1]);
/* 101 */         this.m_OutputStream.write(2000);
/* 102 */         this.m_OutputStream.flush();
/* 103 */         this.m_ByteOut.reset();
/*     */       }
/*     */       
/*     */       int len;
/* 107 */       if (this.m_Echo)
/*     */       {
/* 109 */         readEcho(len + 4);
/*     */       }
/*     */     } catch (Exception ex) {
/* 112 */       throw new ModbusIOException("I/O failed to write");
/*     */     }
/*     */   }
/*     */   
/*     */   public ModbusRequest readRequest()
/*     */     throws ModbusIOException
/*     */   {
/* 119 */     boolean done = false;
/* 120 */     ModbusRequest request = null;
/*     */     
/* 122 */     int in = -1;
/*     */     try
/*     */     {
/*     */       do
/*     */       {
/* 127 */         while ((in = this.m_InputStream.read()) != 1000) {}
/*     */         
/* 129 */         synchronized (this.m_InBuffer) {
/* 130 */           this.m_ByteInOut.reset();
/* 131 */           while ((in = this.m_InputStream.read()) != 2000) {
/* 132 */             this.m_ByteInOut.writeByte(in);
/*     */           }
/*     */           
/* 135 */           int[] crc = ModbusUtil.calculateCRC(this.m_InBuffer, 0, this.m_ByteInOut.size() - 2);
/*     */           
/*     */ 
/* 138 */           if ((this.m_InBuffer[(this.m_ByteInOut.size() - 2)] == crc[0]) && 
/* 139 */             (this.m_InBuffer[(this.m_ByteInOut.size() - 1)] != crc[1])) {
/*     */             continue;
/*     */           }
/*     */           
/* 143 */           this.m_ByteIn.reset(this.m_InBuffer, this.m_ByteInOut.size());
/* 144 */           in = this.m_ByteIn.readUnsignedByte();
/*     */           
/* 146 */           if (in != ModbusCoupler.getReference().getUnitID()) {
/*     */             continue;
/*     */           }
/* 149 */           in = this.m_ByteIn.readUnsignedByte();
/*     */           
/* 151 */           request = ModbusRequest.createModbusRequest(in);
/* 152 */           request.setHeadless();
/*     */           
/* 154 */           this.m_ByteIn.reset(this.m_InBuffer, this.m_ByteInOut.size());
/* 155 */           request.readFrom(this.m_ByteIn);
/*     */         }
/* 157 */         done = true;
/* 158 */       } while (!done);
/* 159 */       return request;
/*     */     } catch (Exception ex) {
/* 161 */       if (Modbus.debug) System.out.println(ex.getMessage());
/* 162 */       throw new ModbusIOException("I/O exception - failed to read.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ModbusResponse readResponse()
/*     */     throws ModbusIOException
/*     */   {
/* 170 */     boolean done = false;
/* 171 */     ModbusResponse response = null;
/* 172 */     int in = -1;
/*     */     try
/*     */     {
/*     */       do
/*     */       {
/* 177 */         while ((in = this.m_InputStream.read()) != 1000) {}
/*     */         
/* 179 */         synchronized (this.m_InBuffer) {
/* 180 */           this.m_ByteInOut.reset();
/* 181 */           while ((in = this.m_InputStream.read()) != 2000) {
/* 182 */             this.m_ByteInOut.writeByte(in);
/*     */           }
/*     */           
/* 185 */           int[] crc = ModbusUtil.calculateCRC(this.m_InBuffer, 0, this.m_ByteInOut.size() - 2);
/*     */           
/* 187 */           if ((this.m_InBuffer[(this.m_ByteInOut.size() - 2)] == crc[0]) && 
/* 188 */             (this.m_InBuffer[(this.m_ByteInOut.size() - 1)] != crc[1])) {
/*     */             continue;
/*     */           }
/*     */           
/* 192 */           this.m_ByteIn.reset(this.m_InBuffer, this.m_ByteInOut.size());
/* 193 */           in = this.m_ByteIn.readUnsignedByte();
/*     */           
/* 195 */           if (in != ModbusCoupler.getReference().getUnitID()) {
/*     */             continue;
/*     */           }
/* 198 */           this.m_ByteIn.reset(this.m_InBuffer, this.m_ByteInOut.size());
/* 199 */           in = this.m_ByteIn.readUnsignedByte();
/*     */           
/* 201 */           if (in != ModbusCoupler.getReference().getUnitID()) {
/*     */             continue;
/*     */           }
/* 204 */           in = this.m_ByteIn.readUnsignedByte();
/*     */           
/* 206 */           response = ModbusResponse.createModbusResponse(in);
/* 207 */           response.setHeadless();
/*     */           
/* 209 */           this.m_ByteIn.reset(this.m_InBuffer, this.m_ByteInOut.size());
/* 210 */           response.readFrom(this.m_ByteIn);
/*     */         }
/* 212 */         done = true;
/* 213 */       } while (!done);
/* 214 */       return response;
/*     */     } catch (Exception ex) {
/* 216 */       if (Modbus.debug) System.out.println(ex.getMessage());
/* 217 */       throw new ModbusIOException("I/O exception - failed to read.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prepareStreams(InputStream in, OutputStream out)
/*     */     throws IOException
/*     */   {
/* 232 */     this.m_InputStream = new DataInputStream(new ASCIIInputStream(in));
/* 233 */     this.m_OutputStream = new ASCIIOutputStream(out);
/* 234 */     this.m_ByteOut = new BytesOutputStream(256);
/* 235 */     this.m_InBuffer = new byte['Ā'];
/* 236 */     this.m_ByteIn = new BytesInputStream(this.m_InBuffer);
/* 237 */     this.m_ByteInOut = new BytesOutputStream(this.m_InBuffer);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\ModbusBINTransport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */