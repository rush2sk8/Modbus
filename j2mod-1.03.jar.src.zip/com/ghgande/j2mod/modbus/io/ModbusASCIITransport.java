/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.ModbusIOException;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusMessage;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.util.ModbusUtil;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusASCIITransport
/*     */   extends ModbusSerialTransport
/*     */ {
/*     */   private DataInputStream m_InputStream;
/*     */   private ASCIIOutputStream m_OutputStream;
/*     */   private byte[] m_InBuffer;
/*     */   private BytesInputStream m_ByteIn;
/*     */   private BytesOutputStream m_ByteInOut;
/*     */   private BytesOutputStream m_ByteOut;
/*     */   public static final int FRAME_START = 1000;
/*     */   public static final int FRAME_END = 2000;
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/*  76 */     this.m_InputStream.close();
/*  77 */     this.m_OutputStream.close();
/*     */   }
/*     */   
/*     */   public ModbusTransaction createTransaction() {
/*  81 */     return new ModbusSerialTransaction();
/*     */   }
/*     */   
/*     */   public void writeMessage(ModbusMessage msg) throws ModbusIOException
/*     */   {
/*     */     try
/*     */     {
/*  88 */       synchronized (this.m_ByteOut)
/*     */       {
/*  90 */         msg.setHeadless();
/*  91 */         msg.writeTo(this.m_ByteOut);
/*  92 */         byte[] buf = this.m_ByteOut.getBuffer();
/*  93 */         int len = this.m_ByteOut.size();
/*     */         
/*     */ 
/*  96 */         this.m_OutputStream.write(1000);
/*  97 */         this.m_OutputStream.write(buf, 0, len);
/*  98 */         System.out.println("Writing: " + ModbusUtil.toHex(buf, 0, len));
/*  99 */         this.m_OutputStream.write(calculateLRC(buf, 0, len));
/* 100 */         this.m_OutputStream.write(2000);
/* 101 */         this.m_OutputStream.flush();
/* 102 */         this.m_ByteOut.reset();
/*     */         
/*     */ 
/* 105 */         if (this.m_Echo)
/*     */         {
/* 107 */           readEcho(len + 3);
/*     */         }
/*     */       }
/*     */     } catch (Exception ex) {
/* 111 */       throw new ModbusIOException("I/O failed to write");
/*     */     }
/*     */   }
/*     */   
/*     */   public ModbusRequest readRequest()
/*     */     throws ModbusIOException
/*     */   {
/* 118 */     boolean done = false;
/* 119 */     ModbusRequest request = null;
/*     */     
/* 121 */     int in = -1;
/*     */     try
/*     */     {
/*     */       do
/*     */       {
/* 126 */         while ((in = this.m_InputStream.read()) != 1000) {}
/*     */         
/* 128 */         synchronized (this.m_InBuffer) {
/* 129 */           this.m_ByteInOut.reset();
/* 130 */           while ((in = this.m_InputStream.read()) != 2000) {
/* 131 */             if (in == -1) {
/* 132 */               throw new IOException("I/O exception - Serial port timeout.");
/*     */             }
/* 134 */             this.m_ByteInOut.writeByte(in);
/*     */           }
/*     */           
/* 137 */           if (this.m_InBuffer[(this.m_ByteInOut.size() - 1)] != 
/* 138 */             calculateLRC(this.m_InBuffer, 0, this.m_ByteInOut.size(), 1)) {
/*     */             continue;
/*     */           }
/*     */           
/* 142 */           this.m_ByteIn.reset(this.m_InBuffer, this.m_ByteInOut.size());
/* 143 */           in = this.m_ByteIn.readUnsignedByte();
/*     */           
/* 145 */           if (in != ModbusCoupler.getReference().getUnitID()) {
/*     */             continue;
/*     */           }
/* 148 */           in = this.m_ByteIn.readUnsignedByte();
/*     */           
/* 150 */           request = ModbusRequest.createModbusRequest(in);
/* 151 */           request.setHeadless();
/*     */           
/* 153 */           this.m_ByteIn.reset(this.m_InBuffer, this.m_ByteInOut.size());
/* 154 */           request.readFrom(this.m_ByteIn);
/*     */         }
/* 156 */         done = true;
/* 157 */       } while (!done);
/* 158 */       return request;
/*     */     } catch (Exception ex) {
/* 160 */       if (Modbus.debug) System.out.println(ex.getMessage());
/* 161 */       throw new ModbusIOException("I/O exception - failed to read.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public ModbusResponse readResponse()
/*     */     throws ModbusIOException
/*     */   {
/* 169 */     boolean done = false;
/* 170 */     ModbusResponse response = null;
/* 171 */     int in = -1;
/*     */     try
/*     */     {
/*     */       do
/*     */       {
/* 176 */         while ((in = this.m_InputStream.read()) != 1000) {
/* 177 */           if (in == -1) {
/* 178 */             throw new IOException("I/O exception - Serial port timeout.");
/*     */           }
/*     */         }
/*     */         
/* 182 */         synchronized (this.m_InBuffer) {
/* 183 */           this.m_ByteInOut.reset();
/* 184 */           while ((in = this.m_InputStream.read()) != 2000) {
/* 185 */             if (in == -1) {
/* 186 */               throw new IOException("I/O exception - Serial port timeout.");
/*     */             }
/* 188 */             this.m_ByteInOut.writeByte(in);
/*     */           }
/* 190 */           int len = this.m_ByteInOut.size();
/* 191 */           if (Modbus.debug) {
/* 192 */             System.out.println("Received: " + 
/* 193 */               ModbusUtil.toHex(this.m_InBuffer, 0, len));
/*     */           }
/* 195 */           if (this.m_InBuffer[(len - 1)] != calculateLRC(this.m_InBuffer, 0, len, 1)) {
/*     */             continue;
/*     */           }
/*     */           
/* 199 */           this.m_ByteIn.reset(this.m_InBuffer, this.m_ByteInOut.size());
/* 200 */           in = this.m_ByteIn.readUnsignedByte();
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 209 */           in = this.m_ByteIn.readUnsignedByte();
/*     */           
/* 211 */           response = ModbusResponse.createModbusResponse(in);
/* 212 */           response.setHeadless();
/*     */           
/* 214 */           this.m_ByteIn.reset(this.m_InBuffer, this.m_ByteInOut.size());
/* 215 */           response.readFrom(this.m_ByteIn);
/*     */         }
/* 217 */         done = true;
/* 218 */       } while (!done);
/* 219 */       return response;
/*     */     } catch (Exception ex) {
/* 221 */       if (Modbus.debug) System.out.println(ex.getMessage());
/* 222 */       throw new ModbusIOException("I/O exception - failed to read.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void prepareStreams(InputStream in, OutputStream out)
/*     */     throws IOException
/*     */   {
/* 237 */     this.m_InputStream = new DataInputStream(new ASCIIInputStream(in));
/* 238 */     this.m_OutputStream = new ASCIIOutputStream(out);
/* 239 */     this.m_ByteOut = new BytesOutputStream(256);
/* 240 */     this.m_InBuffer = new byte['Ā'];
/* 241 */     this.m_ByteIn = new BytesInputStream(this.m_InBuffer);
/* 242 */     this.m_ByteInOut = new BytesOutputStream(this.m_InBuffer);
/*     */   }
/*     */   
/*     */   private static final int calculateLRC(byte[] data, int off, int len) {
/* 246 */     int lrc = 0;
/* 247 */     for (int i = off; i < len; i++) {
/* 248 */       lrc += data[i];
/*     */     }
/* 250 */     return (byte)lrc & 0xFF;
/*     */   }
/*     */   
/*     */   private final byte calculateLRC(byte[] data, int off, int length, int tailskip) {
/* 254 */     int lrc = 0;
/* 255 */     for (int i = off; i < length - tailskip; i++) {
/* 256 */       lrc += data[i];
/*     */     }
/* 258 */     return (byte)lrc;
/*     */   }
/*     */   
/*     */   public boolean getDebug() {
/* 262 */     return "true".equals(System.getProperty("com.ghgande.j2mod.modbus.debug"));
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\ModbusASCIITransport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */