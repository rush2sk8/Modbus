/*    */ package com.ghgande.j2mod.modbus.io;
/*    */ 
/*    */ import java.io.FilterInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BINInputStream
/*    */   extends FilterInputStream
/*    */ {
/*    */   public BINInputStream(InputStream in)
/*    */   {
/* 60 */     super(in);
/* 61 */     if (!in.markSupported()) {
/* 62 */       throw new RuntimeException("Accepts only input streams that support marking.");
/*    */     }
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public int read()
/*    */     throws IOException
/*    */   {
/* 74 */     int ch = this.in.read();
/* 75 */     if (ch == -1)
/* 76 */       return -1;
/* 77 */     if (ch == 123) {
/* 78 */       this.in.mark(1);
/*    */       
/* 80 */       ch = this.in.read();
/* 81 */       if (ch == 123) {
/* 82 */         return ch;
/*    */       }
/* 84 */       this.in.reset();
/* 85 */       return 1000;
/*    */     }
/* 87 */     if (ch == 125) {
/* 88 */       this.in.mark(1);
/*    */       
/* 90 */       ch = this.in.read();
/* 91 */       if (ch == 125) {
/* 92 */         return ch;
/*    */       }
/* 94 */       this.in.reset();
/* 95 */       return 2000;
/*    */     }
/*    */     
/* 98 */     return ch;
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\BINInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */