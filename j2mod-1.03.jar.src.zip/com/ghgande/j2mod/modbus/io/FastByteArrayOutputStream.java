/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FastByteArrayOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   public static final int DEFAULT_INIT_SIZE = 100;
/*     */   public static final int DEFAULT_BUMP_SIZE = 100;
/*     */   protected int count;
/*     */   protected int bumpLen;
/*     */   protected byte[] buf;
/*     */   
/*     */   public FastByteArrayOutputStream()
/*     */   {
/* 125 */     this.buf = new byte[100];
/* 126 */     this.bumpLen = 100;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FastByteArrayOutputStream(int initialSize)
/*     */   {
/* 136 */     this.buf = new byte[initialSize];
/* 137 */     this.bumpLen = 100;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FastByteArrayOutputStream(int initialSize, int bumpSize)
/*     */   {
/* 147 */     this.buf = new byte[initialSize];
/* 148 */     this.bumpLen = bumpSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FastByteArrayOutputStream(byte[] buffer)
/*     */   {
/* 158 */     this.buf = buffer;
/* 159 */     this.bumpLen = 100;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public FastByteArrayOutputStream(byte[] buffer, int bumpSize)
/*     */   {
/* 170 */     this.buf = buffer;
/* 171 */     this.bumpLen = bumpSize;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int size()
/*     */   {
/* 183 */     return this.count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void reset()
/*     */   {
/* 190 */     this.count = 0;
/*     */   }
/*     */   
/*     */   public void write(int b) throws IOException {
/* 194 */     if (this.count + 1 > this.buf.length) {
/* 195 */       bump(1);
/*     */     }
/* 197 */     this.buf[(this.count++)] = ((byte)b);
/*     */   }
/*     */   
/*     */   public void write(byte[] fromBuf) throws IOException {
/* 201 */     int needed = this.count + fromBuf.length - this.buf.length;
/* 202 */     if (needed > 0) {
/* 203 */       bump(needed);
/*     */     }
/* 205 */     for (int i = 0; i < fromBuf.length; i++) {
/* 206 */       this.buf[(this.count++)] = fromBuf[i];
/*     */     }
/*     */   }
/*     */   
/*     */   public void write(byte[] fromBuf, int offset, int length)
/*     */     throws IOException
/*     */   {
/* 213 */     int needed = this.count + length - this.buf.length;
/* 214 */     if (needed > 0) {
/* 215 */       bump(needed);
/*     */     }
/* 217 */     int fromLen = offset + length;
/*     */     
/* 219 */     for (int i = offset; i < fromLen; i++) {
/* 220 */       this.buf[(this.count++)] = fromBuf[i];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void writeTo(OutputStream out)
/*     */     throws IOException
/*     */   {
/* 234 */     out.write(this.buf, 0, this.count);
/*     */   }
/*     */   
/*     */   public String toString() {
/* 238 */     return new String(this.buf, 0, this.count);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString(String encoding)
/*     */     throws UnsupportedEncodingException
/*     */   {
/* 252 */     return new String(this.buf, 0, this.count, encoding);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] toByteArray()
/*     */   {
/* 263 */     byte[] toBuf = new byte[this.count];
/* 264 */     System.arraycopy(this.buf, 0, toBuf, 0, this.count);
/*     */     
/*     */ 
/*     */ 
/* 268 */     return toBuf;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void toByteArray(byte[] toBuf, int offset)
/*     */   {
/* 280 */     int toLen = toBuf.length > this.count ? this.count : toBuf.length;
/* 281 */     for (int i = offset; i < toLen; i++) {
/* 282 */       toBuf[i] = this.buf[i];
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBufferBytes()
/*     */   {
/* 292 */     return this.buf;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBufferOffset()
/*     */   {
/* 301 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBufferLength()
/*     */   {
/* 311 */     return this.count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void makeSpace(int sizeNeeded)
/*     */   {
/* 322 */     int needed = this.count + sizeNeeded - this.buf.length;
/* 323 */     if (needed > 0) {
/* 324 */       bump(needed);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void addSize(int sizeAdded)
/*     */   {
/* 334 */     this.count += sizeAdded;
/*     */   }
/*     */   
/*     */   private void bump(int needed)
/*     */   {
/* 339 */     byte[] toBuf = new byte[this.buf.length + needed + this.bumpLen];
/*     */     
/* 341 */     for (int i = 0; i < this.count; i++) {
/* 342 */       toBuf[i] = this.buf[i];
/*     */     }
/* 344 */     this.buf = toBuf;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\FastByteArrayOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */