/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusIOException;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusMessage;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusRequest;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusResponse;
/*     */ import com.ghgande.j2mod.modbus.net.TCPMasterConnection;
/*     */ import com.ghgande.j2mod.modbus.util.ModbusUtil;
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.net.SocketTimeoutException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ModbusTCPTransport
/*     */   implements ModbusTransport
/*     */ {
/*     */   private DataInputStream m_Input;
/*     */   private DataOutputStream m_Output;
/*     */   private BytesInputStream m_ByteIn;
/*     */   private BytesOutputStream m_ByteOut;
/*  70 */   private int m_Timeout = 3000;
/*  71 */   private Socket m_Socket = null;
/*  72 */   private TCPMasterConnection m_Master = null;
/*  73 */   private boolean headless = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSocket(Socket socket)
/*     */     throws IOException
/*     */   {
/*  85 */     if (this.m_Socket != null) {
/*  86 */       this.m_Socket.close();
/*  87 */       this.m_Socket = null;
/*     */     }
/*  89 */     this.m_Socket = socket;
/*  90 */     setTimeout(this.m_Timeout);
/*     */     
/*  92 */     prepareStreams(socket);
/*     */   }
/*     */   
/*     */   public void setHeadless() {
/*  96 */     this.headless = true;
/*     */   }
/*     */   
/*     */   public void setTimeout(int time) {
/* 100 */     this.m_Timeout = time;
/*     */     
/* 102 */     if (this.m_Socket != null) {
/*     */       try {
/* 104 */         this.m_Socket.setSoTimeout(time);
/*     */       }
/*     */       catch (SocketException e) {}
/*     */     }
/*     */   }
/*     */   
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 113 */     this.m_Input.close();
/* 114 */     this.m_Output.close();
/* 115 */     this.m_Socket.close();
/*     */   }
/*     */   
/*     */   public ModbusTransaction createTransaction() {
/* 119 */     if (this.m_Master == null) {
/* 120 */       this.m_Master = new TCPMasterConnection(this.m_Socket.getInetAddress());
/* 121 */       this.m_Master.setPort(this.m_Socket.getPort());
/* 122 */       this.m_Master.setModbusTransport(this);
/*     */     }
/* 124 */     ModbusTCPTransaction trans = new ModbusTCPTransaction(this.m_Master);
/* 125 */     return trans;
/*     */   }
/*     */   
/*     */   public void writeMessage(ModbusMessage msg) throws ModbusIOException {
/*     */     try {
/* 130 */       byte[] message = msg.getMessage();
/*     */       
/* 132 */       this.m_ByteOut.reset();
/* 133 */       if (!this.headless) {
/* 134 */         this.m_ByteOut.writeShort(msg.getTransactionID());
/* 135 */         this.m_ByteOut.writeShort(msg.getProtocolID());
/* 136 */         this.m_ByteOut
/* 137 */           .writeShort((message != null ? message.length : 0) + 2);
/*     */       }
/* 139 */       this.m_ByteOut.writeByte(msg.getUnitID());
/* 140 */       this.m_ByteOut.writeByte(msg.getFunctionCode());
/* 141 */       if ((message != null) && (message.length > 0)) {
/* 142 */         this.m_ByteOut.write(message);
/*     */       }
/* 144 */       this.m_Output.write(this.m_ByteOut.toByteArray());
/* 145 */       this.m_Output.flush();
/* 146 */       if (Modbus.debug) {
/* 147 */         System.err.println("Sent: " + 
/* 148 */           ModbusUtil.toHex(this.m_ByteOut.toByteArray()));
/*     */       }
/*     */     } catch (SocketException ex) {
/* 151 */       if (!this.m_Master.isConnected()) {
/*     */         try {
/* 153 */           this.m_Master.connect();
/*     */         }
/*     */         catch (Exception localException1) {}
/*     */       }
/*     */       
/* 158 */       throw new ModbusIOException("I/O exception - failed to write.");
/*     */     } catch (Exception ex) {
/* 160 */       throw new ModbusIOException("I/O exception - failed to write.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusRequest readRequest()
/*     */     throws ModbusIOException
/*     */   {
/*     */     try
/*     */     {
/* 174 */       ModbusRequest req = null;
/* 175 */       this.m_ByteIn.reset();
/*     */       
/* 177 */       synchronized (this.m_ByteIn) {
/* 178 */         byte[] buffer = this.m_ByteIn.getBuffer();
/*     */         
/* 180 */         if (!this.headless) {
/* 181 */           if (this.m_Input.read(buffer, 0, 6) == -1) {
/* 182 */             throw new EOFException(
/* 183 */               "Premature end of stream (Header truncated).");
/*     */           }
/* 185 */           int transaction = ModbusUtil.registerToShort(buffer, 0);
/* 186 */           int protocol = ModbusUtil.registerToShort(buffer, 2);
/* 187 */           int count = ModbusUtil.registerToShort(buffer, 4);
/*     */           
/* 189 */           if (this.m_Input.read(buffer, 6, count) == -1) {
/* 190 */             throw new ModbusIOException(
/* 191 */               "Premature end of stream (Message truncated).");
/*     */           }
/* 193 */           if (Modbus.debug) {
/* 194 */             System.err.println("Read: " + 
/* 195 */               ModbusUtil.toHex(buffer, 0, count + 6));
/*     */           }
/* 197 */           this.m_ByteIn.reset(buffer, 6 + count);
/* 198 */           this.m_ByteIn.skip(6);
/*     */           
/* 200 */           int unit = this.m_ByteIn.readByte();
/* 201 */           int functionCode = this.m_ByteIn.readUnsignedByte();
/*     */           
/* 203 */           this.m_ByteIn.reset();
/* 204 */           req = ModbusRequest.createModbusRequest(functionCode);
/* 205 */           req.setUnitID(unit);
/* 206 */           req.setHeadless(false);
/*     */           
/* 208 */           req.setTransactionID(transaction);
/* 209 */           req.setProtocolID(protocol);
/* 210 */           req.setDataLength(count);
/*     */           
/* 212 */           req.readFrom(this.m_ByteIn);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 218 */           int unit = this.m_Input.readByte();
/* 219 */           int function = this.m_Input.readByte();
/*     */           
/* 221 */           req = ModbusRequest.createModbusRequest(function);
/* 222 */           req.setUnitID(unit);
/* 223 */           req.setHeadless(true);
/*     */           
/* 225 */           req.readData(this.m_Input);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 231 */           this.m_Input.readShort();
/* 232 */           if (Modbus.debug)
/* 233 */             System.err.println("Read: " + req.getHexMessage());
/*     */         }
/*     */       }
/* 236 */       return req;
/*     */     } catch (EOFException eoex) {
/* 238 */       throw new ModbusIOException("End of File", true);
/*     */     } catch (SocketTimeoutException x) {
/* 240 */       throw new ModbusIOException("Timeout reading request");
/*     */     } catch (SocketException sockex) {
/* 242 */       throw new ModbusIOException("Socket Exception", true);
/*     */     } catch (Exception ex) {
/* 244 */       throw new ModbusIOException("I/O exception - failed to read.");
/*     */     }
/*     */   }
/*     */   
/*     */   public ModbusResponse readResponse() throws ModbusIOException
/*     */   {
/*     */     try
/*     */     {
/* 252 */       ModbusResponse response = null;
/*     */       
/* 254 */       synchronized (this.m_ByteIn)
/*     */       {
/* 256 */         byte[] buffer = this.m_ByteIn.getBuffer();
/* 257 */         if (Modbus.debug) {
/* 258 */           System.err.println("Read: " + 
/* 259 */             ModbusUtil.toHex(buffer, 0, this.m_ByteIn.count));
/*     */         }
/* 261 */         if (!this.headless)
/*     */         {
/*     */ 
/*     */ 
/* 265 */           if (this.m_Input.read(buffer, 0, 6) == -1) {
/* 266 */             throw new ModbusIOException(
/* 267 */               "Premature end of stream (Header truncated).");
/*     */           }
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 281 */           int transaction = ModbusUtil.registerToShort(buffer, 0);
/* 282 */           int protocol = ModbusUtil.registerToShort(buffer, 2);
/* 283 */           int count = ModbusUtil.registerToShort(buffer, 4);
/*     */           
/* 285 */           if (this.m_Input.read(buffer, 6, count) == -1) {
/* 286 */             throw new ModbusIOException(
/* 287 */               "Premature end of stream (Message truncated).");
/*     */           }
/* 289 */           this.m_ByteIn.reset(buffer, 6 + count);
/*     */           
/* 291 */           this.m_ByteIn.reset();
/* 292 */           this.m_ByteIn.skip(7);
/* 293 */           int function = this.m_ByteIn.readUnsignedByte();
/* 294 */           response = ModbusResponse.createModbusResponse(function);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 300 */           this.m_ByteIn.reset();
/* 301 */           response.readFrom(this.m_ByteIn);
/*     */           
/* 303 */           response.setTransactionID(transaction);
/* 304 */           response.setProtocolID(protocol);
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/* 310 */           int unit = this.m_Input.readByte();
/* 311 */           int function = this.m_Input.readByte();
/*     */           
/* 313 */           response = ModbusResponse.createModbusResponse(function);
/* 314 */           response.setUnitID(unit);
/* 315 */           response.setHeadless();
/* 316 */           response.readData(this.m_Input);
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 322 */           this.m_Input.readShort();
/*     */         }
/*     */       }
/* 325 */       return response;
/*     */     } catch (SocketTimeoutException ex) {
/* 327 */       throw new ModbusIOException("Timeout reading response");
/*     */     } catch (Exception ex) {
/* 329 */       throw new ModbusIOException("I/O exception - failed to read.");
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void prepareStreams(Socket socket)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 349 */       if (this.m_Input != null) {
/* 350 */         this.m_Input.close();
/*     */       }
/* 352 */       if (this.m_Output != null) {
/* 353 */         this.m_Output.close();
/*     */       }
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */     
/* 358 */     this.m_Input = new DataInputStream(new BufferedInputStream(
/* 359 */       socket.getInputStream()));
/*     */     
/* 361 */     this.m_Output = new DataOutputStream(new BufferedOutputStream(
/* 362 */       socket.getOutputStream()));
/*     */     
/* 364 */     this.m_ByteIn = new BytesInputStream(256);
/*     */     
/* 366 */     this.m_ByteOut = new BytesOutputStream(256);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusTCPTransport(Socket socket)
/*     */   {
/*     */     try
/*     */     {
/* 379 */       setSocket(socket);
/* 380 */       socket.setSoTimeout(this.m_Timeout);
/*     */     } catch (IOException ex) {
/* 382 */       if (Modbus.debug) {
/* 383 */         System.out.println("ModbusTCPTransport::Socket invalid.");
/*     */       }
/* 385 */       throw new IllegalStateException("Socket invalid.");
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\ModbusTCPTransport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */