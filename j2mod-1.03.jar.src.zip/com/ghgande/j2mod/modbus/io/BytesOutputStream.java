/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import java.io.DataOutput;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BytesOutputStream
/*     */   extends FastByteArrayOutputStream
/*     */   implements DataOutput
/*     */ {
/*     */   private DataOutputStream m_Dout;
/*     */   
/*     */   public BytesOutputStream(int size)
/*     */   {
/*  60 */     super(size);
/*  61 */     this.m_Dout = new DataOutputStream(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BytesOutputStream(byte[] buffer)
/*     */   {
/*  71 */     this.buf = buffer;
/*  72 */     this.count = 0;
/*  73 */     this.m_Dout = new DataOutputStream(this);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getBuffer()
/*     */   {
/*  82 */     return this.buf;
/*     */   }
/*     */   
/*     */   public void reset() {
/*  86 */     this.count = 0;
/*     */   }
/*     */   
/*     */   public void writeBoolean(boolean v) throws IOException
/*     */   {
/*  91 */     this.m_Dout.writeBoolean(v);
/*     */   }
/*     */   
/*     */   public void writeByte(int v) throws IOException
/*     */   {
/*  96 */     this.m_Dout.writeByte(v);
/*     */   }
/*     */   
/*     */   public void writeShort(int v) throws IOException
/*     */   {
/* 101 */     this.m_Dout.writeShort(v);
/*     */   }
/*     */   
/*     */   public void writeChar(int v) throws IOException
/*     */   {
/* 106 */     this.m_Dout.writeChar(v);
/*     */   }
/*     */   
/*     */   public void writeInt(int v) throws IOException
/*     */   {
/* 111 */     this.m_Dout.writeInt(v);
/*     */   }
/*     */   
/*     */   public void writeLong(long v) throws IOException
/*     */   {
/* 116 */     this.m_Dout.writeLong(v);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeFloat(float v)
/*     */     throws IOException
/*     */   {
/* 123 */     this.m_Dout.writeFloat(v);
/*     */   }
/*     */   
/*     */   public void writeDouble(double v) throws IOException
/*     */   {
/* 128 */     this.m_Dout.writeDouble(v);
/*     */   }
/*     */   
/*     */   public void writeBytes(String s)
/*     */     throws IOException
/*     */   {
/* 134 */     int len = s.length();
/* 135 */     for (int i = 0; i < len; i++) {
/* 136 */       write((byte)s.charAt(i));
/*     */     }
/*     */   }
/*     */   
/*     */   public void writeChars(String s) throws IOException
/*     */   {
/* 142 */     this.m_Dout.writeChars(s);
/*     */   }
/*     */   
/*     */   public void writeUTF(String str) throws IOException
/*     */   {
/* 147 */     this.m_Dout.writeUTF(str);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\BytesOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */