/*     */ package com.ghgande.j2mod.modbus.io;
/*     */ 
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class BINOutputStream
/*     */   extends FilterOutputStream
/*     */ {
/*     */   public BINOutputStream(OutputStream out)
/*     */   {
/*  66 */     super(out);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(int b)
/*     */     throws IOException
/*     */   {
/*  77 */     if (b == 1000) {
/*  78 */       this.out.write(123);
/*  79 */       return; }
/*  80 */     if (b == 2000) {
/*  81 */       this.out.write(125);
/*  82 */       return; }
/*  83 */     if ((b == 123) || (b == 125)) {
/*  84 */       this.out.write(b);
/*  85 */       this.out.write(b);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(byte[] data)
/*     */     throws IOException
/*     */   {
/*  98 */     for (int i = 0; i < data.length; i++) {
/*  99 */       write(data[i]);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void write(byte[] data, int off, int len)
/*     */     throws IOException
/*     */   {
/* 114 */     for (int i = off; i < len; i++) {
/* 115 */       write(data[i]);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\io\BINOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */