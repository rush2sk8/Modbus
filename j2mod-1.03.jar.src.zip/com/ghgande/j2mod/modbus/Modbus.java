/*     */ package com.ghgande.j2mod.modbus;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract interface Modbus
/*     */ {
/*  50 */   public static final boolean debug = "true".equals(System.getProperty("com.ghgande.modbus.debug"));
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_COILS = 1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_INPUT_DISCRETES = 2;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_HOLDING_REGISTERS = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_MULTIPLE_REGISTERS = 3;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_INPUT_REGISTERS = 4;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int WRITE_COIL = 5;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int WRITE_SINGLE_REGISTER = 6;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_EXCEPTION_STATUS = 7;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_SERIAL_DIAGNOSTICS = 8;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_COMM_EVENT_COUNTER = 11;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_COMM_EVENT_LOG = 12;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int WRITE_MULTIPLE_COILS = 15;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int WRITE_MULTIPLE_REGISTERS = 16;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int REPORT_SLAVE_ID = 17;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_FILE_RECORD = 20;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int WRITE_FILE_RECORD = 21;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int MASK_WRITE_REGISTER = 22;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_WRITE_MULTIPLE = 23;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_FIFO_QUEUE = 24;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_MEI = 43;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int READ_MEI_VENDOR_INFO = 14;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int COIL_ON = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int COIL_OFF = 0;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 194 */   public static final byte[] COIL_ON_BYTES = { -1 };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/* 199 */   public static final byte[] COIL_OFF_BYTES = new byte[2];
/*     */   public static final int MAX_BITS = 2000;
/*     */   public static final int EXCEPTION_OFFSET = 128;
/*     */   public static final int ILLEGAL_FUNCTION_EXCEPTION = 1;
/*     */   public static final int ILLEGAL_ADDRESS_EXCEPTION = 2;
/*     */   public static final int ILLEGAL_VALUE_EXCEPTION = 3;
/*     */   public static final int SLAVE_DEVICE_FAILURE = 4;
/*     */   public static final int NEGATIVE_ACKNOWLEDGEMENT = 7;
/*     */   public static final int DEFAULT_PORT = 502;
/*     */   public static final int MAX_MESSAGE_LENGTH = 256;
/*     */   public static final int DEFAULT_TRANSACTION_ID = 0;
/*     */   public static final int DEFAULT_PROTOCOL_ID = 0;
/*     */   public static final int DEFAULT_UNIT_ID = 0;
/*     */   public static final boolean DEFAULT_VALIDITYCHECK = true;
/*     */   public static final int DEFAULT_TIMEOUT = 3000;
/*     */   public static final boolean DEFAULT_RECONNECTING = false;
/*     */   public static final int DEFAULT_RETRIES = 3;
/*     */   public static final int DEFAULT_TRANSMIT_DELAY = 0;
/*     */   public static final int MAX_TRANSACTION_ID = 65534;
/*     */   public static final String SERIAL_ENCODING_ASCII = "ascii";
/*     */   public static final String SERIAL_ENCODING_RTU = "rtu";
/*     */   public static final String SERIAL_ENCODING_BIN = "bin";
/*     */   public static final String DEFAULT_SERIAL_ENCODING = "ascii";
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\Modbus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */