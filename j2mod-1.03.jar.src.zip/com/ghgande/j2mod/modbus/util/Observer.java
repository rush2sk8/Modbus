package com.ghgande.j2mod.modbus.util;

public abstract interface Observer
{
  public abstract void update(Observable paramObservable, Object paramObject);
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\util\Observer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */