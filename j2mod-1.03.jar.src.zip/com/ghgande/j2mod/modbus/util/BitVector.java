/*     */ package com.ghgande.j2mod.modbus.util;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BitVector
/*     */ {
/*     */   private int m_Size;
/*     */   private byte[] m_Data;
/*  51 */   private boolean m_MSBAccess = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BitVector(int size)
/*     */   {
/*  62 */     this.m_Size = size;
/*     */     
/*     */ 
/*  65 */     if (size % 8 > 0) {
/*  66 */       size = size / 8 + 1;
/*     */     } else {
/*  68 */       size /= 8;
/*     */     }
/*  70 */     this.m_Data = new byte[size];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void toggleAccess(boolean b)
/*     */   {
/*  81 */     this.m_MSBAccess = (!this.m_MSBAccess);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isLSBAccess()
/*     */   {
/*  92 */     return !this.m_MSBAccess;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isMSBAccess()
/*     */   {
/* 103 */     return this.m_MSBAccess;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final byte[] getBytes()
/*     */   {
/* 113 */     return this.m_Data;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setBytes(byte[] data)
/*     */   {
/* 123 */     System.arraycopy(data, 0, this.m_Data, 0, data.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setBytes(byte[] data, int size)
/*     */   {
/* 133 */     System.arraycopy(data, 0, this.m_Data, 0, data.length);
/* 134 */     this.m_Size = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final boolean getBit(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 150 */     index = translateIndex(index);
/*     */     
/* 152 */     return 
/* 153 */       (this.m_Data[byteIndex(index)] & 
/* 154 */       1 << bitIndex(index)) != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void setBit(int index, boolean b)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 170 */     index = translateIndex(index);
/*     */     
/* 172 */     int value = b ? 1 : 0;
/* 173 */     int byteNum = byteIndex(index);
/* 174 */     int bitNum = bitIndex(index);
/* 175 */     this.m_Data[byteNum] = ((byte)(
/* 176 */       this.m_Data[byteNum] & (1 << bitNum ^ 0xFFFFFFFF) | 
/* 177 */       (value & 0x1) << bitNum));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int size()
/*     */   {
/* 188 */     return this.m_Size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final void forceSize(int size)
/*     */   {
/* 199 */     if (size > this.m_Data.length * 8) {
/* 200 */       throw new IllegalArgumentException("Size exceeds byte[] store.");
/*     */     }
/* 202 */     this.m_Size = size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public final int byteSize()
/*     */   {
/* 213 */     return this.m_Data.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String toString()
/*     */   {
/* 228 */     StringBuffer sbuf = new StringBuffer();
/* 229 */     for (int i = 0; i < size(); i++) {
/* 230 */       int idx = doTranslateIndex(i);
/* 231 */       sbuf.append(
/* 232 */         (this.m_Data[byteIndex(idx)] & 
/* 233 */         1 << bitIndex(idx)) != 0 ? 
/* 234 */         '1' : '0');
/*     */       
/* 236 */       if ((i + 1) % 8 == 0) {
/* 237 */         sbuf.append(" ");
/*     */       }
/*     */     }
/* 240 */     return sbuf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int byteIndex(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 258 */     if ((index < 0) || (index >= this.m_Data.length * 8)) {
/* 259 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 261 */     return index / 8;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private final int bitIndex(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 280 */     if ((index < 0) || (index >= this.m_Data.length * 8)) {
/* 281 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 283 */     return index % 8;
/*     */   }
/*     */   
/*     */   private final int translateIndex(int idx)
/*     */   {
/* 288 */     if (this.m_MSBAccess) {
/* 289 */       int mod4 = idx % 4;
/* 290 */       int div4 = idx / 4;
/*     */       
/* 292 */       if (div4 % 2 != 0)
/*     */       {
/* 294 */         return idx + ODD_OFFSETS[mod4];
/*     */       }
/*     */       
/* 297 */       return idx + STRAIGHT_OFFSETS[mod4];
/*     */     }
/*     */     
/* 300 */     return idx;
/*     */   }
/*     */   
/*     */ 
/*     */   private static final int doTranslateIndex(int idx)
/*     */   {
/* 306 */     int mod4 = idx % 4;
/* 307 */     int div4 = idx / 4;
/*     */     
/* 309 */     if (div4 % 2 != 0)
/*     */     {
/* 311 */       return idx + ODD_OFFSETS[mod4];
/*     */     }
/*     */     
/* 314 */     return idx + STRAIGHT_OFFSETS[mod4];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BitVector createBitVector(byte[] data, int size)
/*     */   {
/* 326 */     BitVector bv = new BitVector(data.length * 8);
/* 327 */     bv.setBytes(data);
/* 328 */     bv.m_Size = size;
/* 329 */     return bv;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static BitVector createBitVector(byte[] data)
/*     */   {
/* 340 */     BitVector bv = new BitVector(data.length * 8);
/* 341 */     bv.setBytes(data);
/* 342 */     return bv;
/*     */   }
/*     */   
/*     */   public static void main(String[] args) {
/* 346 */     BitVector test = new BitVector(24);
/* 347 */     System.out.println(test.isLSBAccess());
/* 348 */     test.setBit(7, true);
/* 349 */     System.out.println(test.getBit(7));
/* 350 */     test.toggleAccess(true);
/* 351 */     System.out.println(test.getBit(7));
/*     */     
/* 353 */     test.toggleAccess(true);
/* 354 */     test.setBit(6, true);
/* 355 */     test.setBit(3, true);
/* 356 */     test.setBit(2, true);
/*     */     
/* 358 */     test.setBit(0, true);
/* 359 */     test.setBit(8, true);
/* 360 */     test.setBit(10, true);
/*     */     
/* 362 */     System.out.println(test);
/* 363 */     test.toggleAccess(true);
/* 364 */     System.out.println(test);
/* 365 */     test.toggleAccess(true);
/* 366 */     System.out.println(test);
/*     */     
/* 368 */     System.out.println(ModbusUtil.toHex(test.getBytes()));
/*     */   }
/*     */   
/*     */ 
/* 372 */   private static final int[] ODD_OFFSETS = { -1, -3, -5, -7 };
/* 373 */   private static final int[] STRAIGHT_OFFSETS = { 7, 5, 3, 1 };
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\util\BitVector.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */