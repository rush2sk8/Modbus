/*     */ package com.ghgande.j2mod.modbus.util;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.io.BytesOutputStream;
/*     */ import com.ghgande.j2mod.modbus.msg.ModbusMessage;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ModbusUtil
/*     */ {
/*  54 */   private static BytesOutputStream m_ByteOut = new BytesOutputStream(256);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String toHex(ModbusMessage msg)
/*     */   {
/*  64 */     String ret = "-1";
/*     */     try {
/*  66 */       synchronized (m_ByteOut) {
/*  67 */         msg.writeTo(m_ByteOut);
/*  68 */         ret = toHex(m_ByteOut.getBuffer(), 0, m_ByteOut.size());
/*  69 */         m_ByteOut.reset();
/*     */       }
/*     */     }
/*     */     catch (IOException localIOException) {}
/*  73 */     return ret;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String toHex(byte[] data)
/*     */   {
/*  83 */     return toHex(data, 0, data.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final String toHex(byte[] data, int off, int length)
/*     */   {
/* 102 */     StringBuffer buf = new StringBuffer(data.length * 2);
/* 103 */     for (int i = off; i < length; i++)
/*     */     {
/* 105 */       if ((data[i] & 0xFF) < 16) {
/* 106 */         buf.append("0");
/*     */       }
/* 108 */       buf.append(Long.toString(data[i] & 0xFF, 16));
/* 109 */       if (i < data.length - 1) {
/* 110 */         buf.append(" ");
/*     */       }
/*     */     }
/* 113 */     return buf.toString();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] toHex(int i)
/*     */   {
/* 125 */     StringBuffer buf = new StringBuffer(2);
/*     */     
/* 127 */     if ((i & 0xFF) < 16) {
/* 128 */       buf.append("0");
/*     */     }
/* 130 */     buf.append(Long.toString(i & 0xFF, 16).toUpperCase());
/* 131 */     return buf.toString().getBytes();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int registerToUnsignedShort(byte[] bytes)
/*     */   {
/* 148 */     return (bytes[0] & 0xFF) << 8 | bytes[1] & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] unsignedShortToRegister(int v)
/*     */   {
/* 170 */     byte[] register = new byte[2];
/* 171 */     register[0] = ((byte)(0xFF & v >> 8));
/* 172 */     register[1] = ((byte)(0xFF & v));
/* 173 */     return register;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final short registerToShort(byte[] bytes)
/*     */   {
/* 192 */     return (short)(bytes[0] << 8 | bytes[1] & 0xFF);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final short registerToShort(byte[] bytes, int idx)
/*     */   {
/* 213 */     return (short)(bytes[idx] << 8 | bytes[(idx + 1)] & 0xFF);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] shortToRegister(short s)
/*     */   {
/* 231 */     byte[] register = new byte[2];
/* 232 */     register[0] = ((byte)(0xFF & s >> 8));
/* 233 */     register[1] = ((byte)(0xFF & s));
/* 234 */     return register;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int registersToInt(byte[] bytes)
/*     */   {
/* 250 */     return 
/* 251 */       (bytes[0] & 0xFF) << 24 | 
/* 252 */       (bytes[1] & 0xFF) << 16 | 
/* 253 */       (bytes[2] & 0xFF) << 8 | 
/* 254 */       bytes[3] & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] intToRegisters(int v)
/*     */   {
/* 265 */     byte[] registers = new byte[4];
/* 266 */     registers[0] = ((byte)(0xFF & v >> 24));
/* 267 */     registers[1] = ((byte)(0xFF & v >> 16));
/* 268 */     registers[2] = ((byte)(0xFF & v >> 8));
/* 269 */     registers[3] = ((byte)(0xFF & v));
/* 270 */     return registers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final long registersToLong(byte[] bytes)
/*     */   {
/* 281 */     return 
/* 282 */       (bytes[0] & 0xFF) << 56 | 
/* 283 */       (bytes[1] & 0xFF) << 48 | 
/* 284 */       (bytes[2] & 0xFF) << 40 | 
/* 285 */       (bytes[3] & 0xFF) << 32 | 
/* 286 */       (bytes[4] & 0xFF) << 24 | 
/* 287 */       (bytes[5] & 0xFF) << 16 | 
/* 288 */       (bytes[6] & 0xFF) << 8 | 
/* 289 */       bytes[7] & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] longToRegisters(long v)
/*     */   {
/* 300 */     byte[] registers = new byte[8];
/* 301 */     registers[0] = ((byte)(int)(0xFF & v >> 56));
/* 302 */     registers[1] = ((byte)(int)(0xFF & v >> 48));
/* 303 */     registers[2] = ((byte)(int)(0xFF & v >> 40));
/* 304 */     registers[3] = ((byte)(int)(0xFF & v >> 32));
/* 305 */     registers[4] = ((byte)(int)(0xFF & v >> 24));
/* 306 */     registers[5] = ((byte)(int)(0xFF & v >> 16));
/* 307 */     registers[6] = ((byte)(int)(0xFF & v >> 8));
/* 308 */     registers[7] = ((byte)(int)(0xFF & v));
/* 309 */     return registers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final float registersToFloat(byte[] bytes)
/*     */   {
/* 319 */     return Float.intBitsToFloat(
/* 320 */       (bytes[0] & 0xFF) << 24 | 
/* 321 */       (bytes[1] & 0xFF) << 16 | 
/* 322 */       (bytes[2] & 0xFF) << 8 | 
/* 323 */       bytes[3] & 0xFF);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] floatToRegisters(float f)
/*     */   {
/* 334 */     return intToRegisters(Float.floatToIntBits(f));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final double registersToDouble(byte[] bytes)
/*     */   {
/* 344 */     return Double.longBitsToDouble(
/* 345 */       (bytes[0] & 0xFF) << 56 | 
/* 346 */       (bytes[1] & 0xFF) << 48 | 
/* 347 */       (bytes[2] & 0xFF) << 40 | 
/* 348 */       (bytes[3] & 0xFF) << 32 | 
/* 349 */       (bytes[4] & 0xFF) << 24 | 
/* 350 */       (bytes[5] & 0xFF) << 16 | 
/* 351 */       (bytes[6] & 0xFF) << 8 | 
/* 352 */       bytes[7] & 0xFF);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte[] doubleToRegisters(double d)
/*     */   {
/* 363 */     return longToRegisters(Double.doubleToLongBits(d));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int unsignedByteToInt(byte b)
/*     */   {
/* 373 */     return b & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte lowByte(int wd)
/*     */   {
/* 421 */     return new Integer(0xFF & wd).byteValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final byte hiByte(int wd)
/*     */   {
/* 431 */     return new Integer(0xFF & wd >> 8).byteValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static final int makeWord(int hibyte, int lowbyte)
/*     */   {
/* 442 */     int hi = 0xFF & hibyte;
/* 443 */     int low = 0xFF & lowbyte;
/* 444 */     return hi << 8 | low;
/*     */   }
/*     */   
/*     */   public static final int[] calculateCRC(byte[] data, int offset, int len)
/*     */   {
/* 449 */     int[] crc = { 255, 255 };
/* 450 */     int nextByte = 0;
/*     */     
/*     */ 
/* 453 */     for (int i = offset; (i < len) && (i < data.length); i++) {
/* 454 */       nextByte = 0xFF & data[i];
/* 455 */       int uIndex = crc[0] ^ nextByte;
/* 456 */       crc[0] = (crc[1] ^ auchCRCHi[uIndex]);
/* 457 */       crc[1] = auchCRCLo[uIndex];
/*     */     }
/*     */     
/* 460 */     return crc;
/*     */   }
/*     */   
/*     */ 
/* 464 */   private static final short[] auchCRCHi = {
/* 465 */     0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 
/* 466 */     128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 
/* 467 */     0, 193, 129, 64, 0, 193, 129, 64, 1, 192, 
/* 468 */     128, 65, 1, 192, 128, 65, 0, 193, 129, 64, 
/* 469 */     0, 193, 129, 64, 1, 192, 128, 65, 0, 193, 
/* 470 */     129, 64, 1, 192, 128, 65, 1, 192, 128, 65, 
/* 471 */     0, 193, 129, 64, 1, 192, 128, 65, 0, 193, 
/* 472 */     129, 64, 0, 193, 129, 64, 1, 192, 128, 65, 
/* 473 */     0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 
/* 474 */     128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 
/* 475 */     1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 
/* 476 */     129, 64, 1, 192, 128, 65, 0, 193, 129, 64, 
/* 477 */     0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 
/* 478 */     128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 
/* 479 */     1, 192, 128, 65, 0, 193, 129, 64, 1, 192, 
/* 480 */     128, 65, 1, 192, 128, 65, 0, 193, 129, 64, 
/* 481 */     0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 
/* 482 */     128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 
/* 483 */     0, 193, 129, 64, 0, 193, 129, 64, 1, 192, 
/* 484 */     128, 65, 0, 193, 129, 64, 1, 192, 128, 65, 
/* 485 */     1, 192, 128, 65, 0, 193, 129, 64, 1, 192, 
/* 486 */     128, 65, 0, 193, 129, 64, 0, 193, 129, 64, 
/* 487 */     1, 192, 128, 65, 1, 192, 128, 65, 0, 193, 
/* 488 */     129, 64, 0, 193, 129, 64, 1, 192, 128, 65, 
/* 489 */     0, 193, 129, 64, 1, 192, 128, 65, 1, 192, 
/* 490 */     128, 65, 0, 193, 129, 64 };
/*     */   
/*     */ 
/*     */ 
/* 494 */   private static final short[] auchCRCLo = {
/* 495 */     0, 192, 193, 1, 195, 3, 2, 194, 198, 6, 
/* 496 */     7, 199, 5, 197, 196, 4, 204, 12, 13, 205, 
/* 497 */     15, 207, 206, 14, 10, 202, 203, 11, 201, 9, 
/* 498 */     8, 200, 216, 24, 25, 217, 27, 219, 218, 26, 
/* 499 */     30, 222, 223, 31, 221, 29, 28, 220, 20, 212, 
/* 500 */     213, 21, 215, 23, 22, 214, 210, 18, 19, 211, 
/* 501 */     17, 209, 208, 16, 240, 48, 49, 241, 51, 243, 
/* 502 */     242, 50, 54, 246, 247, 55, 245, 53, 52, 244, 
/* 503 */     60, 252, 253, 61, 255, 63, 62, 254, 250, 58, 
/* 504 */     59, 251, 57, 249, 248, 56, 40, 232, 233, 41, 
/* 505 */     235, 43, 42, 234, 238, 46, 47, 239, 45, 237, 
/* 506 */     236, 44, 228, 36, 37, 229, 39, 231, 230, 38, 
/* 507 */     34, 226, 227, 35, 225, 33, 32, 224, 160, 96, 
/* 508 */     97, 161, 99, 163, 162, 98, 102, 166, 167, 103, 
/* 509 */     165, 101, 100, 164, 108, 172, 173, 109, 175, 111, 
/* 510 */     110, 174, 170, 106, 107, 171, 105, 169, 168, 104, 
/* 511 */     120, 184, 185, 121, 187, 123, 122, 186, 190, 126, 
/* 512 */     127, 191, 125, 189, 188, 124, 180, 116, 117, 181, 
/* 513 */     119, 183, 182, 118, 114, 178, 179, 115, 177, 113, 
/* 514 */     112, 176, 80, 144, 145, 81, 147, 83, 82, 146, 
/* 515 */     150, 86, 87, 151, 85, 149, 148, 84, 156, 92, 
/* 516 */     93, 157, 95, 159, 158, 94, 90, 154, 155, 91, 
/* 517 */     153, 89, 88, 152, 136, 72, 73, 137, 75, 139, 
/* 518 */     138, 74, 78, 142, 143, 79, 141, 77, 76, 140, 
/* 519 */     68, 132, 133, 69, 135, 71, 70, 134, 130, 66, 
/* 520 */     67, 131, 65, 129, 128, 64 };
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\util\ModbusUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */