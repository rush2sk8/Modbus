/*     */ package com.ghgande.j2mod.modbus.util;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Observable
/*     */ {
/*     */   private Vector<Observer> m_Observers;
/*     */   
/*     */   public Observable()
/*     */   {
/*  53 */     this.m_Observers = new Vector(10);
/*     */   }
/*     */   
/*     */   /* Error */
/*     */   public int getObserverCount()
/*     */   {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield 19	com/ghgande/j2mod/modbus/util/Observable:m_Observers	Ljava/util/Vector;
/*     */     //   4: dup
/*     */     //   5: astore_1
/*     */     //   6: monitorenter
/*     */     //   7: aload_0
/*     */     //   8: getfield 19	com/ghgande/j2mod/modbus/util/Observable:m_Observers	Ljava/util/Vector;
/*     */     //   11: invokevirtual 27	java/util/Vector:size	()I
/*     */     //   14: aload_1
/*     */     //   15: monitorexit
/*     */     //   16: ireturn
/*     */     //   17: aload_1
/*     */     //   18: monitorexit
/*     */     //   19: athrow
/*     */     // Line number table:
/*     */     //   Java source line #57	-> byte code offset #0
/*     */     //   Java source line #58	-> byte code offset #7
/*     */     //   Java source line #57	-> byte code offset #17
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	signature
/*     */     //   0	20	0	this	Observable
/*     */     //   5	13	1	Ljava/lang/Object;	Object
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   7	16	17	finally
/*     */     //   17	19	17	finally
/*     */   }
/*     */   
/*     */   public void addObserver(Observer o)
/*     */   {
/*  70 */     synchronized (this.m_Observers) {
/*  71 */       if (!this.m_Observers.contains(o)) {
/*  72 */         this.m_Observers.addElement(o);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeObserver(Observer o)
/*     */   {
/*  86 */     synchronized (this.m_Observers) {
/*  87 */       this.m_Observers.removeElement(o);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void removeObservers()
/*     */   {
/*  96 */     synchronized (this.m_Observers) {
/*  97 */       this.m_Observers.removeAllElements();
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void notifyObservers(Object arg)
/*     */   {
/* 109 */     synchronized (this.m_Observers) {
/* 110 */       for (int i = 0; i < this.m_Observers.size(); i++) {
/* 111 */         ((Observer)this.m_Observers.elementAt(i)).update(this, arg);
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\util\Observable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */