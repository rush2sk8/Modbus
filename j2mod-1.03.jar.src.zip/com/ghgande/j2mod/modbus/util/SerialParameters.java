/*     */ package com.ghgande.j2mod.modbus.util;
/*     */ 
/*     */ import java.util.Properties;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SerialParameters
/*     */ {
/*     */   private String m_PortName;
/*     */   private int m_BaudRate;
/*     */   private int m_FlowControlIn;
/*     */   private int m_FlowControlOut;
/*     */   private int m_Databits;
/*     */   private int m_Stopbits;
/*     */   private int m_Parity;
/*     */   private String m_Encoding;
/*     */   private boolean m_Echo;
/*     */   
/*     */   public SerialParameters()
/*     */   {
/*  68 */     this.m_PortName = "";
/*  69 */     this.m_BaudRate = 9600;
/*  70 */     this.m_FlowControlIn = 0;
/*  71 */     this.m_FlowControlOut = 0;
/*  72 */     this.m_Databits = 8;
/*  73 */     this.m_Stopbits = 1;
/*  74 */     this.m_Parity = 0;
/*  75 */     this.m_Encoding = "ascii";
/*  76 */     this.m_Echo = false;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SerialParameters(String portName, int baudRate, int flowControlIn, int flowControlOut, int databits, int stopbits, int parity, boolean echo)
/*     */   {
/* 100 */     this.m_PortName = portName;
/* 101 */     this.m_BaudRate = baudRate;
/* 102 */     this.m_FlowControlIn = flowControlIn;
/* 103 */     this.m_FlowControlOut = flowControlOut;
/* 104 */     this.m_Databits = databits;
/* 105 */     this.m_Stopbits = stopbits;
/* 106 */     this.m_Parity = parity;
/* 107 */     this.m_Echo = echo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public SerialParameters(Properties props, String prefix)
/*     */   {
/* 119 */     if (prefix == null) {
/* 120 */       prefix = "";
/*     */     }
/* 122 */     setPortName(props.getProperty(prefix + "portName", ""));
/* 123 */     setBaudRate(props.getProperty(prefix + "baudRate", "9600"));
/* 124 */     setFlowControlIn(props.getProperty(prefix + "flowControlIn", "0"));
/* 125 */     setFlowControlOut(props.getProperty(prefix + "flowControlOut", "0"));
/* 126 */     setParity(props.getProperty(prefix + "parity", "0"));
/* 127 */     setDatabits(props.getProperty(prefix + "databits", "8"));
/* 128 */     setStopbits(props.getProperty(prefix + "stopbits", "1"));
/* 129 */     setEncoding(props.getProperty(prefix + "encoding", "ascii"));
/* 130 */     setEcho("true".equals(props.getProperty(prefix + "echo")));
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setPortName(String name)
/*     */   {
/* 140 */     this.m_PortName = name;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getPortName()
/*     */   {
/* 149 */     return this.m_PortName;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBaudRate(int rate)
/*     */   {
/* 158 */     this.m_BaudRate = rate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBaudRate(String rate)
/*     */   {
/* 167 */     this.m_BaudRate = Integer.parseInt(rate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBaudRate()
/*     */   {
/* 176 */     return this.m_BaudRate;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getBaudRateString()
/*     */   {
/* 185 */     return Integer.toString(this.m_BaudRate);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlowControlIn(int flowcontrol)
/*     */   {
/* 195 */     this.m_FlowControlIn = flowcontrol;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlowControlIn(String flowcontrol)
/*     */   {
/* 205 */     this.m_FlowControlIn = stringToFlow(flowcontrol);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFlowControlIn()
/*     */   {
/* 214 */     return this.m_FlowControlIn;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFlowControlInString()
/*     */   {
/* 223 */     return flowToString(this.m_FlowControlIn);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlowControlOut(int flowControlOut)
/*     */   {
/* 233 */     this.m_FlowControlOut = flowControlOut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFlowControlOut(String flowControlOut)
/*     */   {
/* 243 */     this.m_FlowControlOut = stringToFlow(flowControlOut);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFlowControlOut()
/*     */   {
/* 252 */     return this.m_FlowControlOut;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getFlowControlOutString()
/*     */   {
/* 261 */     return flowToString(this.m_FlowControlOut);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDatabits(int databits)
/*     */   {
/* 270 */     this.m_Databits = databits;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDatabits(String databits)
/*     */   {
/* 279 */     if (databits.equals("5")) {
/* 280 */       this.m_Databits = 5;
/*     */     }
/* 282 */     if (databits.equals("6")) {
/* 283 */       this.m_Databits = 6;
/*     */     }
/* 285 */     if (databits.equals("7")) {
/* 286 */       this.m_Databits = 7;
/*     */     }
/* 288 */     if (databits.equals("8")) {
/* 289 */       this.m_Databits = 8;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getDatabits()
/*     */   {
/* 299 */     return this.m_Databits;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getDatabitsString()
/*     */   {
/* 308 */     switch (this.m_Databits) {
/*     */     case 5: 
/* 310 */       return "5";
/*     */     case 6: 
/* 312 */       return "6";
/*     */     case 7: 
/* 314 */       return "7";
/*     */     case 8: 
/* 316 */       return "8";
/*     */     }
/* 318 */     return "8";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStopbits(int stopbits)
/*     */   {
/* 328 */     this.m_Stopbits = stopbits;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStopbits(String stopbits)
/*     */   {
/* 337 */     if (stopbits.equals("1")) {
/* 338 */       this.m_Stopbits = 1;
/*     */     }
/* 340 */     if (stopbits.equals("1.5")) {
/* 341 */       this.m_Stopbits = 3;
/*     */     }
/* 343 */     if (stopbits.equals("2")) {
/* 344 */       this.m_Stopbits = 2;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStopbits()
/*     */   {
/* 354 */     return this.m_Stopbits;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getStopbitsString()
/*     */   {
/* 363 */     switch (this.m_Stopbits) {
/*     */     case 1: 
/* 365 */       return "1";
/*     */     case 3: 
/* 367 */       return "1.5";
/*     */     case 2: 
/* 369 */       return "2";
/*     */     }
/* 371 */     return "1";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParity(int parity)
/*     */   {
/* 381 */     this.m_Parity = parity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setParity(String parity)
/*     */   {
/* 391 */     parity = parity.toLowerCase();
/* 392 */     if (parity.equals("none")) {
/* 393 */       this.m_Parity = 0;
/*     */     }
/* 395 */     if (parity.equals("even")) {
/* 396 */       this.m_Parity = 2;
/*     */     }
/* 398 */     if (parity.equals("odd")) {
/* 399 */       this.m_Parity = 1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getParity()
/*     */   {
/* 409 */     return this.m_Parity;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getParityString()
/*     */   {
/* 418 */     switch (this.m_Parity) {
/*     */     case 0: 
/* 420 */       return "none";
/*     */     case 2: 
/* 422 */       return "even";
/*     */     case 1: 
/* 424 */       return "odd";
/*     */     }
/* 426 */     return "none";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEncoding(String enc)
/*     */   {
/* 439 */     enc = enc.toLowerCase();
/* 440 */     if ((enc.equals("ascii")) || 
/* 441 */       (enc.equals("rtu")) || 
/* 442 */       (enc.equals("bin")))
/*     */     {
/* 444 */       this.m_Encoding = enc;
/*     */     } else {
/* 446 */       this.m_Encoding = "ascii";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getEncoding()
/*     */   {
/* 459 */     return this.m_Encoding;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isEcho()
/*     */   {
/* 468 */     return this.m_Echo;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setEcho(boolean newEcho)
/*     */   {
/* 477 */     this.m_Echo = newEcho;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int stringToFlow(String flowcontrol)
/*     */   {
/* 488 */     flowcontrol = flowcontrol.toLowerCase();
/* 489 */     if (flowcontrol.equals("none")) {
/* 490 */       return 0;
/*     */     }
/* 492 */     if (flowcontrol.equals("xon/xoff out")) {
/* 493 */       return 8;
/*     */     }
/* 495 */     if (flowcontrol.equals("xon/xoff in")) {
/* 496 */       return 4;
/*     */     }
/* 498 */     if (flowcontrol.equals("rts/cts in")) {
/* 499 */       return 1;
/*     */     }
/* 501 */     if (flowcontrol.equals("rts/cts out")) {
/* 502 */       return 2;
/*     */     }
/* 504 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private String flowToString(int flowcontrol)
/*     */   {
/* 516 */     switch (flowcontrol) {
/*     */     case 0: 
/* 518 */       return "none";
/*     */     case 8: 
/* 520 */       return "xon/xoff out";
/*     */     case 4: 
/* 522 */       return "xon/xoff in";
/*     */     case 1: 
/* 524 */       return "rts/cts in";
/*     */     case 2: 
/* 526 */       return "rts/cts out";
/*     */     }
/* 528 */     return "none";
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\util\SerialParameters.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */