/*     */ package com.ghgande.j2mod.modbus.util;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LinkedQueue
/*     */ {
/*     */   protected LinkedNode m_Head;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  52 */   protected final Object m_PutLock = new Object();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected LinkedNode m_Tail;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  66 */   protected int m_WaitingForTake = 0;
/*     */   
/*     */   public LinkedQueue() {
/*  69 */     this.m_Head = new LinkedNode(null);
/*  70 */     this.m_Tail = this.m_Head;
/*     */   }
/*     */   
/*     */   protected void insert(Object x)
/*     */   {
/*  75 */     synchronized (this.m_PutLock) {
/*  76 */       LinkedNode p = new LinkedNode(x);
/*  77 */       synchronized (this.m_Tail) {
/*  78 */         this.m_Tail.m_NextNode = p;
/*  79 */         this.m_Tail = p;
/*     */       }
/*  81 */       if (this.m_WaitingForTake > 0) {
/*  82 */         this.m_PutLock.notify();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   protected synchronized Object extract() {
/*  88 */     synchronized (this.m_Head) {
/*  89 */       Object x = null;
/*  90 */       LinkedNode first = this.m_Head.m_NextNode;
/*  91 */       if (first != null) {
/*  92 */         x = first.m_Node;
/*  93 */         first.m_Node = null;
/*  94 */         this.m_Head = first;
/*     */       }
/*  96 */       return x;
/*     */     }
/*     */   }
/*     */   
/*     */   public void put(Object x) throws InterruptedException
/*     */   {
/* 102 */     if (x == null) { throw new IllegalArgumentException();
/*     */     }
/* 104 */     if (Thread.interrupted()) throw new InterruptedException();
/* 105 */     insert(x);
/*     */   }
/*     */   
/*     */   public boolean offer(Object x, long msecs) throws InterruptedException {
/* 109 */     if (x == null) {
/* 110 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*     */ 
/* 114 */     if (Thread.interrupted()) {
/* 115 */       throw new InterruptedException();
/*     */     }
/*     */     
/* 118 */     insert(x);
/* 119 */     return true;
/*     */   }
/*     */   
/*     */   public Object take() throws InterruptedException
/*     */   {
/* 124 */     if (Thread.interrupted()) { throw new InterruptedException();
/*     */     }
/* 126 */     Object x = extract();
/* 127 */     if (x != null) {
/* 128 */       return x;
/*     */     }
/* 130 */     synchronized (this.m_PutLock) {
/*     */       try {
/* 132 */         this.m_WaitingForTake += 1;
/*     */         for (;;) {
/* 134 */           x = extract();
/* 135 */           if (x != null) {
/* 136 */             this.m_WaitingForTake -= 1;
/* 137 */             return x;
/*     */           }
/* 139 */           this.m_PutLock.wait();
/*     */         }
/*     */       }
/*     */       catch (InterruptedException ex) {
/* 143 */         this.m_WaitingForTake -= 1;
/* 144 */         this.m_PutLock.notify();
/* 145 */         throw ex;
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public Object peek()
/*     */   {
/* 152 */     synchronized (this.m_Head) {
/* 153 */       LinkedNode first = this.m_Head.m_NextNode;
/* 154 */       if (first != null) {
/* 155 */         return first.m_Node;
/*     */       }
/* 157 */       return null;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 164 */     synchronized (this.m_Head) {
/* 165 */       return this.m_Head.m_NextNode == null;
/*     */     }
/*     */   }
/*     */   
/*     */   public Object poll(long msecs) throws InterruptedException
/*     */   {
/* 171 */     if (Thread.interrupted()) throw new InterruptedException();
/* 172 */     Object x = extract();
/* 173 */     if (x != null) {
/* 174 */       return x;
/*     */     }
/* 176 */     synchronized (this.m_PutLock) {
/*     */       try {
/* 178 */         long waitTime = msecs;
/* 179 */         long start = msecs <= 0L ? 0L : System.currentTimeMillis();
/* 180 */         this.m_WaitingForTake += 1;
/*     */         for (;;) {
/* 182 */           x = extract();
/* 183 */           if ((x != null) || (waitTime <= 0L)) {
/* 184 */             this.m_WaitingForTake -= 1;
/* 185 */             return x;
/*     */           }
/* 187 */           this.m_PutLock.wait(waitTime);
/* 188 */           waitTime = msecs - (System.currentTimeMillis() - start);
/*     */         }
/*     */       }
/*     */       catch (InterruptedException ex) {
/* 192 */         this.m_WaitingForTake -= 1;
/* 193 */         this.m_PutLock.notify();
/* 194 */         throw ex;
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\util\LinkedQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */