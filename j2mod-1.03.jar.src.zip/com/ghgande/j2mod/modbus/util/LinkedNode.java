/*    */ package com.ghgande.j2mod.modbus.util;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class LinkedNode
/*    */ {
/*    */   protected Object m_Node;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 50 */   protected LinkedNode m_NextNode = null;
/*    */   
/*    */   public LinkedNode(Object node) {
/* 53 */     this.m_Node = node;
/*    */   }
/*    */   
/*    */   public LinkedNode(Object node, LinkedNode linkednode) {
/* 57 */     this.m_Node = node;
/* 58 */     this.m_NextNode = linkednode;
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\util\LinkedNode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */