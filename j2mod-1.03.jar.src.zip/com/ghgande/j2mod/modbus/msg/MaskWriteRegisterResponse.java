/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MaskWriteRegisterResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_Reference;
/*     */   private int m_AndMask;
/*     */   private int m_OrMask;
/*     */   
/*     */   public MaskWriteRegisterResponse()
/*     */   {
/* 101 */     setFunctionCode(22);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/* 108 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/* 115 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAndMask()
/*     */   {
/* 123 */     return this.m_AndMask;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAndMask(int mask)
/*     */   {
/* 130 */     this.m_AndMask = mask;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOrMask()
/*     */   {
/* 138 */     return this.m_OrMask;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOrMask(int mask)
/*     */   {
/* 145 */     this.m_OrMask = mask;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 153 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 162 */     this.m_Reference = din.readShort();
/* 163 */     this.m_AndMask = din.readShort();
/* 164 */     this.m_OrMask = din.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 171 */     byte[] results = new byte[6];
/*     */     
/* 173 */     results[0] = ((byte)(this.m_Reference >> 8));
/* 174 */     results[1] = ((byte)(this.m_Reference & 0xFF));
/* 175 */     results[2] = ((byte)(this.m_AndMask >> 8));
/* 176 */     results[3] = ((byte)(this.m_AndMask & 0xFF));
/* 177 */     results[4] = ((byte)(this.m_OrMask >> 8));
/* 178 */     results[5] = ((byte)(this.m_OrMask & 0xFF));
/*     */     
/* 180 */     return results;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\MaskWriteRegisterResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */