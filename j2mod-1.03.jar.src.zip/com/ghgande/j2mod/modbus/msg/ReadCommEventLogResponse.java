/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadCommEventLogResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_ByteCount;
/*     */   private int m_Status;
/*     */   private int m_EventCount;
/*     */   private int m_MessageCount;
/*     */   private byte[] m_Events;
/*     */   
/*     */   public int getStatus()
/*     */   {
/*  99 */     return this.m_Status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatus(int status)
/*     */   {
/* 108 */     this.m_Status = status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEventCount()
/*     */   {
/* 115 */     return this.m_EventCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setEventCount(int count)
/*     */   {
/* 122 */     this.m_EventCount = count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getMessageCount()
/*     */   {
/* 129 */     return this.m_MessageCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setMessageCount(int count)
/*     */   {
/* 136 */     this.m_MessageCount = count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEvent(int index)
/*     */   {
/* 143 */     if ((this.m_Events == null) || (index < 0) || (index >= this.m_EventCount)) {
/* 144 */       throw new IndexOutOfBoundsException("index = " + index + 
/* 145 */         ", limit = " + this.m_EventCount);
/*     */     }
/* 147 */     return this.m_Events[index] & 0xFF;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setEvent(int index, int event)
/*     */   {
/* 154 */     if ((this.m_Events == null) || (index < 0) || (index >= this.m_EventCount)) {
/* 155 */       throw new IndexOutOfBoundsException("index = " + index + 
/* 156 */         ", limit = " + this.m_EventCount);
/*     */     }
/* 158 */     this.m_Events[index] = ((byte)event);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 165 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 173 */     this.m_ByteCount = din.readByte();
/* 174 */     this.m_Status = din.readShort();
/* 175 */     this.m_EventCount = din.readShort();
/* 176 */     this.m_MessageCount = din.readShort();
/*     */     
/* 178 */     if (this.m_ByteCount != 6 + this.m_EventCount) {
/* 179 */       throw new IOException("Undetected error reading packet");
/*     */     }
/* 181 */     this.m_Events = new byte[this.m_EventCount];
/*     */     
/* 183 */     din.readFully(this.m_Events, 0, this.m_EventCount);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 190 */     byte[] result = new byte[this.m_EventCount + 7];
/*     */     
/* 192 */     result[0] = ((byte)(this.m_ByteCount = this.m_EventCount + 6));
/* 193 */     result[1] = ((byte)(this.m_Status >> 8));
/* 194 */     result[2] = ((byte)(this.m_Status & 0xFF));
/* 195 */     result[3] = ((byte)(this.m_EventCount >> 8));
/* 196 */     result[4] = ((byte)(this.m_EventCount & 0xFF));
/* 197 */     result[5] = ((byte)(this.m_MessageCount >> 8));
/* 198 */     result[6] = ((byte)(this.m_MessageCount & 0xFF));
/*     */     
/* 200 */     for (int i = 0; i < this.m_EventCount; i++) {
/* 201 */       result[(7 + i)] = this.m_Events[i];
/*     */     }
/* 203 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadCommEventLogResponse()
/*     */   {
/* 212 */     setFunctionCode(12);
/* 213 */     setDataLength(7);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadCommEventLogResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */