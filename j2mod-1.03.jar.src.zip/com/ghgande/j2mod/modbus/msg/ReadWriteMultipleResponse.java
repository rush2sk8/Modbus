/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.procimg.InputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadWriteMultipleResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_ByteCount;
/*     */   private InputRegister[] m_Registers;
/*     */   
/*     */   public int getByteCount()
/*     */   {
/*  63 */     return this.m_ByteCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWordCount()
/*     */   {
/*  74 */     return this.m_ByteCount / 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputRegister getRegister(int index)
/*     */   {
/*  90 */     if (this.m_Registers == null) {
/*  91 */       throw new IndexOutOfBoundsException("No registers defined!");
/*     */     }
/*  93 */     if (index < 0) {
/*  94 */       throw new IndexOutOfBoundsException("Negative index: " + index);
/*     */     }
/*  96 */     if (index >= getWordCount()) {
/*  97 */       throw new IndexOutOfBoundsException(index + " > " + getWordCount());
/*     */     }
/*  99 */     return this.m_Registers[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRegisterValue(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 116 */     return getRegister(index).toUnsignedShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputRegister[] getRegisters()
/*     */   {
/* 125 */     return this.m_Registers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRegisters(InputRegister[] registers)
/*     */   {
/* 132 */     this.m_ByteCount = (registers.length * 2 + 1);
/* 133 */     setDataLength(this.m_ByteCount);
/*     */     
/* 135 */     this.m_Registers = registers;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 139 */     dout.writeByte(this.m_ByteCount);
/*     */     
/* 141 */     for (int k = 0; k < getWordCount(); k++)
/* 142 */       dout.write(this.m_Registers[k].toBytes());
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 146 */     this.m_ByteCount = din.readUnsignedByte();
/*     */     
/* 148 */     this.m_Registers = new Register[getWordCount()];
/*     */     
/* 150 */     for (int k = 0; k < getWordCount(); k++) {
/* 151 */       this.m_Registers[k] = new SimpleRegister(din.readByte(), din.readByte());
/*     */     }
/* 153 */     setDataLength(this.m_ByteCount + 1);
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 157 */     byte[] result = null;
/*     */     
/* 159 */     result = new byte[getWordCount() * 2 + 1];
/*     */     
/* 161 */     int offset = 0;
/* 162 */     result[(offset++)] = ((byte)this.m_ByteCount);
/*     */     
/* 164 */     for (int i = 0; i < this.m_Registers.length; i++) {
/* 165 */       byte[] data = this.m_Registers[i].toBytes();
/*     */       
/* 167 */       result[(offset++)] = data[0];
/* 168 */       result[(offset++)] = data[1];
/*     */     }
/* 170 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadWriteMultipleResponse(InputRegister[] registers)
/*     */   {
/* 182 */     setFunctionCode(23);
/* 183 */     setDataLength(registers.length * 2 + 1);
/*     */     
/* 185 */     this.m_Registers = registers;
/* 186 */     this.m_ByteCount = (registers.length * 2 + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadWriteMultipleResponse(int count)
/*     */   {
/* 198 */     setFunctionCode(23);
/* 199 */     setDataLength(count * 2 + 1);
/*     */     
/* 201 */     this.m_Registers = new InputRegister[count];
/* 202 */     this.m_ByteCount = (count * 2 + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadWriteMultipleResponse()
/*     */   {
/* 211 */     setFunctionCode(23);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadWriteMultipleResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */