/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ModbusRequest
/*     */   extends ModbusMessageImpl
/*     */ {
/*     */   public abstract ModbusResponse getResponse();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract ModbusResponse createResponse();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusResponse createExceptionResponse(int code)
/*     */   {
/* 131 */     ExceptionResponse response = new ExceptionResponse(getFunctionCode(), 
/* 132 */       code);
/* 133 */     if (!isHeadless()) {
/* 134 */       response.setTransactionID(getTransactionID());
/* 135 */       response.setProtocolID(getProtocolID());
/*     */     } else {
/* 137 */       response.setHeadless();
/*     */     }
/* 139 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ModbusRequest createModbusRequest(int functionCode)
/*     */   {
/* 151 */     ModbusRequest request = null;
/*     */     
/* 153 */     switch (functionCode) {
/*     */     case 1: 
/* 155 */       request = new ReadCoilsRequest();
/* 156 */       break;
/*     */     case 2: 
/* 158 */       request = new ReadInputDiscretesRequest();
/* 159 */       break;
/*     */     case 3: 
/* 161 */       request = new ReadMultipleRegistersRequest();
/* 162 */       break;
/*     */     case 4: 
/* 164 */       request = new ReadInputRegistersRequest();
/* 165 */       break;
/*     */     case 5: 
/* 167 */       request = new WriteCoilRequest();
/* 168 */       break;
/*     */     case 6: 
/* 170 */       request = new WriteSingleRegisterRequest();
/* 171 */       break;
/*     */     case 15: 
/* 173 */       request = new WriteMultipleCoilsRequest();
/* 174 */       break;
/*     */     case 16: 
/* 176 */       request = new WriteMultipleRegistersRequest();
/* 177 */       break;
/*     */     case 7: 
/* 179 */       request = new ReadExceptionStatusRequest();
/* 180 */       break;
/*     */     case 8: 
/* 182 */       request = new ReadSerialDiagnosticsRequest();
/* 183 */       break;
/*     */     case 11: 
/* 185 */       request = new ReadCommEventCounterRequest();
/* 186 */       break;
/*     */     case 12: 
/* 188 */       request = new ReadCommEventLogRequest();
/* 189 */       break;
/*     */     case 17: 
/* 191 */       request = new ReportSlaveIDRequest();
/* 192 */       break;
/*     */     case 20: 
/* 194 */       request = new ReadFileRecordRequest();
/* 195 */       break;
/*     */     case 21: 
/* 197 */       request = new WriteFileRecordRequest();
/* 198 */       break;
/*     */     case 22: 
/* 200 */       request = new MaskWriteRegisterRequest();
/* 201 */       break;
/*     */     case 23: 
/* 203 */       request = new ReadWriteMultipleRequest();
/* 204 */       break;
/*     */     case 24: 
/* 206 */       request = new ReadFIFOQueueRequest();
/* 207 */       break;
/*     */     case 43: 
/* 209 */       request = new ReadMEIRequest();
/* 210 */       break;
/*     */     case 9: case 10: case 13: case 14: case 18: case 19: case 25: case 26: case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40: case 41: case 42: default: 
/* 212 */       request = new IllegalFunctionRequest(functionCode);
/*     */     }
/*     */     
/* 215 */     return request;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ModbusRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */