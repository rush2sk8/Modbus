/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadMEIRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_SubCode;
/*     */   private int m_FieldLevel;
/*     */   private int m_FieldId;
/*     */   
/*     */   public ReadMEIRequest()
/*     */   {
/*  97 */     setFunctionCode(43);
/*  98 */     this.m_SubCode = 14;
/*     */     
/*     */ 
/* 101 */     setDataLength(3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadMEIRequest(int level, int id)
/*     */   {
/* 117 */     setFunctionCode(43);
/* 118 */     this.m_SubCode = 14;
/*     */     
/*     */ 
/* 121 */     setDataLength(3);
/* 122 */     setLevel(level);
/* 123 */     setFieldId(id);
/*     */   }
/*     */   
/*     */   public ModbusResponse getResponse() {
/* 127 */     ReadMEIResponse response = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 132 */     if (getSubCode() != 14) {
/* 133 */       IllegalFunctionExceptionResponse error = 
/* 134 */         new IllegalFunctionExceptionResponse();
/*     */       
/* 136 */       error.setUnitID(getUnitID());
/* 137 */       error.setFunctionCode(getFunctionCode());
/*     */       
/* 139 */       return error;
/*     */     }
/*     */     
/* 142 */     response = new ReadMEIResponse();
/*     */     
/*     */ 
/* 145 */     if (!isHeadless()) {
/* 146 */       response.setTransactionID(getTransactionID());
/* 147 */       response.setProtocolID(getProtocolID());
/*     */     } else {
/* 149 */       response.setHeadless();
/*     */     }
/* 151 */     response.setUnitID(getUnitID());
/* 152 */     response.setFunctionCode(43);
/*     */     
/* 154 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusResponse createResponse()
/*     */   {
/* 162 */     throw new RuntimeException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getSubCode()
/*     */   {
/* 169 */     return this.m_SubCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setLevel(int level)
/*     */   {
/* 181 */     this.m_FieldLevel = level;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getLevel()
/*     */   {
/* 193 */     return this.m_FieldLevel;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFieldId(int id)
/*     */   {
/* 205 */     this.m_FieldId = id;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldId()
/*     */   {
/* 216 */     return this.m_FieldId;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 220 */     byte[] results = new byte[3];
/*     */     
/* 222 */     results[0] = ((byte)this.m_SubCode);
/* 223 */     results[1] = ((byte)this.m_FieldLevel);
/* 224 */     results[2] = ((byte)this.m_FieldId);
/*     */     
/* 226 */     dout.write(results);
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 230 */     this.m_SubCode = din.readUnsignedByte();
/*     */     
/* 232 */     if (this.m_SubCode != 14) {
/*     */       try {
/* 234 */         while (din.readByte() >= 0) {}
/*     */       }
/*     */       catch (EOFException localEOFException) {}
/*     */       
/*     */ 
/* 239 */       return;
/*     */     }
/* 241 */     this.m_FieldLevel = din.readUnsignedByte();
/* 242 */     this.m_FieldId = din.readUnsignedByte();
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 246 */     byte[] results = new byte[3];
/*     */     
/* 248 */     results[0] = ((byte)this.m_SubCode);
/* 249 */     results[1] = ((byte)this.m_FieldLevel);
/* 250 */     results[2] = ((byte)this.m_FieldId);
/*     */     
/* 252 */     return results;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadMEIRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */