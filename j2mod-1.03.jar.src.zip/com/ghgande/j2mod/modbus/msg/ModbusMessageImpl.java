/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.util.ModbusUtil;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ModbusMessageImpl
/*     */   implements ModbusMessage
/*     */ {
/*  53 */   private int m_TransactionID = 0;
/*  54 */   private int m_ProtocolID = 0;
/*     */   private int m_DataLength;
/*  56 */   private int m_UnitID = 0;
/*     */   private int m_FunctionCode;
/*  58 */   private boolean m_Headless = false;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean isHeadless()
/*     */   {
/*  69 */     return this.m_Headless;
/*     */   }
/*     */   
/*     */   public void setHeadless() {
/*  73 */     this.m_Headless = true;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setHeadless(boolean b)
/*     */   {
/*  83 */     this.m_Headless = b;
/*     */   }
/*     */   
/*     */   public int getTransactionID() {
/*  87 */     return this.m_TransactionID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setTransactionID(int tid)
/*     */   {
/* 101 */     this.m_TransactionID = tid;
/*     */   }
/*     */   
/*     */   public int getProtocolID() {
/* 105 */     return this.m_ProtocolID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setProtocolID(int pid)
/*     */   {
/* 119 */     this.m_ProtocolID = pid;
/*     */   }
/*     */   
/*     */   public int getDataLength() {
/* 123 */     return this.m_DataLength;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDataLength(int length)
/*     */   {
/* 143 */     if ((length < 0) || (length + 2 > 255)) {
/* 144 */       throw new IllegalArgumentException("Invalid length: " + length);
/*     */     }
/* 146 */     this.m_DataLength = (length + 2);
/*     */   }
/*     */   
/*     */   public int getUnitID() {
/* 150 */     return this.m_UnitID;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setUnitID(int num)
/*     */   {
/* 162 */     this.m_UnitID = num;
/*     */   }
/*     */   
/*     */   public int getFunctionCode() {
/* 166 */     return this.m_FunctionCode;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setFunctionCode(int code)
/*     */   {
/* 181 */     this.m_FunctionCode = code;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void writeTo(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 198 */     if (!isHeadless()) {
/* 199 */       dout.writeShort(getTransactionID());
/* 200 */       dout.writeShort(getProtocolID());
/* 201 */       dout.writeShort(getDataLength());
/*     */     }
/* 203 */     dout.writeByte(getUnitID());
/* 204 */     dout.writeByte(getFunctionCode());
/*     */     
/* 206 */     writeData(dout);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void writeData(DataOutput paramDataOutput)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readFrom(DataInput din)
/*     */     throws IOException
/*     */   {
/* 226 */     if (!isHeadless()) {
/* 227 */       setTransactionID(din.readUnsignedShort());
/* 228 */       setProtocolID(din.readUnsignedShort());
/* 229 */       this.m_DataLength = din.readUnsignedShort();
/*     */     }
/* 231 */     setUnitID(din.readUnsignedByte());
/* 232 */     setFunctionCode(din.readUnsignedByte());
/* 233 */     readData(din);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public abstract void readData(DataInput paramDataInput)
/*     */     throws IOException;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOutputLength()
/*     */   {
/* 247 */     int l = 2 + getDataLength();
/* 248 */     if (!isHeadless()) {
/* 249 */       l += 6;
/*     */     }
/* 251 */     return l;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getHexMessage()
/*     */   {
/* 262 */     return ModbusUtil.toHex(this);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ModbusMessageImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */