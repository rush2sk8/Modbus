/*    */ package com.ghgande.j2mod.modbus.msg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalAddressExceptionResponse
/*    */   extends ExceptionResponse
/*    */ {
/*    */   public void setFunctionCode(int fc)
/*    */   {
/* 19 */     super.setFunctionCode(fc | 0x80);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public IllegalAddressExceptionResponse()
/*    */   {
/* 26 */     super(0, 2);
/*    */   }
/*    */   
/*    */   public IllegalAddressExceptionResponse(int function) {
/* 30 */     super(function, 2);
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\IllegalAddressExceptionResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */