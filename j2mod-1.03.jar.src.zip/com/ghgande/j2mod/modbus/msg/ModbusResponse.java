/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ModbusResponse
/*     */   extends ModbusMessageImpl
/*     */ {
/*     */   protected void setMessage(byte[] msg)
/*     */   {
/*     */     try
/*     */     {
/* 101 */       readData(new DataInputStream(new ByteArrayInputStream(msg)));
/*     */     }
/*     */     catch (IOException localIOException) {}
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public static ModbusResponse createModbusResponse(int functionCode)
/*     */   {
/* 116 */     ModbusResponse response = null;
/*     */     
/* 118 */     switch (functionCode) {
/*     */     case 1: 
/* 120 */       response = new ReadCoilsResponse();
/* 121 */       break;
/*     */     case 2: 
/* 123 */       response = new ReadInputDiscretesResponse();
/* 124 */       break;
/*     */     case 3: 
/* 126 */       response = new ReadMultipleRegistersResponse();
/* 127 */       break;
/*     */     case 4: 
/* 129 */       response = new ReadInputRegistersResponse();
/* 130 */       break;
/*     */     case 5: 
/* 132 */       response = new WriteCoilResponse();
/* 133 */       break;
/*     */     case 6: 
/* 135 */       response = new WriteSingleRegisterResponse();
/* 136 */       break;
/*     */     case 15: 
/* 138 */       response = new WriteMultipleCoilsResponse();
/* 139 */       break;
/*     */     case 16: 
/* 141 */       response = new WriteMultipleRegistersResponse();
/* 142 */       break;
/*     */     case 7: 
/* 144 */       response = new ReadExceptionStatusResponse();
/* 145 */       break;
/*     */     case 8: 
/* 147 */       response = new ReadSerialDiagnosticsResponse();
/* 148 */       break;
/*     */     case 11: 
/* 150 */       response = new ReadCommEventCounterResponse();
/* 151 */       break;
/*     */     case 12: 
/* 153 */       response = new ReadCommEventLogResponse();
/* 154 */       break;
/*     */     case 17: 
/* 156 */       response = new ReportSlaveIDResponse();
/* 157 */       break;
/*     */     case 20: 
/* 159 */       response = new ReadFileRecordResponse();
/* 160 */       break;
/*     */     case 21: 
/* 162 */       response = new WriteFileRecordResponse();
/* 163 */       break;
/*     */     case 22: 
/* 165 */       response = new MaskWriteRegisterResponse();
/* 166 */       break;
/*     */     case 23: 
/* 168 */       response = new ReadWriteMultipleResponse();
/* 169 */       break;
/*     */     case 24: 
/* 171 */       response = new ReadFIFOQueueResponse();
/* 172 */       break;
/*     */     case 43: 
/* 174 */       response = new ReadMEIResponse();
/* 175 */       break;
/*     */     case 9: case 10: case 13: case 14: case 18: case 19: case 25: case 26: case 27: case 28: case 29: case 30: case 31: case 32: case 33: case 34: case 35: case 36: case 37: case 38: case 39: case 40: case 41: case 42: default: 
/* 177 */       if ((functionCode & 0x80) != 0) {
/* 178 */         response = new ExceptionResponse(functionCode);
/*     */       } else {
/* 180 */         response = new ExceptionResponse();
/*     */       }
/*     */       break;
/*     */     }
/* 184 */     return response;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ModbusResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */