/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadFileRecordResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_ByteCount;
/*     */   
/*     */   public class RecordResponse
/*     */   {
/*     */     private int m_WordCount;
/*     */     private byte[] m_Data;
/*     */     
/*     */     public int getWordCount()
/*     */     {
/*  89 */       return this.m_WordCount;
/*     */     }
/*     */     
/*     */     public SimpleRegister getRegister(int register) {
/*  93 */       if ((register < 0) || (register >= this.m_WordCount)) {
/*  94 */         throw new IndexOutOfBoundsException("0 <= " + 
/*  95 */           register + " < " + this.m_WordCount);
/*     */       }
/*  97 */       byte b1 = this.m_Data[(register * 2)];
/*  98 */       byte b2 = this.m_Data[(register * 2 + 1)];
/*     */       
/* 100 */       SimpleRegister result = new SimpleRegister(b1, b2);
/* 101 */       return result;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public int getResponseSize()
/*     */     {
/* 111 */       return 2 + this.m_WordCount * 2;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     public void getResponse(byte[] request, int offset)
/*     */     {
/* 125 */       request[offset] = ((byte)(1 + this.m_WordCount * 2));
/* 126 */       request[(offset + 1)] = 6;
/*     */       
/* 128 */       System.arraycopy(this.m_Data, 0, request, offset + 2, this.m_Data.length);
/*     */     }
/*     */     
/*     */     public byte[] getResponse() {
/* 132 */       byte[] request = new byte[getResponseSize()];
/*     */       
/* 134 */       getResponse(request, 0);
/*     */       
/* 136 */       return request;
/*     */     }
/*     */     
/*     */     public RecordResponse(short[] data) {
/* 140 */       this.m_WordCount = data.length;
/* 141 */       this.m_Data = new byte[this.m_WordCount * 2];
/*     */       
/* 143 */       int offset = 0;
/* 144 */       for (int i = 0; i < this.m_WordCount; i++) {
/* 145 */         this.m_Data[(offset++)] = ((byte)(data[i] >> 8));
/* 146 */         this.m_Data[(offset++)] = ((byte)(data[i] & 0xFF));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/* 152 */   private RecordResponse[] m_Records = null;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getByteCount()
/*     */   {
/* 163 */     if (this.m_Records == null) {
/* 164 */       return 1;
/*     */     }
/* 166 */     int size = 1;
/* 167 */     for (int i = 0; i < this.m_Records.length; i++) {
/* 168 */       size += this.m_Records[i].getResponseSize();
/*     */     }
/* 170 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRecordCount()
/*     */   {
/* 179 */     if (this.m_Records == null) {
/* 180 */       return 0;
/*     */     }
/* 182 */     return this.m_Records.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RecordResponse getRecord(int index)
/*     */   {
/* 189 */     return this.m_Records[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addResponse(RecordResponse response)
/*     */   {
/* 196 */     if (this.m_Records == null) {
/* 197 */       this.m_Records = new RecordResponse[1];
/*     */     } else {
/* 199 */       RecordResponse[] old = this.m_Records;
/* 200 */       this.m_Records = new RecordResponse[old.length + 1];
/*     */       
/* 202 */       System.arraycopy(old, 0, this.m_Records, 0, old.length);
/*     */     }
/* 204 */     this.m_Records[(this.m_Records.length - 1)] = response;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 208 */     dout.writeByte(getByteCount() - 1);
/*     */     
/* 210 */     if (this.m_Records == null) {
/* 211 */       return;
/*     */     }
/* 213 */     for (int i = 0; i < this.m_Records.length; i++)
/* 214 */       dout.write(this.m_Records[i].getResponse());
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 218 */     this.m_ByteCount = din.readUnsignedByte();
/*     */     
/* 220 */     int remainder = this.m_ByteCount;
/* 221 */     while (remainder > 0) {
/* 222 */       int length = din.readByte();
/* 223 */       remainder--;
/*     */       
/* 225 */       int function = din.readByte();
/* 226 */       remainder--;
/*     */       
/* 228 */       if ((function != 6) || (length - 1 > remainder)) {
/* 229 */         throw new IOException("Invalid response format");
/*     */       }
/* 231 */       short[] data = new short[(length - 1) / 2];
/* 232 */       for (int i = 0; i < data.length; i++) {
/* 233 */         data[i] = din.readShort();
/* 234 */         remainder -= 2;
/*     */       }
/* 236 */       RecordResponse response = new RecordResponse(data);
/* 237 */       addResponse(response);
/*     */     }
/* 239 */     setDataLength(this.m_ByteCount + 1);
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 243 */     byte[] result = null;
/*     */     
/* 245 */     result = new byte[getByteCount()];
/*     */     
/* 247 */     int offset = 0;
/* 248 */     result[(offset++)] = ((byte)(result.length - 1));
/*     */     
/* 250 */     for (int i = 0; i < this.m_Records.length; i++) {
/* 251 */       this.m_Records[i].getResponse(result, offset);
/* 252 */       offset += this.m_Records[i].getWordCount() * 2;
/*     */     }
/* 254 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadFileRecordResponse()
/*     */   {
/* 263 */     setFunctionCode(20);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadFileRecordResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */