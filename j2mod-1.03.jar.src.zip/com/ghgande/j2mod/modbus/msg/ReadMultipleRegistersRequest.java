/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadMultipleRegistersRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_Reference;
/*     */   private int m_WordCount;
/*     */   
/*     */   public ReadMultipleRegistersRequest()
/*     */   {
/*  66 */     setFunctionCode(3);
/*  67 */     setDataLength(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadMultipleRegistersRequest(int ref, int count)
/*     */   {
/*  85 */     setFunctionCode(3);
/*  86 */     setDataLength(4);
/*     */     
/*  88 */     setReference(ref);
/*  89 */     setWordCount(count);
/*     */   }
/*     */   
/*     */   public ModbusResponse getResponse() {
/*  93 */     ReadMultipleRegistersResponse response = null;
/*     */     
/*  95 */     response = new ReadMultipleRegistersResponse();
/*     */     
/*  97 */     response.setUnitID(getUnitID());
/*  98 */     response.setHeadless(isHeadless());
/*  99 */     if (!isHeadless()) {
/* 100 */       response.setProtocolID(getProtocolID());
/* 101 */       response.setTransactionID(getTransactionID());
/*     */     }
/* 103 */     return response;
/*     */   }
/*     */   
/*     */   public ModbusResponse createResponse() {
/* 107 */     ReadMultipleRegistersResponse response = null;
/* 108 */     Register[] regs = null;
/*     */     
/*     */ 
/* 111 */     ProcessImage procimg = ModbusCoupler.getReference().getProcessImage();
/*     */     try
/*     */     {
/* 114 */       regs = procimg.getRegisterRange(getReference(), getWordCount());
/*     */     } catch (IllegalAddressException e) {
/* 116 */       return createExceptionResponse(2);
/*     */     }
/* 118 */     response = (ReadMultipleRegistersResponse)getResponse();
/* 119 */     response.setRegisters(regs);
/*     */     
/* 121 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/* 133 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/* 145 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWordCount(int count)
/*     */   {
/* 157 */     this.m_WordCount = count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWordCount()
/*     */   {
/* 168 */     return this.m_WordCount;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 172 */     dout.writeShort(this.m_Reference);
/* 173 */     dout.writeShort(this.m_WordCount);
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 177 */     this.m_Reference = din.readUnsignedShort();
/* 178 */     this.m_WordCount = din.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 182 */     byte[] result = new byte[4];
/*     */     
/* 184 */     result[0] = ((byte)(this.m_Reference >> 8 & 0xFF));
/* 185 */     result[1] = ((byte)(this.m_Reference & 0xFF));
/* 186 */     result[2] = ((byte)(this.m_WordCount >> 8 & 0xFF));
/* 187 */     result[3] = ((byte)(this.m_WordCount & 0xFF));
/*     */     
/* 189 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadMultipleRegistersRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */