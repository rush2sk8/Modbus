/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.io.NonWordDataHandler;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.InputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleInputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadWriteMultipleRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private NonWordDataHandler m_NonWordDataHandler;
/*     */   private int m_ReadReference;
/*     */   private int m_ReadCount;
/*     */   private int m_WriteReference;
/*     */   private int m_WriteCount;
/*     */   private Register[] m_WriteRegisters;
/*     */   
/*     */   public void setReadReference(int ref)
/*     */   {
/* 110 */     this.m_ReadReference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReadReference()
/*     */   {
/* 122 */     return this.m_ReadReference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWriteReference(int ref)
/*     */   {
/* 135 */     this.m_WriteReference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWriteReference()
/*     */   {
/* 147 */     return this.m_WriteReference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRegisters(Register[] registers)
/*     */   {
/* 159 */     this.m_WriteRegisters = registers;
/* 160 */     this.m_WriteCount = (registers != null ? registers.length : 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Register[] getRegisters()
/*     */   {
/* 171 */     return this.m_WriteRegisters;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Register getRegister(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 187 */     if (index < 0) {
/* 188 */       throw new IndexOutOfBoundsException(index + " < 0");
/*     */     }
/* 190 */     if (index >= getWriteWordCount()) {
/* 191 */       throw new IndexOutOfBoundsException(index + " > " + 
/* 192 */         getWriteWordCount());
/*     */     }
/* 194 */     return this.m_WriteRegisters[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReadRegisterValue(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 211 */     return getRegister(index).toUnsignedShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getByteCount()
/*     */   {
/* 220 */     return getWriteWordCount() * 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWriteWordCount()
/*     */   {
/* 229 */     return this.m_WriteCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWriteWordCount(int count)
/*     */   {
/* 239 */     this.m_WriteCount = count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReadWordCount()
/*     */   {
/* 248 */     return this.m_ReadCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReadWordCount(int count)
/*     */   {
/* 258 */     this.m_ReadCount = count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNonWordDataHandler(NonWordDataHandler dhandler)
/*     */   {
/* 270 */     this.m_NonWordDataHandler = dhandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NonWordDataHandler getNonWordDataHandler()
/*     */   {
/* 279 */     return this.m_NonWordDataHandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModbusResponse getResponse()
/*     */   {
/* 286 */     ReadWriteMultipleResponse response = null;
/*     */     
/* 288 */     response = new ReadWriteMultipleResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 293 */     response.setHeadless(isHeadless());
/* 294 */     if (!isHeadless()) {
/* 295 */       response.setTransactionID(getTransactionID());
/* 296 */       response.setProtocolID(getProtocolID());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 302 */     response.setUnitID(getUnitID());
/* 303 */     response.setFunctionCode(getFunctionCode());
/*     */     
/* 305 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusResponse createResponse()
/*     */   {
/* 313 */     ReadWriteMultipleResponse response = null;
/* 314 */     InputRegister[] readRegs = null;
/* 315 */     Register[] writeRegs = null;
/*     */     
/*     */ 
/* 318 */     ProcessImage procimg = ModbusCoupler.getReference().getProcessImage();
/*     */     try
/*     */     {
/* 321 */       readRegs = procimg.getRegisterRange(getReadReference(), 
/* 322 */         getReadWordCount());
/*     */       
/* 324 */       InputRegister[] dummy = new InputRegister[readRegs.length];
/* 325 */       for (int i = 0; i < readRegs.length; i++) {
/* 326 */         dummy[i] = new SimpleInputRegister(readRegs[i].getValue());
/*     */       }
/* 328 */       readRegs = dummy;
/*     */       
/* 330 */       writeRegs = procimg.getRegisterRange(getWriteReference(), 
/* 331 */         getWriteWordCount());
/*     */       
/* 333 */       for (int i = 0; i < writeRegs.length; i++)
/* 334 */         writeRegs[i].setValue(getRegister(i).getValue());
/*     */     } catch (IllegalAddressException e) {
/* 336 */       return createExceptionResponse(2);
/*     */     }
/* 338 */     response = (ReadWriteMultipleResponse)getResponse();
/* 339 */     response.setRegisters(readRegs);
/*     */     
/* 341 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 348 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void readData(DataInput input)
/*     */     throws IOException
/*     */   {
/* 356 */     this.m_ReadReference = input.readShort();
/* 357 */     this.m_ReadCount = input.readShort();
/* 358 */     this.m_WriteReference = input.readShort();
/* 359 */     this.m_WriteCount = input.readUnsignedShort();
/* 360 */     int byteCount = input.readUnsignedByte();
/*     */     
/* 362 */     if (this.m_NonWordDataHandler == null) {
/* 363 */       byte[] buffer = new byte[byteCount];
/* 364 */       input.readFully(buffer, 0, byteCount);
/*     */       
/* 366 */       int offset = 0;
/* 367 */       this.m_WriteRegisters = new Register[this.m_WriteCount];
/*     */       
/* 369 */       for (int register = 0; register < this.m_WriteCount; register++) {
/* 370 */         this.m_WriteRegisters[register] = new SimpleRegister(buffer[offset], 
/* 371 */           buffer[(offset + 1)]);
/* 372 */         offset += 2;
/*     */       }
/*     */     }
/*     */     else {
/* 376 */       this.m_NonWordDataHandler.readData(input, this.m_WriteReference, this.m_WriteCount);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 384 */     byte[] results = new byte[9 + 2 * getWriteWordCount()];
/*     */     
/* 386 */     results[0] = ((byte)(this.m_ReadReference >> 8));
/* 387 */     results[1] = ((byte)(this.m_ReadReference & 0xFF));
/* 388 */     results[2] = ((byte)(this.m_ReadCount >> 8));
/* 389 */     results[3] = ((byte)(this.m_ReadCount & 0xFF));
/* 390 */     results[4] = ((byte)(this.m_WriteReference >> 8));
/* 391 */     results[5] = ((byte)(this.m_WriteReference & 0xFF));
/* 392 */     results[6] = ((byte)(this.m_WriteCount >> 8));
/* 393 */     results[7] = ((byte)(this.m_WriteCount & 0xFF));
/* 394 */     results[8] = ((byte)(this.m_WriteCount * 2));
/*     */     
/* 396 */     int offset = 9;
/* 397 */     for (int i = 0; i < this.m_WriteCount; i++) {
/* 398 */       Register reg = getRegister(i);
/* 399 */       byte[] bytes = reg.toBytes();
/*     */       
/* 401 */       results[(offset++)] = bytes[0];
/* 402 */       results[(offset++)] = bytes[1];
/*     */     }
/* 404 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadWriteMultipleRequest(int unit, int readRef, int readCount, int writeRef, int writeCount)
/*     */   {
/* 414 */     setUnitID(unit);
/* 415 */     setFunctionCode(23);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 420 */     setDataLength(9 + writeCount * 2);
/*     */     
/* 422 */     this.m_ReadReference = readRef;
/* 423 */     this.m_ReadCount = readCount;
/* 424 */     this.m_WriteReference = writeRef;
/* 425 */     this.m_WriteCount = writeCount;
/* 426 */     this.m_WriteRegisters = new Register[writeCount];
/* 427 */     for (int i = 0; i < writeCount; i++) {
/* 428 */       this.m_WriteRegisters[i] = new SimpleRegister(0);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadWriteMultipleRequest(int unit)
/*     */   {
/* 437 */     setUnitID(unit);
/* 438 */     setFunctionCode(23);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 443 */     setDataLength(9);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadWriteMultipleRequest()
/*     */   {
/* 452 */     setFunctionCode(23);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 457 */     setDataLength(9);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadWriteMultipleRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */