/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.procimg.File;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.Record;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadFileRecordRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_ByteCount;
/*     */   private RecordRequest[] m_Records;
/*     */   
/*     */   public class RecordRequest
/*     */   {
/*     */     private int m_FileNumber;
/*     */     private int m_RecordNumber;
/*     */     private int m_WordCount;
/*     */     
/*     */     public int getFileNumber()
/*     */     {
/*  95 */       return this.m_FileNumber;
/*     */     }
/*     */     
/*     */     public int getRecordNumber() {
/*  99 */       return this.m_RecordNumber;
/*     */     }
/*     */     
/*     */     public int getWordCount() {
/* 103 */       return this.m_WordCount;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getRequestSize()
/*     */     {
/* 110 */       return 7 + this.m_WordCount * 2;
/*     */     }
/*     */     
/*     */     public void getRequest(byte[] request, int offset) {
/* 114 */       request[offset] = 6;
/* 115 */       request[(offset + 1)] = ((byte)(this.m_FileNumber >> 8));
/* 116 */       request[(offset + 2)] = ((byte)(this.m_FileNumber & 0xFF));
/* 117 */       request[(offset + 3)] = ((byte)(this.m_RecordNumber >> 8));
/* 118 */       request[(offset + 4)] = ((byte)(this.m_RecordNumber & 0xFF));
/* 119 */       request[(offset + 5)] = ((byte)(this.m_WordCount >> 8));
/* 120 */       request[(offset + 6)] = ((byte)(this.m_WordCount & 0xFF));
/*     */     }
/*     */     
/*     */     public byte[] getRequest() {
/* 124 */       byte[] request = new byte[7];
/*     */       
/* 126 */       getRequest(request, 0);
/*     */       
/* 128 */       return request;
/*     */     }
/*     */     
/*     */     public RecordRequest(int file, int record, int count) {
/* 132 */       this.m_FileNumber = file;
/* 133 */       this.m_RecordNumber = record;
/* 134 */       this.m_WordCount = count;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRequestSize()
/*     */   {
/* 148 */     if (this.m_Records == null) {
/* 149 */       return 1;
/*     */     }
/* 151 */     int size = 1;
/* 152 */     for (int i = 0; i < this.m_Records.length; i++) {
/* 153 */       size += this.m_Records[i].getRequestSize();
/*     */     }
/* 155 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getRequestCount()
/*     */   {
/* 162 */     if (this.m_Records == null) {
/* 163 */       return 0;
/*     */     }
/* 165 */     return this.m_Records.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RecordRequest getRecord(int index)
/*     */   {
/* 172 */     return this.m_Records[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addRequest(RecordRequest request)
/*     */   {
/* 179 */     if (request.getRequestSize() + getRequestSize() > 248) {
/* 180 */       throw new IllegalArgumentException();
/*     */     }
/* 182 */     if (this.m_Records == null) {
/* 183 */       this.m_Records = new RecordRequest[1];
/*     */     } else {
/* 185 */       RecordRequest[] old = this.m_Records;
/* 186 */       this.m_Records = new RecordRequest[old.length + 1];
/*     */       
/* 188 */       System.arraycopy(old, 0, this.m_Records, 0, old.length);
/*     */     }
/* 190 */     this.m_Records[(this.m_Records.length - 1)] = request;
/*     */     
/* 192 */     setDataLength(getRequestSize());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModbusResponse getResponse()
/*     */   {
/* 199 */     ReadFileRecordResponse response = null;
/*     */     
/* 201 */     response = new ReadFileRecordResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 206 */     response.setHeadless(isHeadless());
/* 207 */     if (!isHeadless()) {
/* 208 */       response.setTransactionID(getTransactionID());
/* 209 */       response.setProtocolID(getProtocolID());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 215 */     response.setUnitID(getUnitID());
/* 216 */     response.setFunctionCode(getFunctionCode());
/*     */     
/* 218 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusResponse createResponse()
/*     */   {
/* 226 */     ReadFileRecordResponse response = null;
/* 227 */     response = (ReadFileRecordResponse)getResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 232 */     ProcessImage procimg = ModbusCoupler.getReference().getProcessImage();
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 238 */       for (int i = 0; i < getRequestCount(); i++) {
/* 239 */         RecordRequest recordRequest = getRecord(i);
/* 240 */         if ((recordRequest.getFileNumber() < 0) || 
/*     */         
/* 242 */           (recordRequest.getFileNumber() >= procimg.getFileCount())) {
/* 243 */           return createExceptionResponse(2);
/*     */         }
/* 245 */         File file = procimg.getFileByNumber(recordRequest
/* 246 */           .getFileNumber());
/*     */         
/* 248 */         if ((recordRequest.getRecordNumber() < 0) || 
/*     */         
/* 250 */           (recordRequest.getRecordNumber() >= file.getRecordCount())) {
/* 251 */           return createExceptionResponse(2);
/*     */         }
/* 253 */         Record record = file.getRecord(recordRequest.getRecordNumber());
/* 254 */         int registers = recordRequest.getWordCount();
/* 255 */         if ((record == null) && (registers != 0)) {
/* 256 */           return createExceptionResponse(2);
/*     */         }
/* 258 */         short[] data = new short[registers];
/* 259 */         for (int j = 0; j < registers; j++) {
/* 260 */           Register register = record.getRegister(j);
/* 261 */           if (register == null) {
/* 262 */             return createExceptionResponse(2);
/*     */           }
/* 264 */           data[j] = register.toShort();
/*     */         }
/* 266 */         ReadFileRecordResponse tmp191_190 = response;tmp191_190.getClass();ReadFileRecordResponse.RecordResponse recordResponse = new ReadFileRecordResponse.RecordResponse(tmp191_190, 
/* 267 */           data);
/* 268 */         response.addResponse(recordResponse);
/*     */       }
/*     */     } catch (IllegalAddressException e) {
/* 271 */       return createExceptionResponse(2);
/*     */     }
/* 273 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 280 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 287 */     this.m_ByteCount = din.readUnsignedByte();
/*     */     
/* 289 */     int recordCount = this.m_ByteCount / 7;
/* 290 */     this.m_Records = new RecordRequest[recordCount];
/*     */     
/* 292 */     for (int i = 0; i < recordCount; i++) {
/* 293 */       if (din.readByte() != 6) {
/* 294 */         throw new IOException();
/*     */       }
/* 296 */       int file = din.readUnsignedShort();
/* 297 */       int record = din.readUnsignedShort();
/* 298 */       if ((record < 0) || (record >= 10000)) {
/* 299 */         throw new IOException();
/*     */       }
/* 301 */       int count = din.readUnsignedShort();
/*     */       
/* 303 */       this.m_Records[i] = new RecordRequest(file, record, count);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 311 */     byte[] request = new byte[1 + 7 * this.m_Records.length];
/*     */     
/* 313 */     int offset = 0;
/* 314 */     request[(offset++)] = ((byte)(request.length - 1));
/*     */     
/* 316 */     for (int i = 0; i < this.m_Records.length; i++) {
/* 317 */       this.m_Records[i].getRequest(request, offset);
/* 318 */       offset += 7;
/*     */     }
/* 320 */     return request;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadFileRecordRequest()
/*     */   {
/* 329 */     setFunctionCode(20);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 334 */     setDataLength(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadFileRecordRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */