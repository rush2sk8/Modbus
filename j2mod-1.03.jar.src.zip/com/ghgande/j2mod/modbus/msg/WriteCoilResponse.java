/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WriteCoilResponse
/*     */   extends ModbusResponse
/*     */ {
/*  51 */   private boolean m_Coil = false;
/*     */   
/*     */ 
/*     */   private int m_Reference;
/*     */   
/*     */ 
/*     */ 
/*     */   public WriteCoilResponse()
/*     */   {
/*  60 */     setFunctionCode(5);
/*  61 */     setDataLength(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriteCoilResponse(int reference, boolean b)
/*     */   {
/*  75 */     setFunctionCode(5);
/*  76 */     setDataLength(4);
/*     */     
/*  78 */     setReference(reference);
/*  79 */     setCoil(b);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCoil(boolean b)
/*     */   {
/*  89 */     this.m_Coil = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getCoil()
/*     */   {
/*  98 */     return this.m_Coil;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/* 109 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/* 121 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 125 */     byte[] data = getMessage();
/* 126 */     if (data == null) {
/* 127 */       return;
/*     */     }
/* 129 */     dout.write(data);
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 133 */     byte[] data = new byte[4];
/* 134 */     din.readFully(data);
/*     */     
/* 136 */     setReference(data[0] << 8 | data[1] & 0xFF);
/* 137 */     setCoil(data[2] == -1);
/*     */     
/* 139 */     setDataLength(4);
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 143 */     byte[] result = new byte[4];
/*     */     
/* 145 */     result[0] = ((byte)(this.m_Reference >> 8 & 0xFF));
/* 146 */     result[1] = ((byte)(this.m_Reference & 0xFF));
/* 147 */     if (this.m_Coil) {
/* 148 */       result[2] = com.ghgande.j2mod.modbus.Modbus.COIL_ON_BYTES[0];
/* 149 */       result[3] = com.ghgande.j2mod.modbus.Modbus.COIL_ON_BYTES[1];
/*     */     } else {
/* 151 */       result[2] = com.ghgande.j2mod.modbus.Modbus.COIL_OFF_BYTES[0];
/* 152 */       result[3] = com.ghgande.j2mod.modbus.Modbus.COIL_OFF_BYTES[1];
/*     */     }
/* 154 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\WriteCoilResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */