/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ExceptionResponse
/*     */   extends ModbusResponse
/*     */ {
/*  53 */   private int m_ExceptionCode = -1;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getExceptionCode()
/*     */   {
/*  62 */     return this.m_ExceptionCode;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/*  66 */     dout.writeByte(getExceptionCode());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/*  75 */     this.m_ExceptionCode = din.readUnsignedByte();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/*  86 */     byte[] result = new byte[1];
/*  87 */     result[0] = ((byte)getExceptionCode());
/*  88 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExceptionResponse(int fc, int exc)
/*     */   {
/* 106 */     setDataLength(1);
/* 107 */     setFunctionCode(fc | 0x80);
/*     */     
/* 109 */     this.m_ExceptionCode = exc;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExceptionResponse(int fc)
/*     */   {
/* 124 */     setDataLength(1);
/* 125 */     setFunctionCode(fc | 0x80);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ExceptionResponse()
/*     */   {
/* 137 */     setDataLength(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ExceptionResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */