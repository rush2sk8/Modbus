/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.InputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadInputRegistersRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_Reference;
/*     */   private int m_WordCount;
/*     */   
/*     */   public ReadInputRegistersRequest()
/*     */   {
/*  66 */     setFunctionCode(4);
/*     */     
/*  68 */     setDataLength(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadInputRegistersRequest(int ref, int count)
/*     */   {
/*  84 */     setFunctionCode(4);
/*     */     
/*  86 */     setDataLength(4);
/*     */     
/*  88 */     setReference(ref);
/*  89 */     setWordCount(count);
/*     */   }
/*     */   
/*     */   public ReadInputRegistersResponse getResponse() {
/*  93 */     ReadInputRegistersResponse response = 
/*  94 */       new ReadInputRegistersResponse();
/*     */     
/*  96 */     response.setUnitID(getUnitID());
/*  97 */     response.setHeadless(isHeadless());
/*  98 */     response.setWordCount(getWordCount());
/*     */     
/* 100 */     if (!isHeadless()) {
/* 101 */       response.setProtocolID(getProtocolID());
/* 102 */       response.setTransactionID(getTransactionID());
/*     */     }
/* 104 */     return response;
/*     */   }
/*     */   
/*     */   public ModbusResponse createResponse() {
/* 108 */     ReadInputRegistersResponse response = null;
/* 109 */     InputRegister[] inpregs = null;
/*     */     
/*     */ 
/* 112 */     ProcessImage procimg = ModbusCoupler.getReference().getProcessImage();
/*     */     try
/*     */     {
/* 115 */       inpregs = procimg.getInputRegisterRange(getReference(), 
/* 116 */         getWordCount());
/*     */     } catch (IllegalAddressException iaex) {
/* 118 */       return createExceptionResponse(2);
/*     */     }
/* 120 */     response = getResponse();
/* 121 */     response.setRegisters(inpregs);
/*     */     
/* 123 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/* 135 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/* 147 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWordCount(int count)
/*     */   {
/* 159 */     this.m_WordCount = count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWordCount()
/*     */   {
/* 170 */     return this.m_WordCount;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 174 */     dout.writeShort(this.m_Reference);
/* 175 */     dout.writeShort(this.m_WordCount);
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 179 */     this.m_Reference = din.readUnsignedShort();
/* 180 */     this.m_WordCount = din.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 184 */     byte[] result = new byte[4];
/* 185 */     result[0] = ((byte)(this.m_Reference >> 8 & 0xFF));
/* 186 */     result[1] = ((byte)(this.m_Reference & 0xFF));
/* 187 */     result[2] = ((byte)(this.m_WordCount >> 8 & 0xFF));
/* 188 */     result[3] = ((byte)(this.m_WordCount & 0xFF));
/*     */     
/* 190 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadInputRegistersRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */