/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.util.BitVector;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadInputDiscretesResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_BitCount;
/*     */   private BitVector m_Discretes;
/*     */   
/*     */   public ReadInputDiscretesResponse()
/*     */   {
/*  69 */     setFunctionCode(2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadInputDiscretesResponse(int count)
/*     */   {
/*  82 */     setFunctionCode(2);
/*  83 */     setBitCount(count);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBitCount()
/*     */   {
/*  93 */     return this.m_BitCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBitCount(int count)
/*     */   {
/* 102 */     this.m_BitCount = count;
/* 103 */     this.m_Discretes = new BitVector(count);
/*     */     
/* 105 */     setDataLength(this.m_Discretes.byteSize() + 1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BitVector getDiscretes()
/*     */   {
/* 117 */     return this.m_Discretes;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getDiscreteStatus(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 135 */     return this.m_Discretes.getBit(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setDiscreteStatus(int index, boolean b)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 147 */     this.m_Discretes.setBit(index, b);
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException
/*     */   {
/* 152 */     dout.writeByte(this.m_Discretes.byteSize());
/* 153 */     dout.write(this.m_Discretes.getBytes(), 0, this.m_Discretes.byteSize());
/*     */   }
/*     */   
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 159 */     int count = din.readUnsignedByte();
/* 160 */     byte[] data = new byte[count];
/* 161 */     for (int k = 0; k < count; k++) {
/* 162 */       data[k] = din.readByte();
/*     */     }
/*     */     
/*     */ 
/* 166 */     this.m_Discretes = BitVector.createBitVector(data);
/*     */     
/*     */ 
/* 169 */     setDataLength(count + 1);
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 173 */     byte[] result = null;
/* 174 */     int len = 1 + this.m_Discretes.byteSize();
/*     */     
/* 176 */     result = new byte[len];
/* 177 */     result[0] = ((byte)this.m_Discretes.byteSize());
/* 178 */     System.arraycopy(this.m_Discretes.getBytes(), 0, 
/* 179 */       result, 1, this.m_Discretes.byteSize());
/*     */     
/* 181 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadInputDiscretesResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */