/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WriteSingleRegisterRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_Reference;
/*     */   private Register m_Register;
/*     */   
/*     */   public WriteSingleRegisterRequest()
/*     */   {
/*  67 */     setFunctionCode(6);
/*  68 */     setDataLength(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriteSingleRegisterRequest(int ref, Register reg)
/*     */   {
/*  83 */     setFunctionCode(6);
/*  84 */     setDataLength(4);
/*     */     
/*  86 */     this.m_Reference = ref;
/*  87 */     this.m_Register = reg;
/*     */   }
/*     */   
/*     */   public ModbusResponse getResponse() {
/*  91 */     WriteSingleRegisterResponse response = new WriteSingleRegisterResponse();
/*     */     
/*  93 */     response.setHeadless(isHeadless());
/*  94 */     if (!isHeadless()) {
/*  95 */       response.setProtocolID(getProtocolID());
/*  96 */       response.setTransactionID(getTransactionID());
/*     */     }
/*  98 */     response.setFunctionCode(getFunctionCode());
/*  99 */     response.setUnitID(getUnitID());
/*     */     
/* 101 */     return response;
/*     */   }
/*     */   
/*     */   public ModbusResponse createResponse() {
/* 105 */     WriteSingleRegisterResponse response = null;
/* 106 */     Register reg = null;
/*     */     
/*     */ 
/* 109 */     ProcessImage procimg = ModbusCoupler.getReference().getProcessImage();
/*     */     try
/*     */     {
/* 112 */       reg = procimg.getRegister(this.m_Reference);
/*     */       
/* 114 */       reg.setValue(this.m_Register.toBytes());
/*     */     } catch (IllegalAddressException iaex) {
/* 116 */       return createExceptionResponse(2);
/*     */     }
/* 118 */     response = (WriteSingleRegisterResponse)getResponse();
/*     */     
/* 120 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/* 131 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/* 141 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRegister(Register reg)
/*     */   {
/* 152 */     this.m_Register = reg;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Register getRegister()
/*     */   {
/* 162 */     return this.m_Register;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 166 */     dout.writeShort(this.m_Reference);
/* 167 */     dout.write(this.m_Register.toBytes());
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 171 */     this.m_Reference = din.readUnsignedShort();
/* 172 */     this.m_Register = new SimpleRegister(din.readByte(), din.readByte());
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 176 */     byte[] result = new byte[4];
/*     */     
/* 178 */     result[0] = ((byte)(this.m_Reference >> 8 & 0xFF));
/* 179 */     result[1] = ((byte)(this.m_Reference & 0xFF));
/* 180 */     result[2] = ((byte)(this.m_Register.getValue() >> 8 & 0xFF));
/* 181 */     result[3] = ((byte)(this.m_Register.getValue() & 0xFF));
/*     */     
/* 183 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\WriteSingleRegisterRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */