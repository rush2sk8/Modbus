/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WriteSingleRegisterResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_Reference;
/*     */   private int m_RegisterValue;
/*     */   
/*     */   public WriteSingleRegisterResponse()
/*     */   {
/*  65 */     setDataLength(4);
/*  66 */     setFunctionCode(6);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriteSingleRegisterResponse(int reference, int value)
/*     */   {
/*  78 */     setReference(reference);
/*  79 */     setRegisterValue(value);
/*  80 */     setDataLength(4);
/*  81 */     setFunctionCode(6);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRegisterValue()
/*     */   {
/*  92 */     return this.m_RegisterValue;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setRegisterValue(int value)
/*     */   {
/* 102 */     this.m_RegisterValue = value;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/* 112 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void setReference(int ref)
/*     */   {
/* 122 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 128 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException
/*     */   {
/* 133 */     setReference(din.readUnsignedShort());
/* 134 */     setRegisterValue(din.readUnsignedShort());
/*     */     
/* 136 */     setDataLength(4);
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 140 */     byte[] result = new byte[4];
/*     */     
/* 142 */     result[0] = ((byte)(this.m_Reference >> 8 & 0xFF));
/* 143 */     result[1] = ((byte)(this.m_Reference & 0xFF));
/* 144 */     result[2] = ((byte)(this.m_RegisterValue >> 8 & 0xFF));
/* 145 */     result[3] = ((byte)(this.m_RegisterValue & 0xFF));
/*     */     
/* 147 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\WriteSingleRegisterResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */