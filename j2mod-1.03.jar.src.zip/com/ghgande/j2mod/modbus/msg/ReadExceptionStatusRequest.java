/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadExceptionStatusRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   public ModbusResponse getResponse()
/*     */   {
/*  91 */     ReadExceptionStatusResponse response = null;
/*     */     
/*  93 */     response = new ReadExceptionStatusResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  98 */     response.setHeadless(isHeadless());
/*  99 */     if (!isHeadless()) {
/* 100 */       response.setTransactionID(getTransactionID());
/* 101 */       response.setProtocolID(getProtocolID());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 107 */     response.setUnitID(getUnitID());
/* 108 */     response.setFunctionCode(getFunctionCode());
/*     */     
/* 110 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusResponse createResponse()
/*     */   {
/* 118 */     throw new RuntimeException();
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 125 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 139 */     byte[] results = new byte[0];
/*     */     
/* 141 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadExceptionStatusRequest()
/*     */   {
/* 151 */     setFunctionCode(7);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 156 */     setDataLength(0);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadExceptionStatusRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */