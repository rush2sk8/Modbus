/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.util.BitVector;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadCoilsResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private BitVector coils;
/*     */   
/*     */   public int getBitCount()
/*     */   {
/*  73 */     if (this.coils == null) {
/*  74 */       return 0;
/*     */     }
/*  76 */     return this.coils.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BitVector getCoils()
/*     */   {
/*  88 */     return this.coils;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getCoilStatus(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 106 */     if (index < 0) {
/* 107 */       throw new IllegalArgumentException(index + " < 0");
/*     */     }
/* 109 */     if (index > this.coils.size()) {
/* 110 */       throw new IndexOutOfBoundsException(index + 
/* 111 */         " > " + this.coils.size());
/*     */     }
/* 113 */     return this.coils.getBit(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCoilStatus(int index, boolean b)
/*     */   {
/* 123 */     if (index < 0) {
/* 124 */       throw new IllegalArgumentException(index + " < 0");
/*     */     }
/* 126 */     if (index > this.coils.size()) {
/* 127 */       throw new IndexOutOfBoundsException(index + 
/* 128 */         " > " + this.coils.size());
/*     */     }
/* 130 */     this.coils.setBit(index, b);
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput output) throws IOException {
/* 134 */     byte[] result = getMessage();
/*     */     
/* 136 */     output.write(result);
/*     */   }
/*     */   
/*     */   public void readData(DataInput input) throws IOException {
/* 140 */     int count = input.readUnsignedByte();
/* 141 */     byte[] data = new byte[count];
/*     */     
/* 143 */     input.readFully(data, 0, count);
/* 144 */     this.coils = BitVector.createBitVector(data);
/* 145 */     setDataLength(count + 1);
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 149 */     int len = 1 + this.coils.byteSize();
/* 150 */     byte[] result = new byte[len];
/*     */     
/* 152 */     result[0] = ((byte)this.coils.byteSize());
/* 153 */     System.arraycopy(this.coils.getBytes(), 0, 
/* 154 */       result, 1, this.coils.byteSize());
/*     */     
/* 156 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadCoilsResponse()
/*     */   {
/* 164 */     setFunctionCode(1);
/* 165 */     setDataLength(1);
/* 166 */     this.coils = null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadCoilsResponse(int count)
/*     */   {
/* 176 */     setFunctionCode(1);
/* 177 */     this.coils = new BitVector(count);
/* 178 */     setDataLength(this.coils.byteSize() + 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadCoilsResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */