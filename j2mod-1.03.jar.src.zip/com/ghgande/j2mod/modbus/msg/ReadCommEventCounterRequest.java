/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadCommEventCounterRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   public ModbusResponse getResponse()
/*     */   {
/*  90 */     ReadCommEventCounterResponse response = null;
/*     */     
/*  92 */     response = new ReadCommEventCounterResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  97 */     response.setHeadless(isHeadless());
/*  98 */     if (!isHeadless()) {
/*  99 */       response.setTransactionID(getTransactionID());
/* 100 */       response.setProtocolID(getProtocolID());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 106 */     response.setUnitID(getUnitID());
/* 107 */     response.setFunctionCode(getFunctionCode());
/*     */     
/* 109 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModbusResponse createResponse()
/*     */   {
/* 116 */     throw new RuntimeException();
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 123 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {}
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 137 */     byte[] results = new byte[0];
/*     */     
/* 139 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadCommEventCounterRequest()
/*     */   {
/* 148 */     setFunctionCode(11);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 153 */     setDataLength(0);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadCommEventCounterRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */