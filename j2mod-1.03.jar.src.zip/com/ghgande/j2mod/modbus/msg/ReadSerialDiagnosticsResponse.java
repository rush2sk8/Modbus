/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadSerialDiagnosticsResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_Function;
/*  88 */   private short[] m_Data = new short[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFunction()
/*     */   {
/*  96 */     return this.m_Function;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFunction(int function)
/*     */   {
/* 105 */     this.m_Function = function;
/*     */     
/* 107 */     int size = 0;
/*     */     
/* 109 */     switch (function) {
/*     */     case 0: 
/*     */     case 1: 
/*     */     case 2: 
/*     */     case 3: 
/*     */     case 4: 
/*     */     case 10: 
/*     */     case 11: 
/*     */     case 12: 
/*     */     case 13: 
/*     */     case 14: 
/*     */     case 15: 
/*     */     case 16: 
/*     */     case 17: 
/*     */     case 18: 
/*     */     case 20: 
/* 125 */       size = 1;
/*     */     }
/*     */     
/* 128 */     this.m_Data = new short[size];
/* 129 */     setDataLength(2 + size * 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getWordCount()
/*     */   {
/* 136 */     if (this.m_Data != null) {
/* 137 */       return this.m_Data.length;
/*     */     }
/* 139 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getData()
/*     */   {
/* 146 */     return getData(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getData(int index)
/*     */   {
/* 153 */     if ((index < 0) || (index > getWordCount())) {
/* 154 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 156 */     return this.m_Data[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setData(int value)
/*     */   {
/* 163 */     setData(0, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setData(int index, int value)
/*     */   {
/* 170 */     if ((index < 0) || (index > getWordCount())) {
/* 171 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 173 */     this.m_Data[index] = ((short)value);
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 180 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 188 */     this.m_Function = (din.readShort() & 0xFFFF);
/*     */     
/* 190 */     setFunction(this.m_Function);
/*     */     
/* 192 */     if (this.m_Data.length > 0) {
/* 193 */       for (int i = 0; i < this.m_Data.length; i++) {
/* 194 */         this.m_Data[i] = din.readShort();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 202 */     byte[] result = new byte[2 + getWordCount() * 2];
/*     */     
/* 204 */     result[0] = ((byte)(this.m_Function >> 8));
/* 205 */     result[1] = ((byte)(this.m_Function & 0xFF));
/* 206 */     for (int i = 0; i < getWordCount(); i++) {
/* 207 */       result[(2 + i * 2)] = ((byte)(this.m_Data[i] >> 8));
/* 208 */       result[(3 + i * 2)] = ((byte)(this.m_Data[i] & 0xFF));
/*     */     }
/* 210 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadSerialDiagnosticsResponse()
/*     */   {
/* 219 */     setFunctionCode(8);
/* 220 */     setDataLength(2);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadSerialDiagnosticsResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */