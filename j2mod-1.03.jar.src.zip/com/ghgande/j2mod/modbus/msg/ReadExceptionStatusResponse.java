/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadExceptionStatusResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_Status;
/*     */   
/*     */   public ReadExceptionStatusResponse()
/*     */   {
/*  95 */     setFunctionCode(7);
/*  96 */     setDataLength(1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStatus()
/*     */   {
/* 105 */     return this.m_Status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatus(int status)
/*     */   {
/* 114 */     this.m_Status = status;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 121 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 129 */     this.m_Status = (din.readByte() & 0xFF);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 136 */     byte[] result = new byte[1];
/*     */     
/* 138 */     result[0] = ((byte)(this.m_Status & 0xFF));
/*     */     
/* 140 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadExceptionStatusResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */