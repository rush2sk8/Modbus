/*    */ package com.ghgande.j2mod.modbus.msg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalFunctionExceptionResponse
/*    */   extends ExceptionResponse
/*    */ {
/*    */   public void setFunctionCode(int fc)
/*    */   {
/* 19 */     super.setFunctionCode(fc | 0x80);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public IllegalFunctionExceptionResponse()
/*    */   {
/* 26 */     super(0, 1);
/*    */   }
/*    */   
/*    */   public IllegalFunctionExceptionResponse(int function)
/*    */   {
/* 31 */     super(function | 0x80, 1);
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\IllegalFunctionExceptionResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */