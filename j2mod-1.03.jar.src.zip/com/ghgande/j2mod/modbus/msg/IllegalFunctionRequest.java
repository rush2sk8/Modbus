/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IllegalFunctionRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   public IllegalFunctionRequest(int function)
/*     */   {
/*  67 */     setFunctionCode(function);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public IllegalFunctionRequest(int unit, int function)
/*     */   {
/*  81 */     setUnitID(unit);
/*  82 */     setFunctionCode(function);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModbusResponse getResponse()
/*     */   {
/*  89 */     IllegalFunctionExceptionResponse response = 
/*  90 */       new IllegalFunctionExceptionResponse(getFunctionCode());
/*     */     
/*  92 */     response.setUnitID(getUnitID());
/*  93 */     return response;
/*     */   }
/*     */   
/*     */   public ModbusResponse createResponse() {
/*  97 */     return createExceptionResponse(1);
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 101 */     throw new RuntimeException();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 111 */     int length = getDataLength();
/* 112 */     for (int i = 0; i < length; i++) {
/* 113 */       din.readByte();
/*     */     }
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 118 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\IllegalFunctionRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */