/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadMultipleRegistersResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_ByteCount;
/*     */   private Register[] m_Registers;
/*     */   
/*     */   public ReadMultipleRegistersResponse()
/*     */   {
/*  66 */     setFunctionCode(3);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadMultipleRegistersResponse(Register[] registers)
/*     */   {
/*  78 */     setFunctionCode(3);
/*  79 */     setDataLength(registers.length * 2 + 1);
/*     */     
/*  81 */     this.m_Registers = registers;
/*  82 */     this.m_ByteCount = (registers.length * 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getByteCount()
/*     */   {
/*  91 */     return this.m_ByteCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWordCount()
/*     */   {
/* 102 */     return this.m_ByteCount / 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Register getRegister(int index)
/*     */   {
/* 118 */     if (this.m_Registers == null) {
/* 119 */       throw new IndexOutOfBoundsException("No registers defined!");
/*     */     }
/* 121 */     if (index < 0) {
/* 122 */       throw new IndexOutOfBoundsException("Negative index: " + index);
/*     */     }
/* 124 */     if (index >= getWordCount()) {
/* 125 */       throw new IndexOutOfBoundsException(index + " > " + getWordCount());
/*     */     }
/* 127 */     return this.m_Registers[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRegisterValue(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 144 */     return getRegister(index).toUnsignedShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Register[] getRegisters()
/*     */   {
/* 153 */     return this.m_Registers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRegisters(Register[] registers)
/*     */   {
/* 160 */     this.m_ByteCount = (registers.length * 2);
/* 161 */     setDataLength(this.m_ByteCount + 1);
/*     */     
/* 163 */     this.m_Registers = registers;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 167 */     dout.writeByte(this.m_ByteCount);
/*     */     
/* 169 */     for (int k = 0; k < getWordCount(); k++)
/* 170 */       dout.write(this.m_Registers[k].toBytes());
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 174 */     this.m_ByteCount = din.readUnsignedByte();
/*     */     
/* 176 */     this.m_Registers = new Register[getWordCount()];
/*     */     
/* 178 */     for (int k = 0; k < getWordCount(); k++) {
/* 179 */       this.m_Registers[k] = new SimpleRegister(din.readByte(), din.readByte());
/*     */     }
/* 181 */     setDataLength(this.m_ByteCount + 1);
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 185 */     byte[] result = null;
/*     */     
/* 187 */     result = new byte[getWordCount() * 2 + 1];
/*     */     
/* 189 */     int offset = 0;
/* 190 */     result[(offset++)] = ((byte)this.m_ByteCount);
/*     */     
/* 192 */     for (int i = 0; i < this.m_Registers.length; i++) {
/* 193 */       byte[] data = this.m_Registers[i].toBytes();
/*     */       
/* 195 */       result[(offset++)] = data[0];
/* 196 */       result[(offset++)] = data[1];
/*     */     }
/* 198 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadMultipleRegistersResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */