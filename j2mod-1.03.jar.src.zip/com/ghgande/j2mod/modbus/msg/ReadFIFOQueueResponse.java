/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.procimg.InputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleInputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadFIFOQueueResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_Count;
/*     */   private InputRegister[] m_Registers;
/*     */   
/*     */   public int getWordCount()
/*     */   {
/*  99 */     return this.m_Count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setWordCount(int ref)
/*     */   {
/* 108 */     if ((ref < 0) || (ref > 31)) {
/* 109 */       throw new IllegalArgumentException();
/*     */     }
/* 111 */     int oldCount = this.m_Count;
/* 112 */     InputRegister[] newRegisters = new InputRegister[ref];
/*     */     
/* 114 */     this.m_Count = ref;
/*     */     
/* 116 */     for (int i = 0; i < ref; i++) {
/* 117 */       if (i < oldCount) {
/* 118 */         newRegisters[i] = this.m_Registers[i];
/*     */       } else
/* 120 */         newRegisters[i] = new SimpleRegister(0);
/*     */     }
/*     */   }
/*     */   
/*     */   public int getRegister(int index) {
/* 125 */     return this.m_Registers[index].getValue();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public synchronized void setRegisters(InputRegister[] regs)
/*     */   {
/* 134 */     this.m_Registers = regs;
/* 135 */     if (regs == null) {
/* 136 */       this.m_Count = 0;
/* 137 */       return;
/*     */     }
/*     */     
/* 140 */     if (regs.length > 31) {
/* 141 */       throw new IllegalArgumentException();
/*     */     }
/* 143 */     this.m_Count = regs.length;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 150 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 164 */     din.readShort();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 170 */     this.m_Count = din.readShort();
/* 171 */     this.m_Registers = new InputRegister[this.m_Count];
/*     */     
/* 173 */     for (int i = 0; i < this.m_Count; i++) {
/* 174 */       this.m_Registers[i] = new SimpleInputRegister(din.readShort());
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 181 */     byte[] result = new byte[this.m_Count * 2 + 4];
/*     */     
/* 183 */     int len = this.m_Count * 2 + 2;
/* 184 */     result[0] = ((byte)(len >> 8));
/* 185 */     result[1] = ((byte)(len & 0xFF));
/* 186 */     result[2] = ((byte)(this.m_Count >> 8));
/* 187 */     result[3] = ((byte)(this.m_Count & 0xFF));
/*     */     
/* 189 */     for (int i = 0; i < this.m_Count; i++) {
/* 190 */       byte[] value = this.m_Registers[i].toBytes();
/* 191 */       result[(i * 2 + 4)] = value[0];
/* 192 */       result[(i * 2 + 5)] = value[1];
/*     */     }
/* 194 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadFIFOQueueResponse()
/*     */   {
/* 203 */     setFunctionCode(24);
/*     */     
/* 205 */     this.m_Count = 0;
/* 206 */     this.m_Registers = new InputRegister[0];
/*     */     
/* 208 */     setDataLength(7);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadFIFOQueueResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */