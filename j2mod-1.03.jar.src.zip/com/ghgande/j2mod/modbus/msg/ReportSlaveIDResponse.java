/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReportSlaveIDResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   int m_length;
/*     */   byte[] m_data;
/*     */   int m_status;
/*     */   int m_slaveId;
/*     */   
/*     */   public ReportSlaveIDResponse()
/*     */   {
/* 102 */     setFunctionCode(17);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getSlaveID()
/*     */   {
/* 110 */     return this.m_slaveId;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setSlaveID(int i)
/*     */   {
/* 118 */     this.m_slaveId = i;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getStatus()
/*     */   {
/* 126 */     return this.m_status != 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatus(boolean b)
/*     */   {
/* 136 */     this.m_status = (b ? 255 : 0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getData()
/*     */   {
/* 145 */     byte[] result = new byte[this.m_length - 2];
/* 146 */     System.arraycopy(this.m_data, 0, result, 0, this.m_length - 2);
/*     */     
/* 148 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setData(byte[] data)
/*     */   {
/* 161 */     if (data == null) {
/* 162 */       this.m_length = 2;
/* 163 */       this.m_data = new byte[0];
/*     */       
/* 165 */       return;
/*     */     }
/*     */     
/* 168 */     if (data.length > 249) {
/* 169 */       throw new IllegalArgumentException("data length limit exceeded");
/*     */     }
/* 171 */     this.m_length = (data.length + 2);
/*     */     
/* 173 */     this.m_data = new byte[data.length];
/* 174 */     System.arraycopy(data, 0, this.m_data, 0, data.length);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 182 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 195 */     this.m_length = din.readUnsignedByte();
/* 196 */     if ((this.m_length < 2) || (this.m_length > 255)) {
/* 197 */       return;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 202 */     this.m_slaveId = din.readUnsignedByte();
/* 203 */     this.m_status = din.readUnsignedByte();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 210 */     this.m_data = new byte[this.m_length - 2];
/* 211 */     if (this.m_length > 2) {
/* 212 */       din.readFully(this.m_data, 0, this.m_length - 2);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 219 */     byte[] result = new byte[3 + this.m_length];
/* 220 */     int offset = 0;
/*     */     
/* 222 */     result[(offset++)] = ((byte)(this.m_length + 2));
/* 223 */     result[(offset++)] = ((byte)this.m_slaveId);
/* 224 */     result[(offset++)] = ((byte)this.m_status);
/* 225 */     if (this.m_length > 0) {
/* 226 */       System.arraycopy(this.m_data, 0, result, offset, this.m_length - 2);
/*     */     }
/* 228 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReportSlaveIDResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */