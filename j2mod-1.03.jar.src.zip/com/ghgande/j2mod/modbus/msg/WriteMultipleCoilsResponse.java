/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WriteMultipleCoilsResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_Reference;
/*     */   private int m_BitCount;
/*     */   
/*     */   public WriteMultipleCoilsResponse()
/*     */   {
/*  65 */     setDataLength(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriteMultipleCoilsResponse(int ref, int count)
/*     */   {
/*  77 */     this.m_Reference = ref;
/*  78 */     this.m_BitCount = count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/*  89 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBitCount()
/*     */   {
/*  99 */     return this.m_BitCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBitCount(int count)
/*     */   {
/* 109 */     this.m_BitCount = count;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 115 */     dout.writeShort(this.m_Reference);
/* 116 */     dout.writeShort(this.m_BitCount);
/*     */   }
/*     */   
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 122 */     this.m_Reference = din.readUnsignedShort();
/* 123 */     this.m_BitCount = din.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 127 */     byte[] results = new byte[4];
/* 128 */     results[0] = ((byte)(this.m_Reference >> 8 & 0xFF));
/* 129 */     results[1] = ((byte)(this.m_Reference & 0xFF));
/* 130 */     results[2] = ((byte)(this.m_BitCount >> 8 & 0xFF));
/* 131 */     results[3] = ((byte)(this.m_BitCount & 0xFF));
/*     */     
/* 133 */     return results;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\WriteMultipleCoilsResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */