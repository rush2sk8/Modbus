/*    */ package com.ghgande.j2mod.modbus.msg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class IllegalValueExceptionResponse
/*    */   extends ExceptionResponse
/*    */ {
/*    */   public void setFunctionCode(int fc)
/*    */   {
/* 19 */     super.setFunctionCode(fc | 0x80);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public IllegalValueExceptionResponse()
/*    */   {
/* 26 */     super(0, 3);
/*    */   }
/*    */   
/*    */   public IllegalValueExceptionResponse(int function) {
/* 30 */     super(function, 3);
/*    */   }
/*    */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\IllegalValueExceptionResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */