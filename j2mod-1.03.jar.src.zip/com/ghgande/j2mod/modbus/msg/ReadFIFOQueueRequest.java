/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.InputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadFIFOQueueRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_Reference;
/*     */   
/*     */   public int getReference()
/*     */   {
/*  99 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/* 108 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModbusResponse getResponse()
/*     */   {
/* 115 */     ReadFIFOQueueResponse response = null;
/*     */     
/* 117 */     response = new ReadFIFOQueueResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 122 */     response.setHeadless(isHeadless());
/* 123 */     if (!isHeadless()) {
/* 124 */       response.setTransactionID(getTransactionID());
/* 125 */       response.setProtocolID(getProtocolID());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 131 */     response.setUnitID(getUnitID());
/* 132 */     response.setFunctionCode(getFunctionCode());
/*     */     
/* 134 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModbusResponse createResponse()
/*     */   {
/* 141 */     ReadFIFOQueueResponse response = null;
/* 142 */     InputRegister[] registers = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 147 */     ProcessImage procimg = ModbusCoupler.getReference().getProcessImage();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 154 */       Register queue = procimg.getRegister(this.m_Reference);
/* 155 */       int count = queue.getValue();
/* 156 */       if ((count < 0) || (count > 31)) {
/* 157 */         return createExceptionResponse(3);
/*     */       }
/* 159 */       registers = procimg.getRegisterRange(this.m_Reference + 1, count);
/*     */     } catch (IllegalAddressException e) {
/* 161 */       return createExceptionResponse(2);
/*     */     }
/* 163 */     response = (ReadFIFOQueueResponse)getResponse();
/* 164 */     response.setRegisters(registers);
/*     */     
/* 166 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 173 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 180 */     this.m_Reference = din.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 187 */     byte[] results = new byte[2];
/*     */     
/* 189 */     results[0] = ((byte)(this.m_Reference >> 8));
/* 190 */     results[1] = ((byte)(this.m_Reference & 0xFF));
/*     */     
/* 192 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadFIFOQueueRequest()
/*     */   {
/* 201 */     setFunctionCode(24);
/* 202 */     setDataLength(2);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadFIFOQueueRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */