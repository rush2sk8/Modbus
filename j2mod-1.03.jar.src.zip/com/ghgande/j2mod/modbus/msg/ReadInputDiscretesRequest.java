/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.procimg.DigitalIn;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadInputDiscretesRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_Reference;
/*     */   private int m_BitCount;
/*     */   
/*     */   public ReadInputDiscretesRequest()
/*     */   {
/*  72 */     setFunctionCode(2);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*  77 */     setDataLength(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadInputDiscretesRequest(int ref, int count)
/*     */   {
/*  93 */     setFunctionCode(2);
/*     */     
/*  95 */     setDataLength(4);
/*  96 */     setReference(ref);
/*  97 */     setBitCount(count);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadInputDiscretesResponse getResponse()
/*     */   {
/* 109 */     ReadInputDiscretesResponse response = 
/* 110 */       new ReadInputDiscretesResponse(getBitCount());
/*     */     
/* 112 */     response.setUnitID(getUnitID());
/* 113 */     response.setFunctionCode(getFunctionCode());
/*     */     
/* 115 */     response.setHeadless(isHeadless());
/* 116 */     if (!isHeadless()) {
/* 117 */       response.setTransactionID(getTransactionID());
/* 118 */       response.setProtocolID(getProtocolID());
/*     */     }
/* 120 */     return response;
/*     */   }
/*     */   
/*     */   public ModbusResponse createResponse() {
/* 124 */     ReadInputDiscretesResponse response = null;
/* 125 */     DigitalIn[] dins = null;
/*     */     
/*     */ 
/* 128 */     ProcessImage procimg = ModbusCoupler.getReference().getProcessImage();
/*     */     try
/*     */     {
/* 131 */       dins = procimg.getDigitalInRange(getReference(), 
/* 132 */         getBitCount());
/*     */     } catch (IllegalAddressException e) {
/* 134 */       return createExceptionResponse(2);
/*     */     }
/* 136 */     response = getResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 141 */     for (int i = 0; i < dins.length; i++) {
/* 142 */       response.setDiscreteStatus(i, dins[i].isSet());
/*     */     }
/* 144 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/* 156 */     if ((ref < 0) || (this.m_BitCount + ref >= 65536)) {
/* 157 */       throw new IllegalArgumentException();
/*     */     }
/* 159 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/* 170 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBitCount(int count)
/*     */   {
/* 181 */     if ((count < 0) || (count > 2000) || (count + this.m_Reference >= 65536)) {
/* 182 */       throw new IllegalArgumentException();
/*     */     }
/* 184 */     this.m_BitCount = count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBitCount()
/*     */   {
/* 195 */     return this.m_BitCount;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 199 */     dout.writeShort(this.m_Reference);
/* 200 */     dout.writeShort(this.m_BitCount);
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 204 */     this.m_Reference = din.readUnsignedShort();
/* 205 */     this.m_BitCount = din.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 209 */     byte[] result = new byte[4];
/*     */     
/* 211 */     result[0] = ((byte)(this.m_Reference >> 8 & 0xFF));
/* 212 */     result[1] = ((byte)(this.m_Reference & 0xFF));
/* 213 */     result[2] = ((byte)(this.m_BitCount >> 8 & 0xFF));
/* 214 */     result[3] = ((byte)(this.m_BitCount & 0xFF));
/*     */     
/* 216 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadInputDiscretesRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */