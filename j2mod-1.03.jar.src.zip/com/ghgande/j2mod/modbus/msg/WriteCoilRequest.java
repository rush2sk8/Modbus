/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.Modbus;
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.procimg.DigitalOut;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WriteCoilRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_Reference;
/*     */   private boolean m_Coil;
/*     */   
/*     */   public WriteCoilRequest()
/*     */   {
/*  66 */     setFunctionCode(5);
/*  67 */     setDataLength(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriteCoilRequest(int ref, boolean b)
/*     */   {
/*  82 */     setFunctionCode(5);
/*  83 */     setDataLength(4);
/*     */     
/*  85 */     setReference(ref);
/*  86 */     setCoil(b);
/*     */   }
/*     */   
/*     */   public ModbusResponse getResponse() {
/*  90 */     WriteCoilResponse response = new WriteCoilResponse();
/*     */     
/*  92 */     response.setHeadless(isHeadless());
/*  93 */     if (!isHeadless()) {
/*  94 */       response.setProtocolID(getProtocolID());
/*  95 */       response.setTransactionID(getTransactionID());
/*     */     }
/*  97 */     response.setFunctionCode(getFunctionCode());
/*  98 */     response.setUnitID(getUnitID());
/*     */     
/* 100 */     return response;
/*     */   }
/*     */   
/*     */   public ModbusResponse createResponse() {
/* 104 */     WriteCoilResponse response = null;
/* 105 */     DigitalOut dout = null;
/*     */     
/*     */ 
/* 108 */     ProcessImage procimg = ModbusCoupler.getReference().getProcessImage();
/*     */     try
/*     */     {
/* 111 */       dout = procimg.getDigitalOut(getReference());
/*     */       
/* 113 */       dout.set(getCoil());
/*     */     } catch (IllegalAddressException iaex) {
/* 115 */       return createExceptionResponse(2);
/*     */     }
/* 117 */     response = (WriteCoilResponse)getResponse();
/* 118 */     response.setReference(getReference());
/* 119 */     response.setCoil(getCoil());
/*     */     
/* 121 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/* 133 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/* 143 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCoil(boolean b)
/*     */   {
/* 153 */     this.m_Coil = b;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getCoil()
/*     */   {
/* 163 */     return this.m_Coil;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 167 */     dout.writeShort(this.m_Reference);
/*     */     
/* 169 */     if (this.m_Coil) {
/* 170 */       dout.write(Modbus.COIL_ON_BYTES, 0, 2);
/*     */     } else
/* 172 */       dout.write(Modbus.COIL_OFF_BYTES, 0, 2);
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 176 */     this.m_Reference = din.readUnsignedShort();
/*     */     
/* 178 */     if (din.readByte() == -1) {
/* 179 */       this.m_Coil = true;
/*     */     } else {
/* 181 */       this.m_Coil = false;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 186 */     din.readByte();
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 190 */     byte[] result = new byte[4];
/*     */     
/* 192 */     result[0] = ((byte)(this.m_Reference >> 8 & 0xFF));
/* 193 */     result[1] = ((byte)(this.m_Reference & 0xFF));
/* 194 */     if (this.m_Coil) {
/* 195 */       result[2] = Modbus.COIL_ON_BYTES[0];
/* 196 */       result[3] = Modbus.COIL_ON_BYTES[1];
/*     */     } else {
/* 198 */       result[2] = Modbus.COIL_OFF_BYTES[0];
/* 199 */       result[3] = Modbus.COIL_OFF_BYTES[1];
/*     */     }
/* 201 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\WriteCoilRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */