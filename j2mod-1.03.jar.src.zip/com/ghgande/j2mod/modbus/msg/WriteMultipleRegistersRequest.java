/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.io.NonWordDataHandler;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WriteMultipleRegistersRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_Reference;
/*     */   private Register[] m_Registers;
/*  93 */   private NonWordDataHandler m_NonWordDataHandler = null;
/*     */   
/*     */ 
/*     */ 
/*     */   public WriteMultipleRegistersRequest()
/*     */   {
/*  99 */     setFunctionCode(16);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriteMultipleRegistersRequest(int first, Register[] registers)
/*     */   {
/* 113 */     setFunctionCode(16);
/*     */     
/* 115 */     setReference(first);
/* 116 */     setRegisters(registers);
/*     */   }
/*     */   
/*     */   public ModbusResponse getResponse() {
/* 120 */     WriteMultipleRegistersResponse response = new WriteMultipleRegistersResponse();
/*     */     
/* 122 */     response.setHeadless(isHeadless());
/* 123 */     if (!isHeadless()) {
/* 124 */       response.setProtocolID(getProtocolID());
/* 125 */       response.setTransactionID(getTransactionID());
/*     */     }
/* 127 */     response.setFunctionCode(getFunctionCode());
/* 128 */     response.setUnitID(getUnitID());
/*     */     
/* 130 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusResponse createResponse()
/*     */   {
/* 140 */     WriteMultipleRegistersResponse response = null;
/*     */     
/* 142 */     if (this.m_NonWordDataHandler == null) {
/* 143 */       Register[] regs = null;
/*     */       
/* 145 */       ProcessImage procimg = ModbusCoupler.getReference()
/* 146 */         .getProcessImage();
/*     */       try
/*     */       {
/* 149 */         regs = procimg.getRegisterRange(getReference(), getWordCount());
/*     */         
/* 151 */         for (int i = 0; i < regs.length; i++)
/* 152 */           regs[i].setValue(getRegister(i).toBytes());
/*     */       } catch (IllegalAddressException iaex) {
/* 154 */         return createExceptionResponse(2);
/*     */       }
/* 156 */       response = (WriteMultipleRegistersResponse)getResponse();
/*     */       
/* 158 */       response.setReference(getReference());
/* 159 */       response.setWordCount(getWordCount());
/*     */     } else {
/* 161 */       int result = this.m_NonWordDataHandler.commitUpdate();
/* 162 */       if (result > 0) {
/* 163 */         return createExceptionResponse(result);
/*     */       }
/* 165 */       response = (WriteMultipleRegistersResponse)getResponse();
/*     */       
/* 167 */       response.setReference(getReference());
/* 168 */       response.setWordCount(this.m_NonWordDataHandler.getWordCount());
/*     */     }
/*     */     
/* 171 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/* 184 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/* 196 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setRegisters(Register[] registers)
/*     */   {
/* 208 */     this.m_Registers = registers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Register[] getRegisters()
/*     */   {
/* 219 */     return this.m_Registers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Register getRegister(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 235 */     if (index < 0) {
/* 236 */       throw new IndexOutOfBoundsException(index + " < 0");
/*     */     }
/* 238 */     if (index >= getWordCount()) {
/* 239 */       throw new IndexOutOfBoundsException(index + " > " + getWordCount());
/*     */     }
/* 241 */     return this.m_Registers[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRegisterValue(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 259 */     return getRegister(index).toUnsignedShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getByteCount()
/*     */   {
/* 269 */     return getWordCount() * 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWordCount()
/*     */   {
/* 278 */     if (this.m_Registers == null) {
/* 279 */       return 0;
/*     */     }
/* 281 */     return this.m_Registers.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setNonWordDataHandler(NonWordDataHandler dhandler)
/*     */   {
/* 293 */     this.m_NonWordDataHandler = dhandler;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public NonWordDataHandler getNonWordDataHandler()
/*     */   {
/* 302 */     return this.m_NonWordDataHandler;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput output) throws IOException {
/* 306 */     byte[] data = getMessage();
/* 307 */     if (data == null) {
/* 308 */       return;
/*     */     }
/* 310 */     output.write(data);
/*     */   }
/*     */   
/*     */   public void readData(DataInput input) throws IOException {
/* 314 */     this.m_Reference = input.readShort();
/* 315 */     int registerCount = input.readUnsignedShort();
/* 316 */     int byteCount = input.readUnsignedByte();
/*     */     
/* 318 */     if (this.m_NonWordDataHandler == null) {
/* 319 */       byte[] buffer = new byte[byteCount];
/* 320 */       input.readFully(buffer, 0, byteCount);
/*     */       
/* 322 */       int offset = 0;
/* 323 */       this.m_Registers = new Register[registerCount];
/*     */       
/* 325 */       for (int register = 0; register < registerCount; register++) {
/* 326 */         this.m_Registers[register] = new SimpleRegister(buffer[offset], 
/* 327 */           buffer[(offset + 1)]);
/* 328 */         offset += 2;
/*     */       }
/*     */     } else {
/* 331 */       this.m_NonWordDataHandler.readData(input, this.m_Reference, registerCount);
/*     */     }
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 336 */     int len = 5;
/*     */     
/* 338 */     if (this.m_Registers != null) {
/* 339 */       len += this.m_Registers.length * 2;
/*     */     }
/* 341 */     byte[] result = new byte[len];
/* 342 */     int registerCount = this.m_Registers != null ? this.m_Registers.length : 0;
/*     */     
/* 344 */     result[0] = ((byte)(this.m_Reference >> 8 & 0xFF));
/* 345 */     result[1] = ((byte)(this.m_Reference & 0xFF));
/* 346 */     result[2] = ((byte)(registerCount >> 8 & 0xFF));
/* 347 */     result[3] = ((byte)(registerCount & 0xFF));
/* 348 */     result[4] = ((byte)(registerCount * 2));
/*     */     
/* 350 */     int offset = 5;
/*     */     
/* 352 */     if (this.m_NonWordDataHandler == null) {
/* 353 */       for (int i = 0; i < registerCount; i++) {
/* 354 */         byte[] bytes = this.m_Registers[i].toBytes();
/* 355 */         result[(offset++)] = bytes[0];
/* 356 */         result[(offset++)] = bytes[1];
/*     */       }
/*     */     } else {
/* 359 */       this.m_NonWordDataHandler.prepareData(this.m_Reference, registerCount);
/* 360 */       byte[] bytes = this.m_NonWordDataHandler.getData();
/* 361 */       if (bytes != null) {
/* 362 */         int nonWordBytes = bytes.length;
/* 363 */         if (nonWordBytes > registerCount * 2) {
/* 364 */           nonWordBytes = registerCount * 2;
/*     */         }
/* 366 */         System.arraycopy(bytes, 0, result, offset, nonWordBytes);
/*     */       }
/*     */     }
/* 369 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\WriteMultipleRegistersRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */