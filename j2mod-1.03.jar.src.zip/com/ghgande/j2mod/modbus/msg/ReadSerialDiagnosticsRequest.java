/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadSerialDiagnosticsRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_Function;
/*  88 */   private short[] m_Data = new short[0];
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFunction()
/*     */   {
/*  96 */     return this.m_Function;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setFunction(int function)
/*     */   {
/* 105 */     this.m_Function = function;
/*     */     
/* 107 */     int size = 0;
/*     */     
/* 109 */     switch (function) {
/*     */     case 0: 
/*     */     case 1: 
/*     */     case 2: 
/*     */     case 3: 
/*     */     case 4: 
/*     */     case 10: 
/*     */     case 11: 
/*     */     case 12: 
/*     */     case 13: 
/*     */     case 14: 
/*     */     case 15: 
/*     */     case 16: 
/*     */     case 17: 
/*     */     case 18: 
/*     */     case 20: 
/* 125 */       size = 1;
/*     */     }
/*     */     
/* 128 */     this.m_Data = new short[size];
/* 129 */     setDataLength(2 + size * 2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getWordCount()
/*     */   {
/* 136 */     if (this.m_Data != null) {
/* 137 */       return this.m_Data.length;
/*     */     }
/* 139 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getData()
/*     */   {
/* 146 */     return getData(0);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getData(int index)
/*     */   {
/* 153 */     if ((index < 0) || (index > getWordCount())) {
/* 154 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 156 */     return this.m_Data[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setData(int value)
/*     */   {
/* 163 */     setData(0, value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setData(int index, int value)
/*     */   {
/* 170 */     if ((index < 0) || (index > getWordCount())) {
/* 171 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 173 */     this.m_Data[index] = ((short)value);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModbusResponse getResponse()
/*     */   {
/* 180 */     ReadSerialDiagnosticsResponse response = null;
/*     */     
/* 182 */     response = new ReadSerialDiagnosticsResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 187 */     response.setHeadless(isHeadless());
/* 188 */     if (!isHeadless()) {
/* 189 */       response.setTransactionID(getTransactionID());
/* 190 */       response.setProtocolID(getProtocolID());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 196 */     response.setUnitID(getUnitID());
/* 197 */     response.setFunctionCode(getFunctionCode());
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 203 */     response.setFunction(getFunction());
/*     */     
/* 205 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusResponse createResponse()
/*     */   {
/* 213 */     throw new RuntimeException();
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 220 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 227 */     this.m_Function = (din.readShort() & 0xFFFF);
/*     */     
/* 229 */     setFunction(this.m_Function);
/*     */     
/* 231 */     if (this.m_Data.length > 0) {
/* 232 */       for (int i = 0; i < this.m_Data.length; i++) {
/* 233 */         this.m_Data[i] = din.readShort();
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 242 */     byte[] result = new byte[2 + getWordCount() * 2];
/*     */     
/* 244 */     result[0] = ((byte)(this.m_Function >> 8));
/* 245 */     result[1] = ((byte)(this.m_Function & 0xFF));
/* 246 */     for (int i = 0; i < getWordCount(); i++) {
/* 247 */       result[(2 + i * 2)] = ((byte)(this.m_Data[i] >> 8));
/* 248 */       result[(3 + i * 2)] = ((byte)(this.m_Data[i] & 0xFF));
/*     */     }
/* 250 */     return result;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadSerialDiagnosticsRequest()
/*     */   {
/* 260 */     setFunctionCode(17);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 265 */     setDataLength(4);
/* 266 */     this.m_Data = new short[1];
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadSerialDiagnosticsRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */