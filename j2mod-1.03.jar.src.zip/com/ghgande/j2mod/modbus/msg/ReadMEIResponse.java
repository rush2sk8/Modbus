/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadMEIResponse
/*     */   extends ModbusResponse
/*     */ {
/*  88 */   private int m_FieldLevel = 0;
/*  89 */   private int m_Conformity = 1;
/*  90 */   private int m_FieldCount = 0;
/*  91 */   private String[] m_Fields = new String[64];
/*  92 */   private int[] m_FieldIds = new int[64];
/*  93 */   private boolean m_MoreFollows = false;
/*     */   
/*     */ 
/*     */   private int m_NextFieldId;
/*     */   
/*     */ 
/*     */ 
/*     */   public ReadMEIResponse()
/*     */   {
/* 102 */     setFunctionCode(43);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldCount()
/*     */   {
/* 113 */     if (this.m_Fields == null) {
/* 114 */       return 0;
/*     */     }
/* 116 */     return this.m_Fields.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String[] getFields()
/*     */   {
/* 125 */     return this.m_Fields;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public String getField(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 142 */     return this.m_Fields[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getFieldId(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 159 */     return this.m_FieldIds[index];
/*     */   }
/*     */   
/*     */   public void setFieldLevel(int level) {
/* 163 */     this.m_FieldLevel = level;
/*     */   }
/*     */   
/*     */   public void addField(int id, String text) {
/* 167 */     this.m_FieldIds[this.m_FieldCount] = id;
/* 168 */     this.m_Fields[this.m_FieldCount] = text;
/* 169 */     this.m_FieldCount += 1;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException
/*     */   {
/* 174 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException
/*     */   {
/* 179 */     int byteCount = 0;
/*     */     
/* 181 */     int subCode = din.readUnsignedByte();
/* 182 */     if (subCode != 14) {
/* 183 */       throw new IOException("Invalid sub code");
/*     */     }
/*     */     
/* 186 */     this.m_FieldLevel = din.readUnsignedByte();
/* 187 */     this.m_Conformity = din.readUnsignedByte();
/* 188 */     this.m_MoreFollows = (din.readUnsignedByte() == 255);
/* 189 */     this.m_NextFieldId = din.readUnsignedByte();
/*     */     
/* 191 */     this.m_FieldCount = din.readUnsignedByte();
/*     */     
/* 193 */     byteCount = 6;
/*     */     
/* 195 */     if (this.m_FieldCount > 0) {
/* 196 */       this.m_Fields = new String[this.m_FieldCount];
/* 197 */       this.m_FieldIds = new int[this.m_FieldCount];
/*     */       
/* 199 */       for (int i = 0; i < this.m_FieldCount; i++) {
/* 200 */         this.m_FieldIds[i] = din.readUnsignedByte();
/* 201 */         int len = din.readUnsignedByte();
/* 202 */         byte[] data = new byte[len];
/* 203 */         din.readFully(data);
/* 204 */         this.m_Fields[i] = new String(data);
/*     */         
/* 206 */         byteCount += 2 + len;
/*     */       }
/* 208 */       setDataLength(byteCount);
/* 209 */       return;
/*     */     }
/* 211 */     setDataLength(byteCount);
/*     */   }
/*     */   
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 217 */     int size = 6;
/*     */     
/* 219 */     for (int i = 0; i < this.m_FieldCount; i++)
/*     */     {
/*     */ 
/*     */ 
/* 223 */       size++;
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 229 */       size++;
/* 230 */       size += this.m_Fields[i].length();
/*     */     }
/*     */     
/* 233 */     byte[] result = new byte[size];
/* 234 */     int offset = 0;
/*     */     
/* 236 */     result[(offset++)] = 14;
/* 237 */     result[(offset++)] = ((byte)this.m_FieldLevel);
/* 238 */     result[(offset++)] = ((byte)this.m_Conformity);
/* 239 */     result[(offset++)] = ((byte)(this.m_MoreFollows ? 'ÿ' : 0));
/* 240 */     result[(offset++)] = ((byte)this.m_NextFieldId);
/* 241 */     result[(offset++)] = ((byte)this.m_FieldCount);
/*     */     
/* 243 */     for (int i = 0; i < this.m_FieldCount; i++) {
/* 244 */       result[(offset++)] = ((byte)this.m_FieldIds[i]);
/* 245 */       result[(offset++)] = ((byte)this.m_Fields[i].length());
/* 246 */       System.arraycopy(this.m_Fields[i].getBytes(), 0, 
/* 247 */         result, offset, this.m_Fields[i].length());
/* 248 */       offset += this.m_Fields[i].length();
/*     */     }
/*     */     
/* 251 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadMEIResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */