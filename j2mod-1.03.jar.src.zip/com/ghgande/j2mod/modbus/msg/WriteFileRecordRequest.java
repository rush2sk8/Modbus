/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.procimg.File;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.Record;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WriteFileRecordRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_ByteCount;
/*     */   private RecordRequest[] m_Records;
/*     */   
/*     */   public class RecordRequest
/*     */   {
/*     */     private int m_FileNumber;
/*     */     private int m_RecordNumber;
/*     */     private int m_WordCount;
/*     */     private byte[] m_Data;
/*     */     
/*     */     public int getFileNumber()
/*     */     {
/*  68 */       return this.m_FileNumber;
/*     */     }
/*     */     
/*     */     public int getRecordNumber() {
/*  72 */       return this.m_RecordNumber;
/*     */     }
/*     */     
/*     */     public int getWordCount() {
/*  76 */       return this.m_WordCount;
/*     */     }
/*     */     
/*     */     public SimpleRegister getRegister(int register) {
/*  80 */       if ((register < 0) || (register >= this.m_WordCount)) {
/*  81 */         throw new IllegalAddressException("0 <= " + 
/*  82 */           register + " < " + this.m_WordCount);
/*     */       }
/*  84 */       byte b1 = this.m_Data[(register * 2)];
/*  85 */       byte b2 = this.m_Data[(register * 2 + 1)];
/*     */       
/*  87 */       SimpleRegister result = new SimpleRegister(b1, b2);
/*  88 */       return result;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getRequestSize()
/*     */     {
/*  95 */       return 7 + this.m_WordCount * 2;
/*     */     }
/*     */     
/*     */     public void getRequest(byte[] request, int offset) {
/*  99 */       request[(offset++)] = 6;
/* 100 */       request[(offset++)] = ((byte)(this.m_FileNumber >> 8));
/* 101 */       request[(offset++)] = ((byte)(this.m_FileNumber & 0xFF));
/* 102 */       request[(offset++)] = ((byte)(this.m_RecordNumber >> 8));
/* 103 */       request[(offset++)] = ((byte)(this.m_RecordNumber & 0xFF));
/* 104 */       request[(offset++)] = ((byte)(this.m_WordCount >> 8));
/* 105 */       request[(offset++)] = ((byte)(this.m_WordCount & 0xFF));
/*     */       
/* 107 */       System.arraycopy(this.m_Data, 0, request, offset, this.m_Data.length);
/*     */     }
/*     */     
/*     */     public byte[] getRequest() {
/* 111 */       byte[] request = new byte[7 + 2 * this.m_WordCount];
/*     */       
/* 113 */       getRequest(request, 0);
/*     */       
/* 115 */       return request;
/*     */     }
/*     */     
/*     */     public RecordRequest(int file, int record, short[] values) {
/* 119 */       this.m_FileNumber = file;
/* 120 */       this.m_RecordNumber = record;
/* 121 */       this.m_WordCount = values.length;
/* 122 */       this.m_Data = new byte[this.m_WordCount * 2];
/*     */       
/* 124 */       int offset = 0;
/* 125 */       for (int i = 0; i < this.m_WordCount; i++) {
/* 126 */         this.m_Data[(offset++)] = ((byte)(values[i] >> 8));
/* 127 */         this.m_Data[(offset++)] = ((byte)(values[i] & 0xFF));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRequestSize()
/*     */   {
/* 140 */     if (this.m_Records == null) {
/* 141 */       return 1;
/*     */     }
/* 143 */     int size = 1;
/* 144 */     for (int i = 0; i < this.m_Records.length; i++) {
/* 145 */       size += this.m_Records[i].getRequestSize();
/*     */     }
/* 147 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRequestCount()
/*     */   {
/* 155 */     if (this.m_Records == null) {
/* 156 */       return 0;
/*     */     }
/* 158 */     return this.m_Records.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RecordRequest getRecord(int index)
/*     */   {
/* 165 */     return this.m_Records[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addRequest(RecordRequest request)
/*     */   {
/* 172 */     if (request.getRequestSize() + getRequestSize() > 248) {
/* 173 */       throw new IllegalArgumentException();
/*     */     }
/* 175 */     if (this.m_Records == null) {
/* 176 */       this.m_Records = new RecordRequest[1];
/*     */     } else {
/* 178 */       RecordRequest[] old = this.m_Records;
/* 179 */       this.m_Records = new RecordRequest[old.length + 1];
/*     */       
/* 181 */       System.arraycopy(old, 0, this.m_Records, 0, old.length);
/*     */     }
/* 183 */     this.m_Records[(this.m_Records.length - 1)] = request;
/*     */     
/* 185 */     setDataLength(getRequestSize());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModbusResponse getResponse()
/*     */   {
/* 192 */     WriteFileRecordResponse response = null;
/*     */     
/* 194 */     response = new WriteFileRecordResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 199 */     response.setHeadless(isHeadless());
/* 200 */     if (!isHeadless()) {
/* 201 */       response.setTransactionID(getTransactionID());
/* 202 */       response.setProtocolID(getProtocolID());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 208 */     response.setUnitID(getUnitID());
/* 209 */     response.setFunctionCode(getFunctionCode());
/*     */     
/* 211 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModbusResponse createResponse()
/*     */   {
/* 218 */     WriteFileRecordResponse response = null;
/* 219 */     response = (WriteFileRecordResponse)getResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 224 */     ProcessImage procimg = ModbusCoupler.getReference().getProcessImage();
/*     */     
/*     */ 
/*     */ 
/*     */     try
/*     */     {
/* 230 */       for (int i = 0; i < getRequestCount(); i++) {
/* 231 */         RecordRequest recordRequest = getRecord(i);
/* 232 */         if ((recordRequest.getFileNumber() < 0) || 
/* 233 */           (recordRequest.getFileNumber() >= procimg.getFileCount())) {
/* 234 */           return createExceptionResponse(2);
/*     */         }
/* 236 */         File file = procimg.getFileByNumber(recordRequest.getFileNumber());
/*     */         
/* 238 */         if ((recordRequest.getRecordNumber() < 0) || 
/* 239 */           (recordRequest.getRecordNumber() >= file.getRecordCount())) {
/* 240 */           return createExceptionResponse(2);
/*     */         }
/* 242 */         Record record = file.getRecord(recordRequest.getRecordNumber());
/* 243 */         int registers = recordRequest.getWordCount();
/* 244 */         if ((record == null) && (registers != 0)) {
/* 245 */           return createExceptionResponse(2);
/*     */         }
/* 247 */         short[] data = new short[registers];
/* 248 */         for (int j = 0; j < registers; j++) {
/* 249 */           Register register = record.getRegister(j);
/* 250 */           if (register == null) {
/* 251 */             return createExceptionResponse(2);
/*     */           }
/* 253 */           register.setValue(recordRequest.getRegister(j).getValue());
/* 254 */           data[j] = recordRequest.getRegister(j).toShort();
/*     */         }
/* 256 */         WriteFileRecordResponse tmp211_210 = response;tmp211_210.getClass();WriteFileRecordResponse.RecordResponse recordResponse = new WriteFileRecordResponse.RecordResponse(tmp211_210, 
/* 257 */           file.getFileNumber(), record.getRecordNumber(), data);
/* 258 */         response.addResponse(recordResponse);
/*     */       }
/*     */     } catch (IllegalAddressException e) {
/* 261 */       return createExceptionResponse(2);
/*     */     }
/* 263 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 270 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 277 */     this.m_ByteCount = din.readUnsignedByte();
/*     */     
/* 279 */     this.m_Records = new RecordRequest[0];
/*     */     
/* 281 */     for (int offset = 1; offset + 7 < this.m_ByteCount;) {
/* 282 */       int function = din.readUnsignedByte();
/* 283 */       int file = din.readUnsignedShort();
/* 284 */       int record = din.readUnsignedShort();
/* 285 */       int count = din.readUnsignedShort();
/*     */       
/* 287 */       offset += 7;
/*     */       
/* 289 */       if (function != 6) {
/* 290 */         throw new IOException();
/*     */       }
/* 292 */       if ((record < 0) || (record >= 10000)) {
/* 293 */         throw new IOException();
/*     */       }
/* 295 */       if ((count < 0) || (count >= 126)) {
/* 296 */         throw new IOException();
/*     */       }
/* 298 */       short[] registers = new short[count];
/* 299 */       for (int j = 0; j < count; j++) {
/* 300 */         registers[j] = din.readShort();
/* 301 */         offset += 2;
/*     */       }
/* 303 */       RecordRequest[] dummy = new RecordRequest[this.m_Records.length + 1];
/* 304 */       if (this.m_Records.length > 0) {
/* 305 */         System.arraycopy(this.m_Records, 0, dummy, 0, this.m_Records.length);
/*     */       }
/* 307 */       this.m_Records = dummy;
/* 308 */       this.m_Records[(this.m_Records.length - 1)] = 
/* 309 */         new RecordRequest(file, record, registers);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 317 */     byte[] results = new byte[getRequestSize()];
/*     */     
/* 319 */     results[0] = ((byte)(getRequestSize() - 1));
/*     */     
/* 321 */     int offset = 1;
/* 322 */     for (int i = 0; i < this.m_Records.length; i++) {
/* 323 */       this.m_Records[i].getRequest(results, offset);
/* 324 */       offset += this.m_Records[i].getRequestSize();
/*     */     }
/* 326 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriteFileRecordRequest()
/*     */   {
/* 336 */     setFunctionCode(21);
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 341 */     setDataLength(1);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\WriteFileRecordRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */