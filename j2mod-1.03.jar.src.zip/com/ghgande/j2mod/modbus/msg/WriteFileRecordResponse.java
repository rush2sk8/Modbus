/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleRegister;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WriteFileRecordResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_ByteCount;
/*     */   private RecordResponse[] m_Records;
/*     */   
/*     */   public class RecordResponse
/*     */   {
/*     */     private int m_FileNumber;
/*     */     private int m_RecordNumber;
/*     */     private int m_WordCount;
/*     */     private byte[] m_Data;
/*     */     
/*     */     public int getFileNumber()
/*     */     {
/*  92 */       return this.m_FileNumber;
/*     */     }
/*     */     
/*     */     public int getRecordNumber() {
/*  96 */       return this.m_RecordNumber;
/*     */     }
/*     */     
/*     */     public int getWordCount() {
/* 100 */       return this.m_WordCount;
/*     */     }
/*     */     
/*     */     public SimpleRegister getRegister(int register) {
/* 104 */       if ((register < 0) || (register >= this.m_WordCount)) {
/* 105 */         throw new IndexOutOfBoundsException("0 <= " + 
/* 106 */           register + " < " + this.m_WordCount);
/*     */       }
/* 108 */       byte b1 = this.m_Data[(register * 2)];
/* 109 */       byte b2 = this.m_Data[(register * 2 + 1)];
/*     */       
/* 111 */       SimpleRegister result = new SimpleRegister(b1, b2);
/* 112 */       return result;
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */     public int getResponseSize()
/*     */     {
/* 119 */       return 7 + this.m_WordCount * 2;
/*     */     }
/*     */     
/*     */     public void getResponse(byte[] response, int offset) {
/* 123 */       response[(offset++)] = 6;
/* 124 */       response[(offset++)] = ((byte)(this.m_FileNumber >> 8));
/* 125 */       response[(offset++)] = ((byte)(this.m_FileNumber & 0xFF));
/* 126 */       response[(offset++)] = ((byte)(this.m_RecordNumber >> 8));
/* 127 */       response[(offset++)] = ((byte)(this.m_RecordNumber & 0xFF));
/* 128 */       response[(offset++)] = ((byte)(this.m_WordCount >> 8));
/* 129 */       response[(offset++)] = ((byte)(this.m_WordCount & 0xFF));
/*     */       
/* 131 */       System.arraycopy(this.m_Data, 0, response, offset, this.m_Data.length);
/*     */     }
/*     */     
/*     */     public byte[] getResponse() {
/* 135 */       byte[] response = new byte[7 + 2 * this.m_WordCount];
/*     */       
/* 137 */       getResponse(response, 0);
/*     */       
/* 139 */       return response;
/*     */     }
/*     */     
/*     */     public RecordResponse(int file, int record, short[] values) {
/* 143 */       this.m_FileNumber = file;
/* 144 */       this.m_RecordNumber = record;
/* 145 */       this.m_WordCount = values.length;
/* 146 */       this.m_Data = new byte[this.m_WordCount * 2];
/*     */       
/* 148 */       int offset = 0;
/* 149 */       for (int i = 0; i < this.m_WordCount; i++) {
/* 150 */         this.m_Data[(offset++)] = ((byte)(values[i] >> 8));
/* 151 */         this.m_Data[(offset++)] = ((byte)(values[i] & 0xFF));
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getResponseSize()
/*     */   {
/* 163 */     if (this.m_Records == null) {
/* 164 */       return 1;
/*     */     }
/* 166 */     int size = 1;
/* 167 */     for (int i = 0; i < this.m_Records.length; i++) {
/* 168 */       size += this.m_Records[i].getResponseSize();
/*     */     }
/* 170 */     return size;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRequestCount()
/*     */   {
/* 178 */     if (this.m_Records == null) {
/* 179 */       return 0;
/*     */     }
/* 181 */     return this.m_Records.length;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public RecordResponse getRecord(int index)
/*     */   {
/* 188 */     return this.m_Records[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void addResponse(RecordResponse response)
/*     */   {
/* 195 */     if (response.getResponseSize() + getResponseSize() > 248) {
/* 196 */       throw new IllegalArgumentException();
/*     */     }
/* 198 */     if (this.m_Records == null) {
/* 199 */       this.m_Records = new RecordResponse[1];
/*     */     } else {
/* 201 */       RecordResponse[] old = this.m_Records;
/* 202 */       this.m_Records = new RecordResponse[old.length + 1];
/*     */       
/* 204 */       System.arraycopy(old, 0, this.m_Records, 0, old.length);
/*     */     }
/* 206 */     this.m_Records[(this.m_Records.length - 1)] = response;
/*     */     
/* 208 */     setDataLength(getResponseSize());
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 212 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 216 */     this.m_ByteCount = din.readUnsignedByte();
/*     */     
/* 218 */     this.m_Records = new RecordResponse[0];
/*     */     
/* 220 */     for (int offset = 1; offset + 7 < this.m_ByteCount;) {
/* 221 */       int function = din.readUnsignedByte();
/* 222 */       int file = din.readUnsignedShort();
/* 223 */       int record = din.readUnsignedShort();
/* 224 */       int count = din.readUnsignedShort();
/*     */       
/* 226 */       offset += 7;
/*     */       
/* 228 */       if (function != 6) {
/* 229 */         throw new IOException();
/*     */       }
/* 231 */       if ((record < 0) || (record >= 10000)) {
/* 232 */         throw new IOException();
/*     */       }
/* 234 */       if ((count < 0) || (count >= 126)) {
/* 235 */         throw new IOException();
/*     */       }
/* 237 */       short[] registers = new short[count];
/* 238 */       for (int j = 0; j < count; j++) {
/* 239 */         registers[j] = din.readShort();
/* 240 */         offset += 2;
/*     */       }
/* 242 */       RecordResponse[] dummy = new RecordResponse[this.m_Records.length + 1];
/* 243 */       if (this.m_Records.length > 0) {
/* 244 */         System.arraycopy(this.m_Records, 0, dummy, 0, this.m_Records.length);
/*     */       }
/* 246 */       this.m_Records = dummy;
/* 247 */       this.m_Records[(this.m_Records.length - 1)] = 
/* 248 */         new RecordResponse(file, record, registers);
/*     */     }
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 253 */     byte[] results = new byte[getResponseSize()];
/*     */     
/* 255 */     results[0] = ((byte)(getResponseSize() - 1));
/*     */     
/* 257 */     int offset = 1;
/* 258 */     for (int i = 0; i < this.m_Records.length; i++) {
/* 259 */       this.m_Records[i].getResponse(results, offset);
/* 260 */       offset += this.m_Records[i].getResponseSize();
/*     */     }
/* 262 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriteFileRecordResponse()
/*     */   {
/* 271 */     setFunctionCode(21);
/* 272 */     setDataLength(7);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\WriteFileRecordResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */