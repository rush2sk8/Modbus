package com.ghgande.j2mod.modbus.msg;

import com.ghgande.j2mod.modbus.io.Transportable;

public abstract interface ModbusMessage
  extends Transportable
{
  public abstract boolean isHeadless();
  
  public abstract void setHeadless();
  
  public abstract int getTransactionID();
  
  public abstract int getProtocolID();
  
  public abstract int getDataLength();
  
  public abstract int getUnitID();
  
  public abstract int getFunctionCode();
  
  public abstract byte[] getMessage();
  
  public abstract String getHexMessage();
}


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ModbusMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */