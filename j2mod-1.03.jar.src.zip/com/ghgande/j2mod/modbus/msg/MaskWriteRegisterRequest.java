/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import com.ghgande.j2mod.modbus.procimg.Register;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MaskWriteRegisterRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_Reference;
/*     */   private int m_AndMask;
/*     */   private int m_OrMask;
/*     */   
/*     */   public int getReference()
/*     */   {
/*  98 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/* 105 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getAndMask()
/*     */   {
/* 113 */     return this.m_AndMask;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setAndMask(int mask)
/*     */   {
/* 120 */     this.m_AndMask = mask;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getOrMask()
/*     */   {
/* 128 */     return this.m_OrMask;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setOrMask(int mask)
/*     */   {
/* 135 */     this.m_OrMask = mask;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public ModbusResponse getResponse()
/*     */   {
/* 142 */     MaskWriteRegisterResponse response = null;
/*     */     
/* 144 */     response = new MaskWriteRegisterResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 149 */     response.setHeadless(isHeadless());
/* 150 */     if (!isHeadless()) {
/* 151 */       response.setTransactionID(getTransactionID());
/* 152 */       response.setProtocolID(getProtocolID());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 158 */     response.setUnitID(getUnitID());
/* 159 */     response.setFunctionCode(getFunctionCode());
/*     */     
/* 161 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public ModbusResponse createResponse()
/*     */   {
/* 169 */     MaskWriteRegisterResponse response = null;
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 174 */     ProcessImage procimg = ModbusCoupler.getReference().getProcessImage();
/*     */     try {
/* 176 */       Register register = procimg.getRegister(this.m_Reference);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 183 */       int value = register.getValue();
/* 184 */       System.err.println("original value = " + value);
/*     */       
/* 186 */       System.err.println("and = " + this.m_AndMask + ", or = " + this.m_OrMask);
/* 187 */       value = value & this.m_AndMask | this.m_OrMask;
/* 188 */       System.err.println("new value = " + value);
/*     */       
/*     */ 
/*     */ 
/*     */ 
/* 193 */       register.setValue(value);
/* 194 */       System.err.println("Done.");
/*     */     } catch (IllegalAddressException iaex) {
/* 196 */       return createExceptionResponse(2);
/*     */     }
/* 198 */     response = (MaskWriteRegisterResponse)getResponse();
/*     */     
/* 200 */     response.setReference(this.m_Reference);
/* 201 */     response.setAndMask(this.m_AndMask);
/* 202 */     response.setOrMask(this.m_OrMask);
/*     */     
/* 204 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 211 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 218 */     this.m_Reference = din.readShort();
/* 219 */     this.m_AndMask = din.readShort();
/* 220 */     this.m_OrMask = din.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 228 */     byte[] results = new byte[6];
/*     */     
/* 230 */     results[0] = ((byte)(this.m_Reference >> 8));
/* 231 */     results[1] = ((byte)(this.m_Reference & 0xFF));
/* 232 */     results[2] = ((byte)(this.m_AndMask >> 8));
/* 233 */     results[3] = ((byte)(this.m_AndMask & 0xFF));
/* 234 */     results[4] = ((byte)(this.m_OrMask >> 8));
/* 235 */     results[5] = ((byte)(this.m_OrMask & 0xFF));
/*     */     
/* 237 */     return results;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MaskWriteRegisterRequest(int ref, int andMask, int orMask)
/*     */   {
/* 250 */     setFunctionCode(22);
/* 251 */     setReference(ref);
/* 252 */     setAndMask(andMask);
/* 253 */     setOrMask(orMask);
/*     */     
/* 255 */     setDataLength(6);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public MaskWriteRegisterRequest()
/*     */   {
/* 265 */     setFunctionCode(22);
/* 266 */     setDataLength(6);
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\MaskWriteRegisterRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */