/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WriteMultipleRegistersResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_WordCount;
/*     */   private int m_Reference;
/*     */   
/*     */   public WriteMultipleRegistersResponse()
/*     */   {
/*  61 */     setFunctionCode(16);
/*  62 */     setDataLength(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriteMultipleRegistersResponse(int reference, int wordcount)
/*     */   {
/*  76 */     setFunctionCode(16);
/*  77 */     setDataLength(4);
/*     */     
/*  79 */     this.m_Reference = reference;
/*  80 */     this.m_WordCount = wordcount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/*  93 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/* 105 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getByteCount()
/*     */   {
/* 114 */     return this.m_WordCount * 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWordCount()
/*     */   {
/* 125 */     return this.m_WordCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setWordCount(int count)
/*     */   {
/* 135 */     this.m_WordCount = count;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 139 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 143 */     setReference(din.readUnsignedShort());
/* 144 */     setWordCount(din.readUnsignedShort());
/*     */     
/* 146 */     setDataLength(4);
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 150 */     byte[] result = new byte[4];
/*     */     
/* 152 */     result[0] = ((byte)(this.m_Reference >> 8 & 0xFF));
/* 153 */     result[1] = ((byte)(this.m_Reference & 0xFF));
/* 154 */     result[2] = ((byte)(this.m_WordCount >> 8 & 0xFF));
/* 155 */     result[3] = ((byte)(this.m_WordCount & 0xFF));
/*     */     
/* 157 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\WriteMultipleRegistersResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */