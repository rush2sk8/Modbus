/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.procimg.InputRegister;
/*     */ import com.ghgande.j2mod.modbus.procimg.SimpleInputRegister;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadInputRegistersResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_ByteCount;
/*     */   private InputRegister[] m_Registers;
/*     */   
/*     */   public ReadInputRegistersResponse()
/*     */   {
/*  64 */     setFunctionCode(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadInputRegistersResponse(InputRegister[] registers)
/*     */   {
/*  76 */     setFunctionCode(4);
/*  77 */     setDataLength(registers.length * 2 + 1);
/*     */     
/*  79 */     this.m_ByteCount = (registers.length * 2 + 1);
/*  80 */     this.m_Registers = registers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getByteCount()
/*     */   {
/*  89 */     return this.m_ByteCount;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getWordCount()
/*     */   {
/*  99 */     return this.m_ByteCount / 2;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setWordCount(int count)
/*     */   {
/* 106 */     this.m_ByteCount = (count * 2 + 1);
/*     */     
/* 108 */     InputRegister[] regs = new InputRegister[count];
/* 109 */     if (this.m_Registers != null) {
/* 110 */       for (int i = 0; (i < this.m_Registers.length) && (i < count); i++) {
/* 111 */         regs[i] = this.m_Registers[i];
/*     */       }
/* 113 */       if (this.m_Registers.length < count) {
/* 114 */         for (int i = this.m_Registers.length; i < count; i++) {
/* 115 */           regs[i] = new SimpleInputRegister(0);
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputRegister getRegister(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 131 */     if (index < 0) {
/* 132 */       throw new IndexOutOfBoundsException(index + " < 0");
/*     */     }
/* 134 */     if (index >= getWordCount()) {
/* 135 */       throw new IndexOutOfBoundsException(index + " >= " + getWordCount());
/*     */     }
/* 137 */     return this.m_Registers[index];
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getRegisterValue(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 154 */     return getRegister(index).toUnsignedShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public InputRegister[] getRegisters()
/*     */   {
/* 163 */     return this.m_Registers;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setRegisters(InputRegister[] registers)
/*     */   {
/* 170 */     setDataLength(registers.length * 2 + 1);
/*     */     
/* 172 */     this.m_ByteCount = (registers.length * 2 + 1);
/* 173 */     this.m_Registers = registers;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 177 */     dout.writeByte(this.m_ByteCount);
/*     */     
/* 179 */     for (int k = 0; k < getWordCount(); k++) {
/* 180 */       dout.write(this.m_Registers[k].toBytes());
/*     */     }
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 185 */     this.m_ByteCount = din.readUnsignedByte();
/*     */     
/* 187 */     InputRegister[] registers = new InputRegister[getWordCount()];
/* 188 */     for (int k = 0; k < getWordCount(); k++) {
/* 189 */       registers[k] = new SimpleInputRegister(din.readByte(), 
/* 190 */         din.readByte());
/*     */     }
/* 192 */     this.m_Registers = registers;
/*     */     
/* 194 */     setDataLength(this.m_ByteCount + 1);
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 198 */     byte[] result = new byte[this.m_ByteCount + 1];
/* 199 */     result[0] = ((byte)this.m_ByteCount);
/*     */     
/* 201 */     for (int i = 0; i < this.m_Registers.length; i++) {
/* 202 */       byte[] value = this.m_Registers[i].toBytes();
/*     */       
/* 204 */       result[(1 + i * 2)] = value[0];
/* 205 */       result[(2 + i * 2)] = value[1];
/*     */     }
/* 207 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadInputRegistersResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */