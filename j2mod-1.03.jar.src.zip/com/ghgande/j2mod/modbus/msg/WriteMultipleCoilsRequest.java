/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.procimg.DigitalOut;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import com.ghgande.j2mod.modbus.util.BitVector;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WriteMultipleCoilsRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_Reference;
/*     */   private BitVector m_Coils;
/*     */   
/*     */   public WriteMultipleCoilsRequest()
/*     */   {
/*  74 */     setFunctionCode(15);
/*  75 */     setDataLength(5);
/*     */     
/*  77 */     this.m_Coils = new BitVector(1);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriteMultipleCoilsRequest(int ref, int count)
/*     */   {
/*  93 */     setFunctionCode(15);
/*  94 */     setDataLength((count + 7) / 8 + 5);
/*     */     
/*  96 */     setReference(ref);
/*  97 */     this.m_Coils = new BitVector(count);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public WriteMultipleCoilsRequest(int ref, BitVector bv)
/*     */   {
/* 112 */     setFunctionCode(15);
/* 113 */     setDataLength(bv.byteSize() + 5);
/*     */     
/* 115 */     setReference(ref);
/* 116 */     this.m_Coils = bv;
/*     */   }
/*     */   
/*     */   public ModbusResponse getResponse() {
/* 120 */     WriteMultipleCoilsResponse response = new WriteMultipleCoilsResponse();
/*     */     
/* 122 */     response.setHeadless(isHeadless());
/* 123 */     if (!isHeadless()) {
/* 124 */       response.setProtocolID(getProtocolID());
/* 125 */       response.setTransactionID(getTransactionID());
/*     */     }
/* 127 */     response.setFunctionCode(getFunctionCode());
/* 128 */     response.setUnitID(getUnitID());
/*     */     
/* 130 */     return response;
/*     */   }
/*     */   
/*     */   public ModbusResponse createResponse() {
/* 134 */     WriteMultipleCoilsResponse response = null;
/* 135 */     DigitalOut[] douts = null;
/*     */     
/*     */ 
/* 138 */     ProcessImage procimg = ModbusCoupler.getReference().getProcessImage();
/*     */     try
/*     */     {
/* 141 */       douts = procimg.getDigitalOutRange(this.m_Reference, this.m_Coils.size());
/*     */       
/* 143 */       for (int i = 0; i < douts.length; i++) {
/* 144 */         douts[i].set(this.m_Coils.getBit(i));
/*     */       }
/*     */     } catch (IllegalAddressException iaex) {
/* 147 */       return createExceptionResponse(2);
/*     */     }
/* 149 */     response = (WriteMultipleCoilsResponse)getResponse();
/*     */     
/* 151 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/* 163 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/* 174 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBitCount()
/*     */   {
/* 183 */     if (this.m_Coils == null) {
/* 184 */       return 0;
/*     */     }
/* 186 */     return this.m_Coils.size();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getByteCount()
/*     */   {
/* 195 */     return this.m_Coils.byteSize();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public boolean getCoilStatus(int index)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 208 */     return this.m_Coils.getBit(index);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCoilStatus(int index, boolean b)
/*     */     throws IndexOutOfBoundsException
/*     */   {
/* 223 */     this.m_Coils.setBit(index, b);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public BitVector getCoils()
/*     */   {
/* 232 */     return this.m_Coils;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setCoils(BitVector bv)
/*     */   {
/* 242 */     this.m_Coils = bv;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 246 */     dout.writeShort(this.m_Reference);
/* 247 */     dout.writeShort(this.m_Coils.size());
/*     */     
/* 249 */     dout.writeByte(this.m_Coils.byteSize());
/* 250 */     dout.write(this.m_Coils.getBytes());
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 254 */     this.m_Reference = din.readUnsignedShort();
/* 255 */     int bitcount = din.readUnsignedShort();
/* 256 */     int count = din.readUnsignedByte();
/* 257 */     byte[] data = new byte[count];
/*     */     
/* 259 */     for (int k = 0; k < count; k++) {
/* 260 */       data[k] = din.readByte();
/*     */     }
/*     */     
/* 263 */     this.m_Coils = BitVector.createBitVector(data, bitcount);
/*     */     
/*     */ 
/* 266 */     setDataLength(count + 5);
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 270 */     int len = this.m_Coils.byteSize() + 5;
/* 271 */     byte[] result = new byte[len];
/*     */     
/* 273 */     result[0] = ((byte)(this.m_Reference >> 8 & 0xFF));
/* 274 */     result[1] = ((byte)(this.m_Reference & 0xFF));
/*     */     
/* 276 */     result[2] = ((byte)(this.m_Coils.size() >> 8 & 0xFF));
/* 277 */     result[3] = ((byte)(this.m_Coils.size() & 0xFF));
/*     */     
/* 279 */     result[4] = ((byte)this.m_Coils.byteSize());
/*     */     
/* 281 */     System.arraycopy(this.m_Coils.getBytes(), 0, result, 5, this.m_Coils.byteSize());
/*     */     
/* 283 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\WriteMultipleCoilsRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */