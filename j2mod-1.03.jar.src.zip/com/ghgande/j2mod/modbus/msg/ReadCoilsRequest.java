/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import com.ghgande.j2mod.modbus.ModbusCoupler;
/*     */ import com.ghgande.j2mod.modbus.procimg.DigitalOut;
/*     */ import com.ghgande.j2mod.modbus.procimg.IllegalAddressException;
/*     */ import com.ghgande.j2mod.modbus.procimg.ProcessImage;
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadCoilsRequest
/*     */   extends ModbusRequest
/*     */ {
/*     */   private int m_Reference;
/*     */   private int m_BitCount;
/*     */   
/*     */   public ReadCoilsRequest()
/*     */   {
/*  72 */     setFunctionCode(1);
/*  73 */     setDataLength(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public ReadCoilsRequest(int ref, int count)
/*     */   {
/*  89 */     setFunctionCode(1);
/*  90 */     setDataLength(4);
/*     */     
/*  92 */     setReference(ref);
/*  93 */     setBitCount(count);
/*     */   }
/*     */   
/*     */   public ReadCoilsResponse getResponse() {
/*  97 */     ReadCoilsResponse response = null;
/*  98 */     response = new ReadCoilsResponse(this.m_BitCount);
/*     */     
/*     */ 
/* 101 */     if (!isHeadless()) {
/* 102 */       response.setTransactionID(getTransactionID());
/* 103 */       response.setProtocolID(getProtocolID());
/*     */     } else {
/* 105 */       response.setHeadless();
/*     */     }
/* 107 */     response.setUnitID(getUnitID());
/*     */     
/* 109 */     return response;
/*     */   }
/*     */   
/*     */   public ModbusResponse createResponse() {
/* 113 */     ModbusResponse response = null;
/* 114 */     DigitalOut[] douts = null;
/*     */     
/*     */ 
/* 117 */     ProcessImage procimg = ModbusCoupler.getReference().getProcessImage();
/*     */     try
/*     */     {
/* 120 */       douts = procimg.getDigitalOutRange(getReference(), 
/* 121 */         getBitCount());
/*     */     } catch (IllegalAddressException e) {
/* 123 */       response = new IllegalAddressExceptionResponse();
/* 124 */       response.setUnitID(getUnitID());
/* 125 */       response.setFunctionCode(getFunctionCode());
/*     */       
/* 127 */       return response;
/*     */     }
/* 129 */     response = getResponse();
/*     */     
/*     */ 
/*     */ 
/*     */ 
/* 134 */     for (int i = 0; i < douts.length; i++) {
/* 135 */       ((ReadCoilsResponse)response).setCoilStatus(i, douts[i].isSet());
/*     */     }
/* 137 */     return response;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setReference(int ref)
/*     */   {
/* 149 */     this.m_Reference = ref;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getReference()
/*     */   {
/* 161 */     return this.m_Reference;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setBitCount(int count)
/*     */   {
/* 173 */     if (count > 2000) {
/* 174 */       throw new IllegalArgumentException("Maximum bitcount exceeded.");
/*     */     }
/* 176 */     this.m_BitCount = count;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getBitCount()
/*     */   {
/* 188 */     return this.m_BitCount;
/*     */   }
/*     */   
/*     */   public void writeData(DataOutput dout) throws IOException {
/* 192 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */   public void readData(DataInput din) throws IOException {
/* 196 */     this.m_Reference = din.readUnsignedShort();
/* 197 */     this.m_BitCount = din.readUnsignedShort();
/*     */   }
/*     */   
/*     */   public byte[] getMessage() {
/* 201 */     byte[] result = new byte[4];
/*     */     
/* 203 */     result[0] = ((byte)(this.m_Reference >> 8 & 0xFF));
/* 204 */     result[1] = ((byte)(this.m_Reference & 0xFF));
/* 205 */     result[2] = ((byte)(this.m_BitCount >> 8 & 0xFF));
/* 206 */     result[3] = ((byte)(this.m_BitCount & 0xFF));
/*     */     
/* 208 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadCoilsRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */