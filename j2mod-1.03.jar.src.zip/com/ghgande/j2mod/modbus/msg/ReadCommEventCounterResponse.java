/*     */ package com.ghgande.j2mod.modbus.msg;
/*     */ 
/*     */ import java.io.DataInput;
/*     */ import java.io.DataOutput;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ReadCommEventCounterResponse
/*     */   extends ModbusResponse
/*     */ {
/*     */   private int m_Status;
/*     */   private int m_Events;
/*     */   
/*     */   public ReadCommEventCounterResponse()
/*     */   {
/*  96 */     setFunctionCode(11);
/*  97 */     setDataLength(4);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public int getStatus()
/*     */   {
/* 106 */     return this.m_Status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public void setStatus(int status)
/*     */   {
/* 115 */     this.m_Status = status;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public int getEventCount()
/*     */   {
/* 122 */     return this.m_Events;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void setEventCount(int count)
/*     */   {
/* 129 */     this.m_Events = count;
/*     */   }
/*     */   
/*     */ 
/*     */   public void writeData(DataOutput dout)
/*     */     throws IOException
/*     */   {
/* 136 */     dout.write(getMessage());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public void readData(DataInput din)
/*     */     throws IOException
/*     */   {
/* 144 */     this.m_Status = din.readShort();
/* 145 */     this.m_Events = din.readShort();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   public byte[] getMessage()
/*     */   {
/* 152 */     byte[] result = new byte[4];
/*     */     
/* 154 */     result[0] = ((byte)(this.m_Status >> 8));
/* 155 */     result[1] = ((byte)(this.m_Status & 0xFF));
/* 156 */     result[2] = ((byte)(this.m_Events >> 8));
/* 157 */     result[3] = ((byte)(this.m_Events & 0xFF));
/*     */     
/* 159 */     return result;
/*     */   }
/*     */ }


/* Location:              C:\Users\rna2\Downloads\j2mod-1.03.jar!\com\ghgande\j2mod\modbus\msg\ReadCommEventCounterResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */